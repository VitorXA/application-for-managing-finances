# Comprovantes Pix

App Android nativo (Kotlin + XML, sem bibliotecas externas) para guardar e consultar comprovantes Pix recebidos de outros apps pelo botão **Compartilhar**.

- Recebe imagens (PNG/JPEG), PDFs e texto pelo menu Compartilhar, ou por **Importar comprovante** (seletor de arquivos do Android).
- Guarda uma cópia no armazenamento privado do app. Não usa internet, contas nem permissões.
- Lista, pesquisa, abre, edita a descrição e exclui (com confirmação).
- Não é um banco: não faz pagamentos nem acessa contas. O app não criptografa os arquivos.
- Limpar os dados do app ou desinstalá-lo pode apagar os comprovantes salvos.

## Gerar o APK pelo celular (GitHub Actions)

1. No GitHub, crie um repositório e envie o projeto:
   - **Opção A (mais fácil no celular):** em *Add file → Upload files*, envie o arquivo `comprovantes-pix.zip` (sem descompactar). Depois, em *Add file → Create new file*, digite o nome `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo `build-apk.yml`.
   - **Opção B:** envie todos os arquivos mantendo as pastas (`gradlew`, `gradle/`, `app/`, `.github/` etc. na raiz).
2. Abra a aba **Actions** → workflow **Build Android APK** → **Run workflow**.
3. Quando terminar com sucesso, abra a execução e baixe o APK em **Artifacts** (`comprovantes-pix-apk`, um .zip com o `app-debug.apk`).
4. Extraia o .zip, toque no APK e permita a instalação de fontes desconhecidas para o app que você usou para abrir o arquivo.

## APK de depuração × Play Store

O APK gerado é de **depuração**, assinado com uma chave de teste: serve para instalar no seu aparelho. Para publicar na Play Store seria preciso um build *release* assinado com uma chave sua, uma conta de desenvolvedor Google Play e o envio como pacote AAB. Isso não está incluído aqui.

## Versões

Gradle 8.10.2 · Android Gradle Plugin 8.7.3 · Kotlin 2.1.10 · JDK 17 · compileSdk/targetSdk 35 · minSdk 24 · pacote `app.comprovantes.pix`.
