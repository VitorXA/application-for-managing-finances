# Meu Financeiro — Android nativo

Aplicativo Android nativo em Kotlin/XML para organizar dinheiro, planilhas pessoais e comprovantes Pix. Os dados ficam no próprio aparelho; não há login, conexão bancária ou envio automático de informações.

## Novidades da versão 1.3 (visual e recursos)

- **Novo visual**: tela inicial rolável com painel de saldo, período em chips, plano de renda com barra de progresso, atalhos com ícones e comprovantes recentes com valor e tipo detectados.
- **Modo escuro** automático (segue o tema do aparelho) e paleta revisada, com cores de categoria consistentes em listas e gráficos.
- **Movimentações**: resultado do período em destaque, busca por descrição/categoria/conta, filtros (Todas, Entradas, Saídas, Pendentes), agrupamento por dia, avatar da categoria e ações *Marcar como efetivada* e *Duplicar*.
- **Relatórios com gráficos**: entradas × saídas em 6 meses, rosca de gastos por categoria e taxa de poupança.
- **Ajustes**: bloqueio opcional do app com PIN/padrão/biometria do aparelho (também impede capturas de tela) e backup/restauração.

## O que esta versão inclui

- Painel inicial redesenhado com paleta em tons de papel quente, verde-floresta e sálvia; hierarquia visual mais clara e menos contornos competindo pela atenção.
- Saldo atual, entradas e saídas por semana, quinzena, mês ou ano.
- Planejamento de renda por mês ou quinzena.
- Dízimo **opcional e desativado por padrão**, com percentual configurável. Quando ativado, ele aparece como primeiro desconto do valor que ficará disponível para o planejamento.
- Contas obrigatórias recorrentes com valor mensal, dia de vencimento, conta/carteira utilizada e opção de pausar sem excluir.
- Percentual das despesas efetivadas em relação à renda recebida no período de planejamento. Quando não há entradas, o app orienta registrar uma receita em vez de mostrar uma porcentagem enganosa.
- Contas/carteiras identificadas nas movimentações e filtro de movimentações por conta.
- Cadastro, edição e exclusão de receitas/despesas, categoria, data, efetivação ou pendência, conta/carteira e vínculo opcional a comprovante.
- Calendário com visualizações por semana, mês e ano.
- Planilhas personalizadas, com colunas editáveis, tipos de campo, linhas/células editáveis, totais, pesquisa, filtros, ordenação e exportação CSV.
- Orçamentos por categoria e relatórios de despesas.
- Importação de comprovantes em imagem/PDF e recebimento pelo menu Compartilhar do Android preservados.
- **Backup e restauração** (botão *Backup* na tela inicial): um único .zip com movimentações, planilhas, orçamentos, contas fixas e comprovantes.
- **Exportação das movimentações em CSV** (período e conta filtrados na tela).
- **Registrar pagamento** direto de uma conta obrigatória (cria a despesa já preenchida, para você conferir).
- Comprovante idêntico importado duas vezes é reaproveitado, sem duplicar o arquivo.

## Regras importantes do planejamento

- O dízimo não é obrigatório e vem desativado por padrão. Só é calculado quando o usuário ativa a opção.
- O valor do dízimo é mostrado separadamente e descontado antes de calcular o valor disponível para distribuir no planejamento.
- Contas obrigatórias são provisões: são mostradas no planejamento, mas **não** criam despesas reais automaticamente. Para refletir um pagamento no saldo e nos relatórios, a pessoa registra a movimentação efetiva.
- O percentual de gasto considera despesas efetivadas em comparação com as entradas efetivadas dentro do período configurado. Movimentações pendentes ficam de fora.
- O valor disponível para planejamento é uma visão de orçamento; não altera o saldo bancário nem cria uma movimentação por conta própria.
- Contas/carteiras antigas que não tinham esse campo passam a aparecer como “Conta principal”, sem apagar os registros.

## Armazenamento e privacidade

- Dados financeiros, preferências, contas fixas e planilhas são salvos localmente no arquivo privado `finance-data.json`.
- Comprovantes seguem o armazenamento privado já existente (`receipts/` e `receipts.json`).
- Compartilhar/ importar um comprovante não cria automaticamente uma movimentação.
- Não há sincronização automática entre aparelhos. Use *Backup > Exportar* e guarde o .zip fora do aparelho.
- Arquivos ilegíveis nunca são apagados: o app guarda uma cópia com data/hora e avisa na abertura.

## Assinatura fixa (importante)

O arquivo `app/debug.keystore` é uma chave de depuração fixa, usada em todo build. Assim, cada APK novo instala **por cima** do anterior sem perder dados. Na primeira vez que você instalar esta versão, o Android pode pedir para desinstalar a anterior (assinatura diferente): exporte os dados antes, se houver algo importante. Depois disso as atualizações funcionam normalmente. Não use essa chave para publicar na Play Store.

## Compilar o APK pelo GitHub Actions

O workflow `.github/workflows/build-apk.yml` permite colocar `comprovantes-pix.zip` na raiz do repositório: o workflow extrai o ZIP automaticamente e compila o APK. Execute **Actions → Build Android APK → Run workflow**; depois baixe o artefato `comprovantes-pix-apk`.

Configuração esperada (inclui `android.useAndroidX=true`, exigido pelo ML Kit): Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.1.10, JDK 17, `compileSdk` 35 e `minSdk` 24.

## Nota de validação

A estrutura, os recursos XML e os fluxos de dados foram revisados estaticamente. Não foi possível executar a compilação Android dentro deste ambiente, porque o Gradle Wrapper precisa baixar Gradle de `services.gradle.org`, a rede/DNS está indisponível e não há Android SDK instalado aqui. Confirme a compilação pelo GitHub Actions antes de distribuir o APK.


## Leitura de comprovantes e movimentações

- Imagens, PDFs (primeira página) e texto compartilhado passam por leitura local com Google ML Kit Text Recognition.
- O app tenta identificar valor, data, entrada/saída, contraparte e categoria por regras de contexto em português.
- Antes de qualquer movimentação financeira ser criada, a pessoa revisa e confirma o tipo, valor, data, descrição, categoria e conta.
- O arquivo e o texto reconhecido ficam armazenados localmente; o OCR não envia o comprovante para uma API externa.
- Em comprovantes antigos, abra os detalhes e use **Ler comprovante e registrar** para analisar novamente sem criar uma segunda cópia do arquivo.
- Se os dados não forem identificados com clareza, o app pede preenchimento manual; os resultados automáticos são sugestões e podem exigir correção conforme o banco e a qualidade da imagem.
