# Meu Financeiro — Android nativo

Aplicativo Android nativo em Kotlin/XML para organizar dinheiro, planilhas pessoais e comprovantes Pix. Os dados ficam no próprio aparelho; não há login, conexão bancária ou envio automático de informações.

## O que esta versão inclui

- Painel inicial redesenhado com paleta em tons de papel quente, verde-floresta e sálvia; hierarquia visual mais clara e menos contornos competindo pela atenção.
- Saldo atual, entradas e saídas por semana, quinzena, mês ou ano.
- Planejamento de renda por mês ou quinzena.
- Dízimo **opcional e desativado por padrão**, com percentual configurável. Quando ativado, ele aparece como primeiro desconto do valor que ficará disponível para o planejamento.
- Contas obrigatórias recorrentes com valor mensal, dia de vencimento, conta/carteira utilizada e opção de pausar sem excluir.
- Percentual das despesas efetivadas em relação à renda recebida no período de planejamento. Quando não há entradas, o app orienta registrar uma receita em vez de mostrar uma porcentagem enganosa.
- Contas/carteiras identificadas nas movimentações e filtro de movimentações por conta.
- Cadastro, edição e exclusão de receitas/despesas, categoria, data, efetivação ou pendência, conta/carteira e vínculo opcional a comprovante.
- Calendário com visualizações por semana, mês e ano.
- Planilhas personalizadas, com colunas editáveis, tipos de campo, linhas/células editáveis, totais, pesquisa, filtros, ordenação e exportação CSV.
- Orçamentos por categoria e relatórios de despesas.
- Importação de comprovantes em imagem/PDF e recebimento pelo menu Compartilhar do Android preservados.

## Regras importantes do planejamento

- O dízimo não é obrigatório e vem desativado por padrão. Só é calculado quando o usuário ativa a opção.
- O valor do dízimo é mostrado separadamente e descontado antes de calcular o valor disponível para distribuir no planejamento.
- Contas obrigatórias são provisões: são mostradas no planejamento, mas **não** criam despesas reais automaticamente. Para refletir um pagamento no saldo e nos relatórios, a pessoa registra a movimentação efetiva.
- O percentual de gasto considera despesas efetivadas em comparação com as entradas efetivadas dentro do período configurado. Movimentações pendentes ficam de fora.
- O valor disponível para planejamento é uma visão de orçamento; não altera o saldo bancário nem cria uma movimentação por conta própria.
- Contas/carteiras antigas que não tinham esse campo passam a aparecer como “Conta principal”, sem apagar os registros.

## Armazenamento e privacidade

- Dados financeiros, preferências, contas fixas e planilhas são salvos localmente no arquivo privado `finance-data.json`.
- Comprovantes seguem o armazenamento privado já existente (`receipts/` e `receipts.json`).
- Compartilhar/ importar um comprovante não cria automaticamente uma movimentação.
- Ainda não há sincronização entre aparelhos nem backup/restauração completo.

## Compilar o APK pelo GitHub Actions

O workflow `.github/workflows/build-apk.yml` permite colocar `comprovantes-pix.zip` na raiz do repositório: o workflow extrai o ZIP automaticamente e compila o APK. Execute **Actions → Build Android APK → Run workflow**; depois baixe o artefato `comprovantes-pix-apk`.

Configuração esperada: Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.1.10, JDK 17, `compileSdk` 35 e `minSdk` 24.

## Nota de validação

A estrutura, os recursos XML e os fluxos de dados foram revisados estaticamente. Não foi possível executar a compilação Android dentro deste ambiente, porque o Gradle Wrapper precisa baixar Gradle de `services.gradle.org`, a rede/DNS está indisponível e não há Android SDK instalado aqui. Confirme a compilação pelo GitHub Actions antes de distribuir o APK.
