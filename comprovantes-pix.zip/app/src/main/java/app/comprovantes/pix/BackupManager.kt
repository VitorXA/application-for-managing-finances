package app.comprovantes.pix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup em um único .zip: dados financeiros (finance-data.json), índice de comprovantes
 * (receipts.json) e os arquivos em receipts/. Fica tudo no aparelho, até você salvar o arquivo onde quiser.
 */
object BackupManager {
    private const val FINANCE = "finance-data.json"
    private const val INDEX = "receipts.json"
    private const val FOLDER = "receipts/"
    private const val MAX_JSON = 64L * 1024 * 1024
    private const val MAX_FILE = 100L * 1024 * 1024
    private const val MAX_TOTAL = 1024L * 1024 * 1024

    fun export(context: Context, out: OutputStream) {
        ReceiptStore.init(context)
        FinanceStore.init(context)
        val base = context.applicationContext.filesDir
        ZipOutputStream(out).use { zip ->
            addFile(zip, File(base, FINANCE), FINANCE)
            addFile(zip, File(base, INDEX), INDEX)
            File(base, "receipts").listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") }
                ?.forEach { addFile(zip, it, FOLDER + it.name) }
        }
    }

    private fun addFile(zip: ZipOutputStream, file: File, name: String) {
        if (!file.isFile) return
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip) }
        zip.closeEntry()
    }

    /** Restaura um backup. Devolve um resumo para mostrar ao usuário; lança exceção se o arquivo for inválido. */
    fun restore(context: Context, input: InputStream): String {
        ReceiptStore.init(context)
        FinanceStore.init(context)
        val tmp = File(context.cacheDir, "restore-" + System.currentTimeMillis())
        val filesDir = File(tmp, "receipts")
        if (!filesDir.mkdirs()) throw IOException("sem espaço temporário")
        try {
            var financeText: String? = null
            var indexText: String? = null
            var total = 0L
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) continue
                    val name = entry.name
                    when {
                        name == FINANCE -> financeText = readLimited(zip, MAX_JSON).toString(Charsets.UTF_8)
                        name == INDEX -> indexText = readLimited(zip, MAX_JSON).toString(Charsets.UTF_8)
                        name.startsWith(FOLDER) -> {
                            val simple = name.removePrefix(FOLDER)
                            // Nada de subpastas nem "..": o nome precisa ser um arquivo simples.
                            if (simple.isEmpty() || simple.contains('/') || simple.contains('\\') || simple.contains("..")) continue
                            val target = File(filesDir, simple)
                            var size = 0L
                            FileOutputStream(target).use { fos ->
                                val buffer = ByteArray(32 * 1024)
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    size += n; total += n
                                    if (size > MAX_FILE || total > MAX_TOTAL) throw IOException("backup grande demais")
                                    fos.write(buffer, 0, n)
                                }
                            }
                        }
                    }
                }
            }
            val finance = financeText
            val index = indexText
            if (finance == null && index == null) throw IOException("não é um backup do app")

            // Valida tudo antes de mudar qualquer dado.
            val indexArray: JSONArray? = index?.let { text ->
                JSONArray(text).also { a -> for (i in 0 until a.length()) Receipt.fromJson(a.getJSONObject(i)) }
            }
            if (finance != null) JSONObject(finance)

            val txCount = if (finance != null) FinanceStore.restore(finance) else 0
            val receiptCount = if (indexArray != null) ReceiptStore.restoreMerge(indexArray, filesDir) else 0
            return "Backup restaurado: $txCount movimentação(ões) e $receiptCount comprovante(s)."
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun readLimited(input: InputStream, max: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(32 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            total += n
            if (total > max) throw IOException("arquivo grande demais")
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }
}
