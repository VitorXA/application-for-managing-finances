package app.comprovantes.pix

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.WindowManager

/** Bloqueio opcional do app usando a tela de bloqueio do próprio aparelho (PIN, padrão, senha ou biometria). */
object AppLock {
    private const val PREFS = "settings"
    private const val KEY = "lock_enabled"
    const val REQUEST = 4242
    private const val TIMEOUT_MS = 30_000L
    private const val NEVER = -1_000_000L

    @Volatile var lastActive = NEVER

    fun enabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun setEnabled(context: Context, value: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, value).apply()
        if (value) lastActive = SystemClock.elapsedRealtime()
    }

    fun available(context: Context): Boolean =
        (context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.isDeviceSecure == true

    fun needsUnlock(context: Context): Boolean =
        enabled(context) && available(context) && SystemClock.elapsedRealtime() - lastActive > TIMEOUT_MS

    fun reset() { lastActive = NEVER }
}

/** Base de todas as telas: aplica o bloqueio e impede capturas de tela quando ele está ligado. */
abstract class BaseActivity : Activity() {
    private var unlocking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (AppLock.enabled(this)) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onResume() {
        super.onResume()
        val content = findViewById<View>(android.R.id.content)
        if (!unlocking && AppLock.needsUnlock(this)) {
            content?.visibility = View.INVISIBLE
            requestUnlock()
        } else if (!unlocking) {
            content?.visibility = View.VISIBLE
        }
    }

    override fun onPause() {
        super.onPause()
        AppLock.lastActive = SystemClock.elapsedRealtime()
    }

    @Suppress("DEPRECATION")
    private fun requestUnlock() {
        val manager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val intent: Intent? = manager.createConfirmDeviceCredentialIntent("Meu Financeiro", "Confirme para abrir seus dados financeiros")
        if (intent == null) { findViewById<View>(android.R.id.content)?.visibility = View.VISIBLE; return }
        unlocking = true
        startActivityForResult(intent, AppLock.REQUEST)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == AppLock.REQUEST) {
            unlocking = false
            if (resultCode == RESULT_OK) {
                AppLock.lastActive = SystemClock.elapsedRealtime()
                findViewById<View>(android.R.id.content)?.visibility = View.VISIBLE
            } else {
                AppLock.reset()
                finishAffinity()
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}
