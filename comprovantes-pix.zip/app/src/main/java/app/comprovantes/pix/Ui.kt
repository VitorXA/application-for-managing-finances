package app.comprovantes.pix

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sistema de design compartilhado: cores, cartões, botões, chips e estados vazios. */
object Ui {

    /** Mantém o conteúdo fora das barras do sistema (necessário com Android 15 em diante). */
    fun applyInsets(root: View) {
        val left = root.paddingLeft
        val top = root.paddingTop
        val right = root.paddingRight
        val bottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { view, insets ->
            val extra = systemInsets(insets)
            view.setPadding(left + extra[0], top + extra[1], right + extra[2], bottom + extra[3])
            insets
        }
        root.requestApplyInsets()
    }

    @Suppress("DEPRECATION")
    private fun systemInsets(insets: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val types = WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime()
            val i = insets.getInsets(types)
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            intArrayOf(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
        }
    }

    fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    fun hideKeyboard(view: View) {
        val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun formatDate(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.forLanguageTag("pt-BR")).format(Date(millis))

    fun formatSize(context: Context, bytes: Long): String = Formatter.formatShortFileSize(context, bytes)

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ formas e cores

    fun rounded(context: Context, colorRes: Int, radiusDp: Int = 12): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(context, radiusDp).toFloat()
        setColor(context.getColor(colorRes))
    }

    fun circle(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** Cor de uma cor com transparência (usada em fundos suaves de ícones e chips). */
    fun tint(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private val categoryColors = intArrayOf(R.color.cat_1, R.color.cat_2, R.color.cat_3, R.color.cat_4, R.color.cat_5, R.color.cat_6, R.color.cat_7, R.color.cat_8)

    /** Mesma categoria, mesma cor em toda a aplicação (listas, gráficos e orçamentos). */
    fun categoryColorRes(category: String): Int {
        val key = category.trim().lowercase(Locale.ROOT)
        val fixed = when (key) {
            "moradia" -> 0; "alimentação", "alimentacao" -> 1; "transporte" -> 2; "saúde", "saude" -> 3
            "educação", "educacao" -> 4; "compras" -> 5; "lazer" -> 6; "outros" -> 7
            "assinaturas" -> 4; "contas da casa", "contas fixas" -> 2; "salário", "salario" -> 0; "doações / dízimo" -> 6
            else -> -1
        }
        val index = if (fixed >= 0) fixed else (key.hashCode() and Int.MAX_VALUE) % categoryColors.size
        return categoryColors[index]
    }

    fun categoryColor(context: Context, category: String): Int = context.getColor(categoryColorRes(category))

    // ------------------------------------------------------------------ componentes

    fun button(context: Context, text: String, primary: Boolean): Button = Button(context).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        minHeight = dp(context, 40); minimumHeight = dp(context, 40)
        setPadding(dp(context, 12), 0, dp(context, 12), 0)
        setBackgroundResource(if (primary) R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        setTextColor(context.getColor(if (primary) R.color.on_primary else R.color.primary))
        stateListAnimator = null
    }

    /** Filtro em forma de pílula. */
    fun chip(context: Context, text: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(context).apply {
        this.text = text
        textSize = 13f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8))
        background = rounded(context, if (selected) R.color.primary else R.color.chip_bg, 20)
        setTextColor(context.getColor(if (selected) R.color.on_primary else R.color.text_primary))
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    /** Pequena etiqueta de status (Pendente, Comprovante...). */
    fun tag(context: Context, text: String, colorRes: Int): TextView = TextView(context).apply {
        this.text = text
        textSize = 11f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val c = context.getColor(colorRes)
        setTextColor(c)
        setPadding(dp(context, 8), dp(context, 2), dp(context, 8), dp(context, 2))
        background = GradientDrawable().apply { cornerRadius = dp(context, 10).toFloat(); setColor(tint(c, 36)) }
    }

    /** Ícone dentro de um círculo suave. */
    fun iconBadge(context: Context, iconRes: Int, sizeDp: Int = 44, color: Int = context.getColor(R.color.primary)): View {
        val image = ImageView(context).apply {
            setImageResource(iconRes)
            val pad = dp(context, sizeDp / 4)
            setPadding(pad, pad, pad, pad)
            background = circle(tint(color, 40))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        image.layoutParams = LinearLayout.LayoutParams(dp(context, sizeDp), dp(context, sizeDp))
        return image
    }

    /** Círculo com a inicial da categoria. */
    fun letterBadge(context: Context, letter: String, color: Int, sizeDp: Int = 40): TextView = TextView(context).apply {
        text = letter.uppercase(Locale.ROOT)
        gravity = Gravity.CENTER
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(color)
        background = circle(tint(color, 44))
        layoutParams = LinearLayout.LayoutParams(dp(context, sizeDp), dp(context, sizeDp))
    }

    fun emptyState(context: Context, iconRes: Int, title: String, detail: String): View = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        background = context.getDrawable(R.drawable.bg_card)
        setPadding(dp(context, 20), dp(context, 26), dp(context, 20), dp(context, 26))
        addView(iconBadge(context, iconRes, 56).also { (it.layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(context, 12) })
        addView(TextView(context).apply {
            text = title; textSize = 16f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(context.getColor(R.color.text_primary))
        })
        addView(TextView(context).apply {
            text = detail; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(context.getColor(R.color.text_secondary))
            setPadding(0, dp(context, 6), 0, 0)
        })
    }

    /** Números alinhados em colunas (mesma largura para todos os dígitos). */
    fun tabular(view: TextView): TextView { view.fontFeatureSettings = "tnum"; return view }

    fun fadeIn(view: View) {
        view.alpha = 0f
        view.animate().alpha(1f).setDuration(160).start()
    }

    fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
