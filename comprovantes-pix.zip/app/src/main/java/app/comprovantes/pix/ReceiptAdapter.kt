package app.comprovantes.pix

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class ReceiptAdapter(private val context: Context) : BaseAdapter() {

    private var data: List<Receipt> = emptyList()

    fun submit(list: List<Receipt>) {
        data = list
        notifyDataSetChanged()
    }

    override fun getCount(): Int = data.size

    override fun getItem(position: Int): Receipt = data[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_receipt, parent, false)
        val receipt = data[position]

        val title = view.findViewById<TextView>(R.id.itemTitle)
        val name = view.findViewById<TextView>(R.id.itemName)
        val meta = view.findViewById<TextView>(R.id.itemMeta)
        val icon = view.findViewById<ImageView>(R.id.itemIcon)
        val amount = view.findViewById<TextView>(R.id.itemAmount)

        val primary = context.getColor(R.color.primary)
        icon.setImageResource(if (receipt.isImage) R.drawable.ic_image else R.drawable.ic_doc)
        icon.background = Ui.circle(Ui.tint(primary, 40))

        if (receipt.description.isNotBlank()) {
            title.text = receipt.description
            name.text = receipt.displayName
            name.visibility = View.VISIBLE
        } else {
            title.text = receipt.displayName
            name.visibility = View.GONE
        }
        meta.text = receipt.formatLabel + " · " + Ui.formatDate(receipt.importedAt)

        val cents = receipt.detectedAmountCents
        if (cents != null) {
            val income = receipt.detectedDirection == "INCOME"
            val sign = if (receipt.detectedDirection == null) "" else if (income) "+ " else "− "
            amount.text = sign + FinanceDates.money(cents)
            amount.setTextColor(context.getColor(if (receipt.detectedDirection == null) R.color.text_primary else if (income) R.color.positive else R.color.danger))
            Ui.tabular(amount)
            amount.visibility = View.VISIBLE
        } else {
            amount.visibility = View.GONE
        }
        return view
    }
}
