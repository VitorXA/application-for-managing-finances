package app.comprovantes.pix

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ajustes: segurança (bloqueio do app), backup e informações. */
class SettingsActivity : BaseActivity() {
    private companion object {
        const val REQUEST_BACKUP_EXPORT = 1002
        const val REQUEST_BACKUP_IMPORT = 1003
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.background))
            isFillViewport = true; clipToPadding = false
            setPadding(Ui.dp(this@SettingsActivity, 20), Ui.dp(this@SettingsActivity, 10), Ui.dp(this@SettingsActivity, 20), Ui.dp(this@SettingsActivity, 24))
        }
        Ui.applyInsets(scroll)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(page)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(Ui.button(this, "‹ Voltar", false).apply { setOnClickListener { finish() } }, LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 42)))
        header.addView(text("Ajustes", 22, R.color.text_primary, true).apply { setPadding(Ui.dp(this@SettingsActivity, 14), 0, 0, 0) })
        page.addView(header)

        // ---- Segurança
        page.addView(section("Segurança"))
        val lockSwitch = Switch(this).apply { isChecked = AppLock.enabled(this@SettingsActivity) }
        val lockRow = row(R.drawable.ic_lock, "Bloquear o app", "Pede o PIN, padrão ou biometria do aparelho ao abrir. Também impede capturas de tela.", lockSwitch)
        lockRow.setOnClickListener { lockSwitch.toggle() }
        lockSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked && !AppLock.available(this)) {
                lockSwitch.isChecked = false
                Ui.toast(this, "Defina um PIN, padrão ou biometria nas configurações do aparelho para usar o bloqueio.")
                return@setOnCheckedChangeListener
            }
            AppLock.setEnabled(this, checked)
            if (checked) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        page.addView(lockRow, cardParams())

        // ---- Dados
        page.addView(section("Seus dados"))
        page.addView(row(R.drawable.ic_backup, "Exportar backup", "Gera um .zip com movimentações, planilhas, orçamentos, contas fixas e comprovantes.", null).apply {
            setOnClickListener { startBackupExport() }
        }, cardParams())
        page.addView(row(R.drawable.ic_note_add, "Restaurar backup", "Substitui os dados financeiros pelos do arquivo e acrescenta os comprovantes.", null).apply {
            setOnClickListener { confirmRestore() }
        }, cardParams())
        page.addView(text("Os dados ficam só neste aparelho. Guarde o backup fora dele (Drive, e-mail ou outro).", 12, R.color.text_secondary, false).apply {
            setPadding(Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 8), Ui.dp(this@SettingsActivity, 4), 0)
        })

        // ---- Sobre
        page.addView(section("Sobre"))
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        page.addView(row(R.drawable.ic_doc, "Meu Financeiro $version", "Sem login, sem conexão bancária e sem envio de dados. A leitura dos comprovantes (OCR) acontece no aparelho.", null), cardParams())
        setContentView(scroll)
    }

    private fun cardParams() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SettingsActivity, 8) }

    private fun section(title: String): TextView = text(title.uppercase(Locale.ROOT), 12, R.color.text_secondary, true).apply {
        letterSpacing = 0.08f
        setPadding(Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 22), 0, 0)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(getColor(color))
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun row(icon: Int, title: String, subtitle: String, trailing: View?): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.bg_card)
            isClickable = true; isFocusable = true
            setPadding(Ui.dp(this@SettingsActivity, 14), Ui.dp(this@SettingsActivity, 14), Ui.dp(this@SettingsActivity, 14), Ui.dp(this@SettingsActivity, 14))
        }
        row.addView(Ui.iconBadge(this, icon, 44))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(text(title, 15, R.color.text_primary, true))
        info.addView(text(subtitle, 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SettingsActivity, 3), 0, 0) })
        row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = Ui.dp(this@SettingsActivity, 12); marginEnd = Ui.dp(this@SettingsActivity, 8) })
        if (trailing != null) row.addView(trailing)
        return row
    }

    // ------------------------------------------------------------------ backup

    @Suppress("DEPRECATION")
    private fun startBackupExport() {
        val name = "meu-financeiro-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.ROOT).format(Date()) + ".zip"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"; putExtra(Intent.EXTRA_TITLE, name)
        }
        try { startActivityForResult(intent, REQUEST_BACKUP_EXPORT) } catch (_: ActivityNotFoundException) { Ui.toast(this, getString(R.string.picker_missing)) }
    }

    private fun confirmRestore() {
        AlertDialog.Builder(this).setTitle("Restaurar backup?")
            .setMessage("Os dados financeiros atuais serão substituídos pelos do backup (uma cópia de segurança do arquivo atual é guardada). Os comprovantes do backup são adicionados aos que já existem.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Escolher arquivo") { _, _ -> startBackupImport() }.show()
    }

    @Suppress("DEPRECATION")
    private fun startBackupImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        try { startActivityForResult(intent, REQUEST_BACKUP_IMPORT) } catch (_: ActivityNotFoundException) { Ui.toast(this, getString(R.string.picker_missing)) }
    }

    private fun runBackupExport(uri: Uri) {
        Ui.toast(this, "Gerando backup…")
        Thread {
            val message = try {
                (contentResolver.openOutputStream(uri) ?: throw IOException("sem saída")).use { BackupManager.export(this, it) }
                "Backup salvo."
            } catch (_: Exception) { "Não foi possível salvar o backup." }
            runOnUiThread { if (!isDestroyed) Ui.toast(this, message) }
        }.start()
    }

    private fun runBackupImport(uri: Uri) {
        Ui.toast(this, "Restaurando backup…")
        Thread {
            val message = try {
                (contentResolver.openInputStream(uri) ?: throw IOException("sem entrada")).use { BackupManager.restore(this, it) }
            } catch (_: Exception) { "Arquivo de backup inválido ou incompleto. Nada foi alterado." }
            runOnUiThread { if (!isDestroyed) Ui.toast(this, message) }
        }.start()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQUEST_BACKUP_EXPORT -> runBackupExport(uri)
            REQUEST_BACKUP_IMPORT -> runBackupImport(uri)
        }
    }
}
