package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.io.File
import java.io.IOException

class DetailActivity : BaseActivity() {

    companion object {
        const val EXTRA_ID = "receipt_id"
    }

    private var receipt: Receipt? = null

    private lateinit var titleText: TextView
    private lateinit var previewImage: ImageView
    private lateinit var previewText: TextView
    private lateinit var messageText: TextView
    private lateinit var infoText: TextView
    private lateinit var registerButton: Button
    private lateinit var recognizedTextButton: Button
    private lateinit var openButton: Button
    private lateinit var editButton: Button
    private lateinit var deleteButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        Ui.applyInsets(findViewById(R.id.detailRoot))
        ReceiptStore.init(this)
        FinanceStore.init(this)

        titleText = findViewById(R.id.titleText)
        previewImage = findViewById(R.id.previewImage)
        previewText = findViewById(R.id.previewText)
        messageText = findViewById(R.id.messageText)
        infoText = findViewById(R.id.infoText)
        registerButton = findViewById(R.id.registerButton)
        recognizedTextButton = findViewById(R.id.recognizedTextButton)
        openButton = findViewById(R.id.openButton)
        editButton = findViewById(R.id.editButton)
        deleteButton = findViewById(R.id.deleteButton)

        val id = intent.getStringExtra(EXTRA_ID)
        val found = if (id != null) ReceiptStore.find(id) else null
        if (found == null) {
            Ui.toast(this, getString(R.string.receipt_not_found))
            finish()
            return
        }
        receipt = found

        registerButton.setOnClickListener { receipt?.let { analyzeAndRegister(it) } }
        recognizedTextButton.setOnClickListener { receipt?.let { showRecognizedText(it.recognizedText) } }
        openButton.setOnClickListener { receipt?.let { openExternally(it) } }
        editButton.setOnClickListener { receipt?.let { editDescription(it) } }
        deleteButton.setOnClickListener { receipt?.let { confirmDelete(it) } }

        bind(found)
        loadPreview(found)
    }

    private fun bind(r: Receipt) {
        titleText.text = if (r.description.isNotBlank()) r.description else r.displayName
        val file = ReceiptStore.fileOf(r)
        openButton.isEnabled = file.exists()

        val lines = mutableListOf(
            getString(R.string.label_name) to r.displayName,
            getString(R.string.label_description) to (if (r.description.isNotBlank()) r.description else getString(R.string.no_description)),
            getString(R.string.label_format) to r.formatLabel,
            getString(R.string.label_imported) to Ui.formatDate(r.importedAt),
            getString(R.string.label_size) to Ui.formatSize(this, r.sizeBytes)
        )
        if (r.detectedAmountCents != null) lines.add("Valor identificado" to FinanceDates.money(r.detectedAmountCents))
        if (r.detectedDirection != null) lines.add("Tipo identificado" to if (r.detectedDirection == "INCOME") "Entrada" else "Saída")
        if (r.detectedDate != null) lines.add("Data do comprovante" to FinanceDates.display(r.detectedDate))
        if (r.detectedCategory.isNotBlank() && r.detectedCategory != "Outros") lines.add("Categoria sugerida" to r.detectedCategory)
        if (!r.detectedCounterparty.isNullOrBlank()) lines.add("Pessoa/empresa possível" to r.detectedCounterparty)
        val linked = FinanceStore.allTransactions().firstOrNull { it.receiptId == r.id }
        if (linked != null) {
            lines.add("Movimentação registrada" to if (linked.type == "INCOME") "Entrada · ${FinanceDates.money(linked.amountCents)}" else "Saída · ${FinanceDates.money(linked.amountCents)}")
            lines.add("Descrição financeira" to linked.description)
            lines.add("Data / conta" to "${FinanceDates.display(linked.date)} · ${linked.account}")
        }
        infoText.text = lines.joinToString("\n") { it.first + ": " + it.second }
        registerButton.visibility = if (linked == null && file.exists()) View.VISIBLE else View.GONE
        registerButton.text = if (r.detectedAmountCents != null && r.detectedDirection != null) "Revisar e registrar no financeiro" else "Ler comprovante e registrar"
        recognizedTextButton.visibility = if (r.recognizedText.isNotBlank()) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        val id = receipt?.id ?: return
        ReceiptStore.find(id)?.let { updated -> receipt = updated; bind(updated) }
    }

    private fun showRecognizedText(raw: String) {
        val text = TextView(this).apply {
            this.text = raw.ifBlank { "Nenhum texto reconhecido foi armazenado." }
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
            setPadding(Ui.dp(this@DetailActivity, 18), Ui.dp(this@DetailActivity, 10), Ui.dp(this@DetailActivity, 18), Ui.dp(this@DetailActivity, 10))
            textIsSelectable = true
        }
        val scroll = android.widget.ScrollView(this).apply { addView(text) }
        AlertDialog.Builder(this).setTitle("Texto reconhecido").setView(scroll).setPositiveButton("Fechar", null).show()
    }

    private fun analyzeAndRegister(r: Receipt) {
        if (!ReceiptStore.fileOf(r).exists()) {
            Ui.toast(this, getString(R.string.file_missing))
            return
        }
        val uri = ReceiptProvider.uriFor(this, r)
        val forward = Intent(this, ReceiveActivity::class.java).apply {
            action = Intent.ACTION_SEND
            type = r.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(ReceiveActivity.EXTRA_EXISTING_RECEIPT_ID, r.id)
            clipData = ClipData.newRawUri(r.displayName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(forward)
    }

    private fun loadPreview(r: Receipt) {
        val file = ReceiptStore.fileOf(r)
        if (!file.exists()) {
            messageText.setText(R.string.file_missing)
            return
        }
        Thread {
            var bitmap: Bitmap? = null
            var text: String? = null
            try {
                when {
                    r.isImage -> bitmap = decodeImage(file)
                    r.isPdf -> bitmap = renderPdf(file)
                    r.isText -> text = readText(file)
                }
            } catch (e: Exception) {
                bitmap = null
                text = null
            } catch (e: OutOfMemoryError) {
                bitmap = null
                text = null
            }
            val finalBitmap = bitmap
            val finalText = text
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                when {
                    finalBitmap != null -> {
                        previewImage.setImageBitmap(finalBitmap)
                        previewImage.visibility = View.VISIBLE
                        messageText.visibility = View.GONE
                    }
                    finalText != null -> {
                        previewText.text = finalText
                        previewText.visibility = View.VISIBLE
                        messageText.visibility = View.GONE
                    }
                    else -> messageText.setText(R.string.preview_failed)
                }
            }
        }.start()
    }

    private fun decodeImage(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    /** Mostra a primeira página do PDF. */
    private fun renderPdf(file: File): Bitmap {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val renderer = PdfRenderer(pfd)
            try {
                if (renderer.pageCount == 0) throw IOException("PDF sem páginas")
                val page = renderer.openPage(0)
                try {
                    val scale = minOf(1080f / page.width, 4096f / page.height)
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                } finally {
                    page.close()
                }
            } finally {
                renderer.close()
            }
        } finally {
            pfd.close()
        }
    }

    private fun readText(file: File): String {
        val reader = file.bufferedReader(Charsets.UTF_8)
        try {
            val buffer = CharArray(20000)
            val n = reader.read(buffer)
            return if (n > 0) String(buffer, 0, n) else ""
        } finally {
            reader.close()
        }
    }

    private fun openExternally(r: Receipt) {
        if (!ReceiptStore.fileOf(r).exists()) {
            Ui.toast(this, getString(R.string.file_missing))
            return
        }
        val uri = ReceiptProvider.uriFor(this, r)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, r.mimeType)
            clipData = ClipData.newRawUri(null, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(view, getString(R.string.open_with)))
        } catch (e: ActivityNotFoundException) {
            Ui.toast(this, getString(R.string.no_viewer))
        }
    }

    private fun editDescription(r: Receipt) {
        val input = EditText(this).apply {
            setText(r.description)
            setSelection(text.length)
            hint = getString(R.string.description_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            filters = arrayOf(InputFilter.LengthFilter(200))
        }
        val container = FrameLayout(this).apply {
            val horizontal = Ui.dp(this@DetailActivity, 20)
            setPadding(horizontal, Ui.dp(this@DetailActivity, 8), horizontal, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.edit_description)
            .setView(container)
            .setPositiveButton(R.string.save) { _, _ ->
                saveDescription(r, input.text.toString().trim())
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun saveDescription(r: Receipt, description: String) {
        try {
            val updated = ReceiptStore.updateDescription(r.id, description)
            receipt = updated
            bind(updated)
            Ui.toast(this, getString(R.string.description_saved))
        } catch (e: Exception) {
            Ui.toast(this, getString(R.string.description_save_failed))
        }
    }

    private fun confirmDelete(r: Receipt) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(R.string.delete_message)
            .setPositiveButton(R.string.delete_receipt) { _, _ -> performDelete(r) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun performDelete(r: Receipt) {
        try {
            ReceiptStore.delete(r.id)
            Ui.toast(this, getString(R.string.deleted))
            finish()
        } catch (e: Exception) {
            Ui.toast(this, getString(R.string.delete_failed))
        }
    }
}
