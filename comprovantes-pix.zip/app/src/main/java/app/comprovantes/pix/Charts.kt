package app.comprovantes.pix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.max

/** Rosca de proporções (ex.: gastos por categoria). Cada fatia: valor e cor. */
class DonutView(context: Context) : View(context) {
    var slices: List<Pair<Long, Int>> = emptyList()
        set(value) { field = value; invalidate() }
    var centerTop: String = ""
    var centerBottom: String = ""

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val topPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val bottomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val oval = RectF()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = Ui.dp(context, 190)
        setMeasuredDimension(resolveSize(Ui.dp(context, 190), widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val d = context.resources.displayMetrics.density
        val stroke = 22f * d
        val size = minOf(width, height) - stroke - 8f * d
        val cx = width / 2f
        val cy = height / 2f
        oval.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2)
        trackPaint.strokeWidth = stroke
        trackPaint.color = context.getColor(R.color.stroke)
        canvas.drawArc(oval, 0f, 360f, false, trackPaint)
        val total = slices.sumOf { it.first }.toFloat()
        if (total > 0f) {
            arcPaint.strokeWidth = stroke
            var start = -90f
            val gap = if (slices.size > 1) 2f else 0f
            slices.forEach { (value, color) ->
                val sweep = value / total * 360f
                arcPaint.color = color
                canvas.drawArc(oval, start + gap / 2, max(sweep - gap, 0.5f), false, arcPaint)
                start += sweep
            }
        }
        topPaint.textSize = 18f * d; topPaint.color = context.getColor(R.color.text_primary)
        bottomPaint.textSize = 12f * d; bottomPaint.color = context.getColor(R.color.text_secondary)
        canvas.drawText(centerTop, cx, cy + 2f * d, topPaint)
        canvas.drawText(centerBottom, cx, cy + 20f * d, bottomPaint)
    }
}

/** Barras agrupadas por período: entradas e saídas lado a lado. */
class BarsView(context: Context) : View(context) {
    data class Group(val label: String, val income: Long, val expense: Long)

    var groups: List<Group> = emptyList()
        set(value) { field = value; invalidate() }

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val gridPaint = Paint().apply { strokeWidth = 1f }
    private val rect = RectF()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(resolveSize(Ui.dp(context, 200), widthMeasureSpec), resolveSize(Ui.dp(context, 170), heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        if (groups.isEmpty()) return
        val d = context.resources.displayMetrics.density
        val labelHeight = 22f * d
        val top = 8f * d
        val chartBottom = height - labelHeight
        val chartHeight = chartBottom - top
        val maxValue = max(groups.maxOf { max(it.income, it.expense) }, 1L).toFloat()
        gridPaint.color = context.getColor(R.color.stroke)
        canvas.drawLine(0f, chartBottom, width.toFloat(), chartBottom, gridPaint)
        canvas.drawLine(0f, top, width.toFloat(), top, gridPaint)
        val slot = width / groups.size.toFloat()
        val barWidth = minOf(slot * 0.28f, 18f * d)
        val radius = 4f * d
        labelPaint.textSize = 11f * d
        labelPaint.color = context.getColor(R.color.text_secondary)
        groups.forEachIndexed { i, g ->
            val center = slot * i + slot / 2f
            fun bar(value: Long, left: Float, color: Int) {
                val h = if (value <= 0L) 0f else max(value / maxValue * chartHeight, 3f * d)
                if (h <= 0f) return
                barPaint.color = color
                rect.set(left, chartBottom - h, left + barWidth, chartBottom)
                canvas.drawRoundRect(rect, radius, radius, barPaint)
            }
            bar(g.income, center - barWidth - 1.5f * d, context.getColor(R.color.positive))
            bar(g.expense, center + 1.5f * d, context.getColor(R.color.danger))
            canvas.drawText(g.label, center, height - 6f * d, labelPaint)
        }
    }
}
