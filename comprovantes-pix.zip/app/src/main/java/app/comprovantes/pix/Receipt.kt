package app.comprovantes.pix

import org.json.JSONObject
import java.util.Locale

/** Metadados de um comprovante salvo. O arquivo fica em filesDir/receipts/[storedName]. */
data class Receipt(
    val id: String,
    val displayName: String,
    val storedName: String,
    val mimeType: String,
    val importedAt: Long,
    val sizeBytes: Long,
    val description: String,
    val recognizedText: String = "",
    val detectedAmountCents: Long? = null,
    val detectedDate: String? = null,
    val detectedDirection: String? = null,
    val detectedCategory: String = "Outros",
    val detectedCounterparty: String? = null,
    val contentHash: String = ""
) {
    val isImage: Boolean get() = mimeType.startsWith("image/")
    val isPdf: Boolean get() = mimeType == "application/pdf"
    val isText: Boolean get() = mimeType == "text/plain"
    val formatLabel: String get() = labelFor(mimeType)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("displayName", displayName)
        put("storedName", storedName)
        put("mimeType", mimeType)
        put("importedAt", importedAt)
        put("sizeBytes", sizeBytes)
        put("description", description)
        put("recognizedText", recognizedText)
        if (detectedAmountCents != null) put("detectedAmountCents", detectedAmountCents)
        if (detectedDate != null) put("detectedDate", detectedDate)
        if (detectedDirection != null) put("detectedDirection", detectedDirection)
        put("detectedCategory", detectedCategory)
        if (detectedCounterparty != null) put("detectedCounterparty", detectedCounterparty)
        if (contentHash.isNotEmpty()) put("contentHash", contentHash)
    }

    companion object {
        fun fromJson(o: JSONObject): Receipt = Receipt(
            id = o.getString("id"),
            displayName = o.getString("displayName"),
            storedName = o.getString("storedName"),
            mimeType = o.getString("mimeType"),
            importedAt = o.getLong("importedAt"),
            sizeBytes = o.optLong("sizeBytes", 0L),
            description = o.optString("description", ""),
            recognizedText = o.optString("recognizedText", ""),
            detectedAmountCents = if (o.has("detectedAmountCents") && !o.isNull("detectedAmountCents")) o.optLong("detectedAmountCents") else null,
            detectedDate = o.optString("detectedDate", "").takeIf { it.isNotBlank() },
            detectedDirection = o.optString("detectedDirection", "").takeIf { it == "INCOME" || it == "EXPENSE" },
            detectedCategory = o.optString("detectedCategory", "Outros"),
            detectedCounterparty = o.optString("detectedCounterparty", "").takeIf { it.isNotBlank() },
            contentHash = o.optString("contentHash", "")
        )

        fun labelFor(mime: String?): String = when {
            mime == null -> "?"
            mime == "application/pdf" -> "PDF"
            mime == "image/png" -> "PNG"
            mime == "image/jpeg" -> "JPEG"
            mime.startsWith("image/") -> mime.substringAfter('/').uppercase(Locale.ROOT)
            mime == "text/plain" -> "Texto"
            else -> mime
        }
    }
}
