package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class FinanceActivity : Activity() {
    companion object {
        const val EXTRA_SCREEN = "finance_screen"
        const val SCREEN_TRANSACTIONS = "transactions"
        const val SCREEN_CALENDAR = "calendar"
    }

    private lateinit var contentHost: FrameLayout
    private lateinit var transactionTab: Button
    private lateinit var calendarTab: Button
    private var currentScreen = SCREEN_TRANSACTIONS
    private var periodMode = "Mês"
    private var periodAnchor = Calendar.getInstance()
    private var calendarMode = "Mês"
    private var calendarAnchor = Calendar.getInstance()
    private var selectedDate = FinanceDates.today()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FinanceStore.init(this)
        ReceiptStore.init(this)
        val requested = intent.getStringExtra(EXTRA_SCREEN) ?: SCREEN_TRANSACTIONS
        currentScreen = requested

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background))
            setPadding(Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 8), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 8))
        }
        Ui.applyInsets(root)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = makeButton("‹ Voltar", false).apply { setOnClickListener { finish() } }
        header.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 42)))
        val title = label("Finanças", 21, R.color.text_primary, true)
        title.gravity = Gravity.CENTER_VERTICAL
        header.addView(title, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f))
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, Ui.dp(this@FinanceActivity, 7), 0, Ui.dp(this@FinanceActivity, 7)) }
        transactionTab = makeButton("Movimentações", false)
        calendarTab = makeButton("Calendário", false)
        tabs.addView(transactionTab, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { rightMargin = Ui.dp(this@FinanceActivity, 4) })
        tabs.addView(calendarTab, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { leftMargin = Ui.dp(this@FinanceActivity, 4) })
        root.addView(tabs)
        transactionTab.setOnClickListener { currentScreen = SCREEN_TRANSACTIONS; render() }
        calendarTab.setOnClickListener { currentScreen = SCREEN_CALENDAR; render() }
        contentHost = FrameLayout(this)
        root.addView(contentHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        val transactionsSelected = currentScreen == SCREEN_TRANSACTIONS
        styleTab(transactionTab, transactionsSelected)
        styleTab(calendarTab, !transactionsSelected)
        if (transactionsSelected) showTransactions() else showCalendar()
    }

    private fun showTransactions() {
        val page = vertical()
        val controls = horizontal()
        controls.addView(makeButton("‹", false).apply { contentDescription = "Período anterior"; setOnClickListener { movePeriod(-1); showTransactions() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 42)))
        controls.addView(makeButton(periodLabel(periodMode, periodAnchor) + " ▾", false).apply {
            setOnClickListener { choosePeriodMode { mode -> periodMode = mode; showTransactions() } }
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { leftMargin = Ui.dp(this, 6); rightMargin = Ui.dp(this, 6) })
        controls.addView(makeButton("›", false).apply { contentDescription = "Próximo período"; setOnClickListener { movePeriod(1); showTransactions() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 42)))
        page.addView(controls)

        val newRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        newRow.addView(makeButton("+ Nova movimentação", true).apply { setOnClickListener { showTransactionDialog(null) } }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { rightMargin = Ui.dp(this@FinanceActivity, 4) })
        newRow.addView(makeButton("Saldo inicial", false).apply { setOnClickListener { showOpeningBalanceDialog() } }, LinearLayout.LayoutParams(Ui.dp(this, 124), Ui.dp(this, 46)).apply { leftMargin = Ui.dp(this@FinanceActivity, 4) })
        page.addView(newRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })

        val (start, end) = range(periodMode, periodAnchor)
        val listed = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end }
        val done = listed.filter { it.status == "DONE" }
        val income = done.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val expenses = done.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val summary = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 11), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 11))
        }
        summary.addView(label("Resumo do período", 14, R.color.text_secondary, false))
        val stats = horizontal()
        stats.addView(statBlock("Entradas", FinanceDates.money(income), R.color.positive), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(statBlock("Saídas", FinanceDates.money(expenses), R.color.danger), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(statBlock("Resultado", FinanceDates.money(income - expenses), R.color.text_primary), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(stats, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8) })
        page.addView(summary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8); bottomMargin = Ui.dp(this@FinanceActivity, 8) })

        if (listed.isEmpty()) {
            page.addView(emptyPanel("Nenhuma movimentação neste período.", "Toque em “Nova movimentação” para registrar uma entrada ou um gasto."))
        } else {
            val heading = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
            heading.addView(label("Movimentações", 16, R.color.text_primary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            heading.addView(label("${listed.size} registro(s)", 12, R.color.text_secondary, false))
            page.addView(heading)
            listed.sortedWith(compareByDescending<MoneyTransaction> { it.date }.thenByDescending { it.id }).forEach { tx ->
                page.addView(transactionCard(tx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })
            }
        }
        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
    }

    private fun showCalendar() {
        val page = vertical()
        val modeRow = horizontal()
        listOf("Semana", "Mês", "Ano").forEach { mode ->
            modeRow.addView(makeButton(mode, calendarMode == mode).apply {
                setOnClickListener { calendarMode = mode; selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis); showCalendar() }
            }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { rightMargin = Ui.dp(this@FinanceActivity, 3); leftMargin = Ui.dp(this@FinanceActivity, 3) })
        }
        page.addView(modeRow)
        val nav = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        nav.addView(makeButton("‹", false).apply { setOnClickListener { moveCalendar(-1); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(label(calendarLabel(), 15, R.color.text_primary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
        nav.addView(makeButton("›", false).apply { setOnClickListener { moveCalendar(1); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(makeButton("Hoje", false).apply { setOnClickListener { calendarAnchor = Calendar.getInstance(); selectedDate = FinanceDates.today(); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 40)).apply { leftMargin = Ui.dp(this@FinanceActivity, 4) })
        page.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 4); bottomMargin = Ui.dp(this@FinanceActivity, 6) })

        when (calendarMode) {
            "Semana" -> renderWeek(page)
            "Ano" -> renderYear(page)
            else -> renderMonth(page)
        }

        val dayTx = FinanceStore.allTransactions().filter { it.date == selectedDate }
        val dayDone = dayTx.filter { it.status == "DONE" }
        val dayIn = dayDone.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val dayOut = dayDone.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val selectedCard = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 10), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 10))
        }
        selectedCard.addView(label("${FinanceDates.display(selectedDate)} · ${dayTx.size} movimentação(ões)", 15, R.color.text_primary, true))
        selectedCard.addView(label("Entradas ${FinanceDates.money(dayIn)}     Saídas ${FinanceDates.money(dayOut)}", 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 4), 0, 0) })
        page.addView(selectedCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8) })
        page.addView(makeButton("+ Movimentação nesta data", false).apply { setOnClickListener { showTransactionDialog(null, selectedDate) } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)).apply { topMargin = Ui.dp(this@FinanceActivity, 5) })
        if (dayTx.isEmpty()) page.addView(label("Nenhuma movimentação nesta data.", 13, R.color.text_secondary, false).apply { setPadding(Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 10), 0, Ui.dp(this@FinanceActivity, 8)) })
        else dayTx.forEach { tx -> page.addView(transactionCard(tx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) }) }
        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
    }

    private fun renderMonth(page: LinearLayout) {
        val weekdays = horizontal()
        listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom").forEach { d ->
            weekdays.addView(label(d, 11, R.color.text_secondary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 24), 1f))
        }
        page.addView(weekdays)
        val first = (calendarAnchor.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val todayKey = FinanceDates.today()
        for (week in 0 until 6) {
            val row = horizontal()
            for (col in 0 until 7) {
                val n = week * 7 + col - offset + 1
                if (n in 1..days) {
                    val cal = (first.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, n) }
                    val key = FinanceDates.dateForMillis(cal.timeInMillis)
                    val has = FinanceStore.allTransactions().any { it.date == key }
                    val txt = if (has) "$n\n•" else n.toString()
                    val cell = TextView(this).apply {
                        text = txt; gravity = Gravity.CENTER; textSize = 12f
                        setTextColor(getColor(if (key == selectedDate) R.color.on_primary else R.color.text_primary))
                        if (key == selectedDate) background = rounded(R.color.primary) else if (key == todayKey) background = rounded(R.color.stroke)
                        isClickable = true; isFocusable = true
                        setOnClickListener { selectedDate = key; showCalendar() }
                    }
                    row.addView(cell, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { setMargins(Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1)) })
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
                }
            }
            page.addView(row)
            if (week * 7 - offset + 1 > days) break
        }
    }

    private fun renderWeek(page: LinearLayout) {
        val start = (calendarAnchor.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }
        val dayLabel = java.text.SimpleDateFormat("EEE dd/MM", Locale.forLanguageTag("pt-BR"))
        for (i in 0..6) {
            val day = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
            val key = FinanceDates.dateForMillis(day.timeInMillis)
            val txs = FinanceStore.allTransactions().filter { it.date == key }
            val total = txs.filter { it.status == "DONE" }.sumOf { if (it.type == "INCOME") it.amountCents else -it.amountCents }
            val b = makeButton("${dayLabel.format(day.time).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}     ${if (txs.isEmpty()) "" else FinanceDates.money(total)}", key == selectedDate)
            b.gravity = Gravity.CENTER_VERTICAL
            b.setOnClickListener { selectedDate = key; showCalendar() }
            page.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 42)).apply { topMargin = Ui.dp(this@FinanceActivity, 3) })
        }
    }

    private fun renderYear(page: LinearLayout) {
        val grid = GridLayout(this).apply { columnCount = 3; rowCount = 4 }
        val year = calendarAnchor.get(Calendar.YEAR)
        for (month in 0..11) {
            val cal = (calendarAnchor.clone() as Calendar).apply { set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, 1) }
            val start = FinanceDates.dateForMillis(cal.timeInMillis)
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
            val end = FinanceDates.dateForMillis(cal.timeInMillis)
            val tx = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end && it.status == "DONE" }
            val spent = tx.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
            val b = makeButton("${FinanceDates.monthShort((calendarAnchor.clone() as Calendar).apply { set(Calendar.MONTH, month) })}\n${FinanceDates.money(spent)}", false)
            b.textSize = 12f
            b.setOnClickListener {
                calendarAnchor = (calendarAnchor.clone() as Calendar).apply { set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, 1) }
                calendarMode = "Mês"; selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis); showCalendar()
            }
            val lp = GridLayout.LayoutParams().apply { width = 0; height = Ui.dp(this@FinanceActivity, 72); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2)) }
            grid.addView(b, lp)
        }
        page.addView(grid)
    }

    private fun showTransactionDialog(existing: MoneyTransaction?, initialDate: String? = null) {
        val form = vertical().apply { setPadding(Ui.dp(this@FinanceActivity, 6), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 6), Ui.dp(this@FinanceActivity, 2)) }
        val typeSpinner = spinner(listOf("Despesa", "Receita"), if (existing?.type == "INCOME") 1 else 0)
        form.addView(label("Tipo", 13, R.color.text_secondary, false)); form.addView(typeSpinner)
        val desc = editField("Ex.: Supermercado", existing?.description.orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Descrição", 13, R.color.text_secondary, false)); form.addView(desc)
        val amount = editField("0,00", if (existing == null) "" else String.format(Locale.forLanguageTag("pt-BR"), "%.2f", existing.amountCents / 100.0), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        form.addView(label("Valor (R$)", 13, R.color.text_secondary, false)); form.addView(amount)
        val category = editField("Ex.: Alimentação", existing?.category ?: "Outros", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Categoria", 13, R.color.text_secondary, false)); form.addView(category)
        val statusSpinner = spinner(listOf("Efetivada", "Pendente"), if (existing?.status == "PENDING") 1 else 0)
        form.addView(label("Situação", 13, R.color.text_secondary, false)); form.addView(statusSpinner)
        var dateKey = existing?.date ?: initialDate ?: FinanceDates.today()
        val dateButton = makeButton("Data: ${FinanceDates.display(dateKey)}", false)
        dateButton.setOnClickListener {
            val c = FinanceDates.calendarFor(dateKey)
            DatePickerDialog(this, { _, y, m, d ->
                val selected = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }
                dateKey = FinanceDates.dateForMillis(selected.timeInMillis)
                dateButton.text = "Data: ${FinanceDates.display(dateKey)}"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        form.addView(label("Data", 13, R.color.text_secondary, false)); form.addView(dateButton)
        val receiptItems = ReceiptStore.list()
        val receiptOptions = listOf("Sem comprovante") + receiptItems.map { if (it.description.isNotBlank()) it.description else it.displayName }
        val receiptSpinner = spinner(receiptOptions, (receiptItems.indexOfFirst { it.id == existing?.receiptId } + 1).coerceAtLeast(0))
        form.addView(label("Comprovante (opcional)", 13, R.color.text_secondary, false)); form.addView(receiptSpinner)

        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Nova movimentação" else "Editar movimentação")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("Salvar", null).setNegativeButton("Cancelar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val description = desc.text.toString().trim()
                val cents = FinanceDates.parseCents(amount.text.toString())
                if (description.isBlank()) { desc.error = "Informe uma descrição"; return@setOnClickListener }
                if (cents == null || cents <= 0) { amount.error = "Informe um valor maior que zero"; return@setOnClickListener }
                val tx = existing ?: MoneyTransaction(type = "EXPENSE", description = "", amountCents = 0, date = dateKey, category = "Outros")
                tx.type = if (typeSpinner.selectedItemPosition == 1) "INCOME" else "EXPENSE"
                tx.description = description; tx.amountCents = cents; tx.date = dateKey
                tx.category = category.text.toString().trim().ifBlank { "Outros" }
                tx.status = if (statusSpinner.selectedItemPosition == 1) "PENDING" else "DONE"
                tx.receiptId = receiptItems.getOrNull(receiptSpinner.selectedItemPosition - 1)?.id
                try { FinanceStore.saveTransaction(tx); dialog.dismiss(); showTransactions(); Ui.toast(this, "Movimentação salva") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível salvar. Tente novamente.") }
            }
        }
        dialog.show()
    }

    private fun showOpeningBalanceDialog() {
        val input = editField("0,00", String.format(Locale.forLanguageTag("pt-BR"), "%.2f", FinanceStore.openingBalance() / 100.0), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        AlertDialog.Builder(this).setTitle("Saldo inicial")
            .setMessage("Informe o saldo que você já tinha antes das movimentações registradas.")
            .setView(input).setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val cents = FinanceDates.parseCents(input.text.toString())
                if (cents == null) Ui.toast(this, "Informe um valor válido") else try { FinanceStore.setOpeningBalance(cents); showTransactions() } catch (_: Exception) { Ui.toast(this, "Não foi possível salvar o saldo") }
            }.show()
    }

    private fun transactionCard(tx: MoneyTransaction): View {
        val card = horizontal().apply {
            background = getDrawable(R.drawable.bg_card)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 9), Ui.dp(this@FinanceActivity, 10), Ui.dp(this@FinanceActivity, 9))
            isClickable = true
            setOnClickListener { showTransactionActions(tx) }
        }
        val info = vertical()
        info.addView(label(tx.description, 14, R.color.text_primary, true))
        val status = if (tx.status == "PENDING") " · Pendente" else ""
        val receipt = if (tx.receiptId != null && ReceiptStore.find(tx.receiptId!!) != null) " · Comprovante" else ""
        info.addView(label("${tx.category} · ${FinanceDates.display(tx.date)}$status$receipt", 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 3), 0, 0) })
        card.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val amount = label((if (tx.type == "INCOME") "+ " else "− ") + FinanceDates.money(tx.amountCents), 14, if (tx.type == "INCOME") R.color.positive else R.color.danger, true)
        amount.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        card.addView(amount)
        return card
    }

    private fun showTransactionActions(tx: MoneyTransaction) {
        val linkedReceipt = tx.receiptId?.let { ReceiptStore.find(it) }
        val options = if (linkedReceipt != null) arrayOf("Editar", "Abrir comprovante", "Excluir") else arrayOf("Editar", "Excluir")
        AlertDialog.Builder(this).setTitle(tx.description).setItems(options) { _, which ->
            when {
                which == 0 -> showTransactionDialog(tx.copy())
                linkedReceipt != null && which == 1 -> startActivity(Intent(this, DetailActivity::class.java).putExtra(DetailActivity.EXTRA_ID, linkedReceipt.id))
                else -> AlertDialog.Builder(this).setTitle("Excluir movimentação?").setMessage("Essa ação não pode ser desfeita.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                        try { FinanceStore.deleteTransaction(tx.id); showTransactions(); Ui.toast(this, "Movimentação excluída") }
                        catch (_: Exception) { Ui.toast(this, "Não foi possível excluir") }
                    }.show()
            }
        }.show()
    }

    private fun choosePeriodMode(onSelected: (String) -> Unit) {
        val options = arrayOf("Semana", "Mês", "Ano")
        AlertDialog.Builder(this).setTitle("Filtrar por período")
            .setSingleChoiceItems(options, options.indexOf(periodMode).coerceAtLeast(0)) { dialog, which -> onSelected(options[which]); dialog.dismiss() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun movePeriod(delta: Int) {
        when (periodMode) { "Semana" -> periodAnchor.add(Calendar.WEEK_OF_YEAR, delta); "Ano" -> periodAnchor.add(Calendar.YEAR, delta); else -> periodAnchor.add(Calendar.MONTH, delta) }
    }

    private fun range(mode: String, anchor: Calendar): Pair<String, String> {
        val start = (anchor.clone() as Calendar); val end = (anchor.clone() as Calendar)
        when (mode) {
            "Semana" -> {
                val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7
                start.add(Calendar.DAY_OF_MONTH, -offset)
                end.timeInMillis = start.timeInMillis; end.add(Calendar.DAY_OF_MONTH, 6)
            }
            "Ano" -> { start.set(Calendar.MONTH, Calendar.JANUARY); start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun periodLabel(mode: String, anchor: Calendar): String = when (mode) {
        "Semana" -> {
            val (s, e) = range(mode, anchor); "${FinanceDates.display(s)} – ${FinanceDates.display(e)}"
        }
        "Ano" -> anchor.get(Calendar.YEAR).toString()
        else -> FinanceDates.monthLabel(anchor)
    }

    private fun calendarLabel(): String = when (calendarMode) {
        "Semana" -> { val (s, e) = range("Semana", calendarAnchor); "${FinanceDates.display(s)} – ${FinanceDates.display(e)}" }
        "Ano" -> calendarAnchor.get(Calendar.YEAR).toString()
        else -> FinanceDates.monthLabel(calendarAnchor)
    }

    private fun moveCalendar(delta: Int) {
        when (calendarMode) { "Semana" -> calendarAnchor.add(Calendar.WEEK_OF_YEAR, delta); "Ano" -> calendarAnchor.add(Calendar.YEAR, delta); else -> calendarAnchor.add(Calendar.MONTH, delta) }
        selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis)
    }

    private fun statBlock(title: String, value: String, colorRes: Int): View = vertical().apply {
        addView(label(title, 11, R.color.text_secondary, false))
        addView(label(value, 13, colorRes, true).apply { setPadding(0, Ui.dp(this@FinanceActivity, 3), 0, 0) })
    }

    private fun emptyPanel(title: String, detail: String): View = vertical().apply {
        background = getDrawable(R.drawable.bg_card)
        setPadding(Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 20), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 20))
        addView(label(title, 15, R.color.text_primary, true))
        addView(label(detail, 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 5), 0, 0) })
    }

    private fun label(textValue: String, size: Int, colorRes: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue; textSize = size.toFloat(); setTextColor(getColor(colorRes)); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun makeButton(textValue: String, primary: Boolean): Button = Button(this).apply {
        text = textValue; textSize = 13f; isAllCaps = false; minHeight = Ui.dp(this@FinanceActivity, 40); minimumHeight = Ui.dp(this@FinanceActivity, 40)
        setPadding(Ui.dp(this@FinanceActivity, 8), 0, Ui.dp(this@FinanceActivity, 8), 0)
        setBackgroundResource(if (primary) R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        setTextColor(getColor(if (primary) R.color.on_primary else R.color.primary))
        stateListAnimator = null
    }
    private fun styleTab(button: Button, active: Boolean) {
        button.setBackgroundResource(if (active) R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        button.setTextColor(getColor(if (active) R.color.on_primary else R.color.primary))
    }
    private fun editField(hintValue: String, initial: String, inputTypeValue: Int): EditText = EditText(this).apply {
        hint = hintValue; setText(initial); inputType = inputTypeValue; textSize = 15f; maxLines = 1
        setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 4))
        setBackgroundResource(R.drawable.bg_input); minimumHeight = Ui.dp(this@FinanceActivity, 44)
    }
    private fun spinner(items: List<String>, selection: Int): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@FinanceActivity, android.R.layout.simple_spinner_item, items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setSelection(selection.coerceIn(items.indices))
    }
    private fun rounded(colorRes: Int) = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = Ui.dp(this@FinanceActivity, 8).toFloat(); setColor(getColor(colorRes)) }
}
