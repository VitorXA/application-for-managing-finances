package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class FinanceActivity : BaseActivity() {
    companion object {
        const val EXTRA_SCREEN = "finance_screen"
        const val SCREEN_TRANSACTIONS = "transactions"
        const val SCREEN_CALENDAR = "calendar"
        const val SCREEN_PLAN = "planning"
    }

    private lateinit var contentHost: FrameLayout
    private lateinit var transactionTab: Button
    private lateinit var calendarTab: Button
    private lateinit var planningTab: Button
    private var currentScreen = SCREEN_TRANSACTIONS
    private var selectedAccount = "Todas as contas"
    private var periodMode = "Mês"
    private var periodAnchor = Calendar.getInstance()
    private var calendarMode = "Mês"
    private var calendarAnchor = Calendar.getInstance()
    private var selectedDate = FinanceDates.today()
    private var started = false
    private var typeFilter = "Todas"
    private var searchQuery = ""
    private var pendingCsv: String? = null
    private val createCsvRequest = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FinanceStore.init(this)
        ReceiptStore.init(this)
        val requested = intent.getStringExtra(EXTRA_SCREEN) ?: SCREEN_TRANSACTIONS
        currentScreen = requested
        if (savedInstanceState != null) {
            currentScreen = savedInstanceState.getString("screen", requested)
            periodMode = savedInstanceState.getString("periodMode", periodMode)
            calendarMode = savedInstanceState.getString("calendarMode", calendarMode)
            selectedAccount = savedInstanceState.getString("account", selectedAccount)
            selectedDate = savedInstanceState.getString("selectedDate", selectedDate)
            periodAnchor.timeInMillis = savedInstanceState.getLong("periodAnchor", periodAnchor.timeInMillis)
            calendarAnchor.timeInMillis = savedInstanceState.getLong("calendarAnchor", calendarAnchor.timeInMillis)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background))
            setPadding(Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 8), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 8))
        }
        Ui.applyInsets(root)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = makeButton("‹ Voltar", false).apply { setOnClickListener { finish() } }
        header.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 42)))
        val title = label("Finanças", 21, R.color.text_primary, true)
        title.gravity = Gravity.CENTER_VERTICAL
        header.addView(title, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f))
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(this@FinanceActivity, R.color.sage, 14)
            val p = Ui.dp(this@FinanceActivity, 4); setPadding(p, p, p, p)
        }
        transactionTab = makeButton("Movimentações", false)
        calendarTab = makeButton("Calendário", false)
        planningTab = makeButton("Planejamento", false)
        listOf(transactionTab, calendarTab, planningTab).forEachIndexed { index, button ->
            tabs.addView(button, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply {
                if (index != 0) leftMargin = Ui.dp(this@FinanceActivity, 3)
                if (index != 2) rightMargin = Ui.dp(this@FinanceActivity, 3)
            })
        }
        root.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8); bottomMargin = Ui.dp(this@FinanceActivity, 8) })
        transactionTab.setOnClickListener { currentScreen = SCREEN_TRANSACTIONS; render() }
        calendarTab.setOnClickListener { currentScreen = SCREEN_CALENDAR; render() }
        planningTab.setOnClickListener { currentScreen = SCREEN_PLAN; render() }
        contentHost = FrameLayout(this)
        root.addView(contentHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("screen", currentScreen); outState.putString("periodMode", periodMode)
        outState.putString("calendarMode", calendarMode); outState.putString("account", selectedAccount)
        outState.putString("selectedDate", selectedDate)
        outState.putLong("periodAnchor", periodAnchor.timeInMillis); outState.putLong("calendarAnchor", calendarAnchor.timeInMillis)
    }

    /** Ao voltar de outra tela (ex.: comprovante excluído), atualiza o que está na tela. */
    override fun onResume() {
        super.onResume()
        if (started) render() else started = true
    }

    private fun render() {
        styleTab(transactionTab, currentScreen == SCREEN_TRANSACTIONS)
        styleTab(calendarTab, currentScreen == SCREEN_CALENDAR)
        styleTab(planningTab, currentScreen == SCREEN_PLAN)
        when (currentScreen) {
            SCREEN_CALENDAR -> showCalendar()
            SCREEN_PLAN -> showPlanning()
            else -> showTransactions()
        }
    }

    private fun showTransactions() {
        val page = vertical()
        val controls = horizontal()
        controls.addView(makeButton("‹", false).apply { contentDescription = "Período anterior"; setOnClickListener { movePeriod(-1); showTransactions() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 42)))
        controls.addView(makeButton(periodLabel(periodMode, periodAnchor) + " ▾", false).apply {
            setOnClickListener { choosePeriodMode { mode -> periodMode = mode; showTransactions() } }
        }, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { leftMargin = Ui.dp(this@FinanceActivity, 6); rightMargin = Ui.dp(this@FinanceActivity, 6) })
        controls.addView(makeButton("›", false).apply { contentDescription = "Próximo período"; setOnClickListener { movePeriod(1); showTransactions() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 42)))
        page.addView(controls)
        page.addView(makeButton("Conta: $selectedAccount  ▾", false).apply {
            setOnClickListener {
                val options = listOf("Todas as contas") + FinanceStore.accountNames()
                AlertDialog.Builder(this@FinanceActivity).setTitle("Filtrar por conta")
                    .setSingleChoiceItems(options.toTypedArray(), options.indexOf(selectedAccount).coerceAtLeast(0)) { dialog, which ->
                        selectedAccount = options[which]; dialog.dismiss(); showTransactions()
                    }.setNegativeButton("Cancelar", null).show()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 38)).apply { topMargin = Ui.dp(this@FinanceActivity, 5) })

        val newRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        newRow.addView(makeButton("+ Nova movimentação", true).apply { setOnClickListener { showTransactionDialog(null) } }, LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f).apply { rightMargin = Ui.dp(this@FinanceActivity, 4) })
        newRow.addView(makeButton("Saldo inicial", false).apply { setOnClickListener { showOpeningBalanceDialog() } }, LinearLayout.LayoutParams(Ui.dp(this, 124), Ui.dp(this, 46)).apply { leftMargin = Ui.dp(this@FinanceActivity, 4) })
        page.addView(newRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })

        val (start, end) = range(periodMode, periodAnchor)
        val periodList = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end && (selectedAccount == "Todas as contas" || it.account.equals(selectedAccount, ignoreCase = true)) }
        val done = periodList.filter { it.status == "DONE" }
        val income = done.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val expenses = done.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val summary = vertical().apply {
            background = getDrawable(R.drawable.bg_hero)
            setPadding(Ui.dp(this@FinanceActivity, 18), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 18), Ui.dp(this@FinanceActivity, 16))
        }
        summary.addView(label("Resultado do período", 13, R.color.hero_text_dim, false))
        summary.addView(Ui.tabular(label(FinanceDates.money(income - expenses), 28, R.color.hero_text, true)).apply { setPadding(0, Ui.dp(this@FinanceActivity, 2), 0, Ui.dp(this@FinanceActivity, 12)) })
        val stats = horizontal()
        stats.addView(statBlock("↑ Entradas", FinanceDates.money(income), R.color.hero_text, R.color.hero_text_dim), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(statBlock("↓ Saídas", FinanceDates.money(expenses), R.color.hero_text, R.color.hero_text_dim), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(stats)
        page.addView(summary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 10); bottomMargin = Ui.dp(this@FinanceActivity, 10) })

        val chips = horizontal()
        listOf("Todas", "Entradas", "Saídas", "Pendentes").forEach { f ->
            chips.addView(Ui.chip(this, f, typeFilter == f) { typeFilter = f; showTransactions() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = Ui.dp(this@FinanceActivity, 8) })
        }
        page.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        val search = editField("Buscar por descrição, categoria ou conta", searchQuery, InputType.TYPE_CLASS_TEXT)
        page.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46)).apply { topMargin = Ui.dp(this@FinanceActivity, 10) })
        val listHost = vertical()
        page.addView(listHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 4) })

        fun fillList() {
            listHost.removeAllViews()
            val q = searchQuery.trim().lowercase(Locale.ROOT)
            val shown = periodList.filter { tx ->
                val typeOk = when (typeFilter) { "Entradas" -> tx.type == "INCOME"; "Saídas" -> tx.type == "EXPENSE"; "Pendentes" -> tx.status == "PENDING"; else -> true }
                typeOk && (q.isEmpty() || tx.description.lowercase(Locale.ROOT).contains(q) || tx.category.lowercase(Locale.ROOT).contains(q) || tx.account.lowercase(Locale.ROOT).contains(q))
            }
            if (shown.isEmpty()) {
                listHost.addView(
                    if (periodList.isEmpty()) Ui.emptyState(this, R.drawable.ic_swap, "Nenhuma movimentação neste período", "Toque em “Nova movimentação” para registrar uma entrada ou um gasto.")
                    else Ui.emptyState(this, R.drawable.ic_swap, "Nada encontrado", "Ajuste a busca ou o filtro."),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 10) })
                return
            }
            val heading = horizontal().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 10), 0, 0) }
            heading.addView(label("${shown.size} registro(s)", 12, R.color.text_secondary, false), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            heading.addView(makeButton("Exportar CSV", false).apply { setOnClickListener { exportTransactionsCsv(shown) } },
                LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 34)))
            listHost.addView(heading)
            shown.sortedWith(compareByDescending<MoneyTransaction> { it.date }.thenByDescending { it.id }).groupBy { it.date }.forEach { (date, items) ->
                val dayNet = items.filter { it.status == "DONE" }.sumOf { if (it.type == "INCOME") it.amountCents else -it.amountCents }
                val head = horizontal().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 14), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 2)) }
                head.addView(label(dayLabel(date), 12, R.color.text_secondary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                head.addView(Ui.tabular(label(FinanceDates.money(dayNet), 12, R.color.text_secondary, false)))
                listHost.addView(head)
                items.forEach { tx ->
                    listHost.addView(transactionCard(tx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty(); fillList() }
            override fun afterTextChanged(s: Editable?) {}
        })
        fillList()
        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
        Ui.fadeIn(contentHost)
    }

    private fun dayLabel(key: String): String {
        val base = FinanceDates.display(key)
        return when (key) {
            FinanceDates.today() -> "Hoje · $base"
            FinanceDates.dateForMillis(System.currentTimeMillis() - 86_400_000L) -> "Ontem · $base"
            else -> base
        }
    }

    private fun showPlanning() {
        val page = vertical()
        val prefs = FinanceStore.preferences()
        val plan = FinanceStore.planningSummary()
        val start = plan.startDate
        val end = plan.endDate
        val income = plan.incomeCents
        val tithe = plan.titheCents
        val fixedInCycle = plan.mandatoryDueCents
        val available = plan.availableCents
        val ratio = (plan.spendingPercent ?: 0.0).coerceAtLeast(0.0)
        val allFixed = FinanceStore.allMandatoryExpenses()

        val intro = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        val heading = vertical()
        heading.addView(label("Plano de renda", 18, R.color.text_primary, true))
        heading.addView(label(if (prefs.cycleMode == "Quinzenal") "Quinzena atual · ${FinanceDates.display(start)}–${FinanceDates.display(end)}" else FinanceDates.monthLabel(FinanceDates.calendarFor(start)), 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 2), 0, 0) })
        intro.addView(heading, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        intro.addView(makeButton("Ajustes", false).apply { setOnClickListener { showPlanningSettingsDialog() } }, LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 38)))
        page.addView(intro)

        val hero = vertical().apply {
            background = getDrawable(R.drawable.bg_hero)
            setPadding(Ui.dp(this@FinanceActivity, 18), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 18), Ui.dp(this@FinanceActivity, 16))
        }
        hero.addView(label("DISPONÍVEL APÓS DESCONTOS PLANEJADOS", 11, R.color.hero_text_dim, true))
        hero.addView(Ui.tabular(label(FinanceDates.money(available), 30, R.color.hero_text, true)).apply { setPadding(0, Ui.dp(this@FinanceActivity, 3), 0, Ui.dp(this@FinanceActivity, 4)) })
        hero.addView(label("Entrada − dízimo opcional − contas obrigatórias do período", 12, R.color.hero_text_dim, false))
        page.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 10) })

        val summary = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 11), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 11))
        }
        summary.addView(label("Distribuição da renda", 15, R.color.text_primary, true))
        summary.addView(summaryLine("Valor que entrou", FinanceDates.money(income), R.color.positive))
        val titheRateLabel = String.format(Locale.forLanguageTag("pt-BR"), "%.2f", prefs.tithePercent).trimEnd('0').trimEnd(',').trimEnd('.')
        summary.addView(summaryLine("Dízimo ${if (prefs.titheEnabled) "($titheRateLabel%)" else "· desativado"}", FinanceDates.money(tithe), R.color.warning))
        summary.addView(summaryLine("Contas obrigatórias do mês", FinanceDates.money(plan.monthlyMandatoryCents), R.color.danger))
        if (prefs.cycleMode == "Quinzenal") summary.addView(summaryLine("Vencem nesta quinzena", FinanceDates.money(fixedInCycle), R.color.danger))
        summary.addView(View(this).apply { setBackgroundColor(getColor(R.color.stroke)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)).apply { topMargin = Ui.dp(this@FinanceActivity, 7); bottomMargin = Ui.dp(this@FinanceActivity, 5) })
        val percentLabel = if (income > 0) "${String.format(Locale.forLanguageTag("pt-BR"), "%.1f", ratio)}% da renda recebida já foi gasta" else "Registre uma entrada para calcular o percentual de gastos."
        summary.addView(label(percentLabel, 13, R.color.text_primary, true))
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            this.progress = ratio.toInt().coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(getColor(if (ratio >= 90) R.color.danger else R.color.positive))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.stroke))
        }
        summary.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5)).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })
        page.addView(summary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8) })

        val fixedHeader = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        fixedHeader.addView(label("Contas obrigatórias", 16, R.color.text_primary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fixedHeader.addView(makeButton("+ Adicionar", true).apply { setOnClickListener { showMandatoryExpenseDialog(null) } }, LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 38)))
        page.addView(fixedHeader, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 14); bottomMargin = Ui.dp(this@FinanceActivity, 4) })
        if (allFixed.isEmpty()) {
            page.addView(emptyPanel("Nenhuma conta fixa cadastrada", "Adicione aluguel, internet, energia ou outra despesa que se repete todo mês."))
        } else {
            allFixed.forEach { item ->
                val row = horizontal().apply {
                    background = getDrawable(R.drawable.bg_card)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(Ui.dp(this@FinanceActivity, 11), Ui.dp(this@FinanceActivity, 9), Ui.dp(this@FinanceActivity, 9), Ui.dp(this@FinanceActivity, 9))
                    setOnClickListener { showMandatoryExpenseActions(item) }
                }
                val info = vertical()
                info.addView(label(item.name + if (item.active) "" else " · Pausada", 14, R.color.text_primary, true))
                info.addView(label("Vence dia ${item.dueDay} · ${item.account}", 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 2), 0, 0) })
                row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(label(FinanceDates.money(item.amountCents), 13, R.color.danger, true))
                page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 5) })
            }
        }
        page.addView(label("As contas fixas são um planejamento; elas não viram despesas automaticamente.", 11, R.color.text_secondary, false).apply { setPadding(Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 7), 0, Ui.dp(this@FinanceActivity, 6)) })
        page.addView(makeButton("Ver movimentações do período", false).apply { setOnClickListener { periodMode = if (prefs.cycleMode == "Quinzenal") "Quinzena" else "Mês"; periodAnchor = Calendar.getInstance(); currentScreen = SCREEN_TRANSACTIONS; render() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 42)).apply { topMargin = Ui.dp(this@FinanceActivity, 4) })

        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
    }

    private fun showPlanningSettingsDialog() {
        val prefs = FinanceStore.preferences()
        val form = vertical().apply { setPadding(Ui.dp(this@FinanceActivity, 5), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 5), 0) }
        val titheCheck = CheckBox(this).apply { text = "Ativar desconto opcional do dízimo"; isChecked = prefs.titheEnabled; textSize = 14f; setTextColor(getColor(R.color.text_primary)) }
        form.addView(titheCheck)
        val percent = editField("10", String.format(Locale.ROOT, "%.2f", prefs.tithePercent).trimEnd('0').trimEnd('.'), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        form.addView(label("Percentual do dízimo (%)", 12, R.color.text_secondary, false))
        form.addView(percent)
        percent.isEnabled = titheCheck.isChecked
        percent.alpha = if (percent.isEnabled) 1f else 0.5f
        titheCheck.setOnCheckedChangeListener { _, checked -> percent.isEnabled = checked; percent.alpha = if (checked) 1f else 0.5f }
        val cycleSpinner = spinner(listOf("Mensal", "Quinzenal"), if (prefs.cycleMode == "Quinzenal") 1 else 0)
        form.addView(label("Organização da renda", 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 8), 0, 0) })
        form.addView(cycleSpinner)
        val dialog = AlertDialog.Builder(this).setTitle("Preferências do planejamento")
            .setMessage("O dízimo é opcional e só reduz o valor disponível quando você ativa esta opção.")
            .setView(form).setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val percentage = percent.text.toString().replace(',', '.').toDoubleOrNull()
                if (titheCheck.isChecked && (percentage == null || percentage !in 0.0..100.0)) {
                    percent.error = "Use um percentual entre 0 e 100"
                    return@setOnClickListener
                }
                try {
                    FinanceStore.savePreferences(FinancePreferences(titheCheck.isChecked, percentage ?: prefs.tithePercent, if (cycleSpinner.selectedItemPosition == 1) "Quinzenal" else "Mensal"))
                    dialog.dismiss(); showPlanning(); Ui.toast(this, "Planejamento atualizado")
                } catch (_: Exception) { Ui.toast(this, "Não foi possível salvar as preferências") }
            }
        }
        dialog.show()
    }

    private fun showMandatoryExpenseDialog(existing: MandatoryExpense?) {
        val form = vertical().apply { setPadding(Ui.dp(this@FinanceActivity, 5), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 5), 0) }
        val name = editField("Ex.: Aluguel, internet, energia", existing?.name.orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val amount = editField("0,00", existing?.let { String.format(Locale.forLanguageTag("pt-BR"), "%.2f", it.amountCents / 100.0) }.orEmpty(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val day = editField("1 a 31", (existing?.dueDay ?: 1).toString(), InputType.TYPE_CLASS_NUMBER)
        val account = editField("Ex.: Conta principal, Nubank", existing?.account ?: "Conta principal", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val active = CheckBox(this).apply { text = "Incluir no planejamento"; isChecked = existing?.active ?: true; textSize = 13f }
        listOf("Nome da conta", name, "Valor mensal (R$)", amount, "Dia do vencimento", day, "Conta / carteira usada", account, active).forEach { item ->
            when (item) {
                is String -> form.addView(label(item, 12, R.color.text_secondary, false))
                is View -> form.addView(item)
            }
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Nova conta obrigatória" else "Editar conta obrigatória")
            .setView(ScrollView(this).apply { addView(form) }).setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val expenseName = name.text.toString().trim(); val cents = FinanceDates.parseCents(amount.text.toString()); val dueDay = day.text.toString().toIntOrNull()
                if (expenseName.isBlank()) { name.error = "Informe um nome"; return@setOnClickListener }
                if (cents == null || cents <= 0) { amount.error = "Informe um valor maior que zero"; return@setOnClickListener }
                if (dueDay == null || dueDay !in 1..31) { day.error = "Use um dia entre 1 e 31"; return@setOnClickListener }
                val entry = existing ?: MandatoryExpense(name = expenseName, amountCents = cents)
                entry.name = expenseName; entry.amountCents = cents; entry.dueDay = dueDay
                entry.account = account.text.toString().trim().ifBlank { "Conta principal" }; entry.active = active.isChecked
                try { FinanceStore.saveMandatoryExpense(entry); dialog.dismiss(); showPlanning(); Ui.toast(this, "Conta fixa salva") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível salvar a conta") }
            }
        }
        dialog.show()
    }

    private fun showMandatoryExpenseActions(item: MandatoryExpense) {
        AlertDialog.Builder(this).setTitle(item.name).setItems(arrayOf("Registrar pagamento", "Editar", if (item.active) "Desativar no planejamento" else "Ativar no planejamento", "Excluir")) { _, which ->
            when (which) {
                0 -> showTransactionDialog(
                    MoneyTransaction(type = "EXPENSE", description = item.name, amountCents = item.amountCents,
                        date = FinanceDates.today(), category = "Contas fixas", account = item.account), null, true)
                1 -> showMandatoryExpenseDialog(item.copyExpense())
                2 -> { item.active = !item.active; try { FinanceStore.saveMandatoryExpense(item); showPlanning() } catch (_: Exception) { Ui.toast(this, "Não foi possível atualizar") } }
                else -> AlertDialog.Builder(this).setTitle("Excluir conta fixa?").setMessage("Ela será removida do planejamento, sem apagar movimentações anteriores.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ -> try { FinanceStore.deleteMandatoryExpense(item.id); showPlanning() } catch (_: Exception) { Ui.toast(this, "Não foi possível excluir") } }.show()
            }
        }.show()
    }

    private fun summaryLine(title: String, value: String, colorRes: Int): View = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(label(title, 13, R.color.text_secondary, false), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(label(value, 13, colorRes, true))
        setPadding(0, Ui.dp(this@FinanceActivity, 7), 0, 0)
    }

    private fun showCalendar() {
        val page = vertical()
        val modeRow = horizontal()
        listOf("Semana", "Mês", "Ano").forEach { mode ->
            modeRow.addView(makeButton(mode, calendarMode == mode).apply {
                setOnClickListener { calendarMode = mode; selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis); showCalendar() }
            }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { rightMargin = Ui.dp(this@FinanceActivity, 3); leftMargin = Ui.dp(this@FinanceActivity, 3) })
        }
        page.addView(modeRow)
        val nav = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        nav.addView(makeButton("‹", false).apply { setOnClickListener { moveCalendar(-1); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(label(calendarLabel(), 15, R.color.text_primary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
        nav.addView(makeButton("›", false).apply { setOnClickListener { moveCalendar(1); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(makeButton("Hoje", false).apply { setOnClickListener { calendarAnchor = Calendar.getInstance(); selectedDate = FinanceDates.today(); showCalendar() } }, LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 40)).apply { leftMargin = Ui.dp(this@FinanceActivity, 4) })
        page.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 4); bottomMargin = Ui.dp(this@FinanceActivity, 6) })

        when (calendarMode) {
            "Semana" -> renderWeek(page)
            "Ano" -> renderYear(page)
            else -> renderMonth(page)
        }

        val dayTx = FinanceStore.allTransactions().filter { it.date == selectedDate }
        val dayDone = dayTx.filter { it.status == "DONE" }
        val dayIn = dayDone.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val dayOut = dayDone.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val selectedCard = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 10), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 10))
        }
        selectedCard.addView(label("${FinanceDates.display(selectedDate)} · ${dayTx.size} movimentação(ões)", 15, R.color.text_primary, true))
        selectedCard.addView(label("Entradas ${FinanceDates.money(dayIn)}     Saídas ${FinanceDates.money(dayOut)}", 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 4), 0, 0) })
        page.addView(selectedCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 8) })
        page.addView(makeButton("+ Movimentação nesta data", false).apply { setOnClickListener { showTransactionDialog(null, selectedDate) } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)).apply { topMargin = Ui.dp(this@FinanceActivity, 5) })
        if (dayTx.isEmpty()) page.addView(label("Nenhuma movimentação nesta data.", 13, R.color.text_secondary, false).apply { setPadding(Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 10), 0, Ui.dp(this@FinanceActivity, 8)) })
        else dayTx.forEach { tx -> page.addView(transactionCard(tx), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) }) }
        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
    }

    private fun renderMonth(page: LinearLayout) {
        val weekdays = horizontal()
        listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom").forEach { d ->
            weekdays.addView(label(d, 11, R.color.text_secondary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 24), 1f))
        }
        page.addView(weekdays)
        val first = (calendarAnchor.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val todayKey = FinanceDates.today()
        val txDates = FinanceStore.allTransactions().map { it.date }.toHashSet()
        for (week in 0 until 6) {
            val row = horizontal()
            for (col in 0 until 7) {
                val n = week * 7 + col - offset + 1
                if (n in 1..days) {
                    val cal = (first.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, n) }
                    val key = FinanceDates.dateForMillis(cal.timeInMillis)
                    val has = key in txDates
                    val txt = if (has) "$n\n•" else n.toString()
                    val cell = TextView(this).apply {
                        text = txt; gravity = Gravity.CENTER; textSize = 12f
                        setTextColor(getColor(if (key == selectedDate) R.color.on_primary else R.color.text_primary))
                        if (key == selectedDate) background = rounded(R.color.primary) else if (key == todayKey) background = rounded(R.color.stroke)
                        isClickable = true; isFocusable = true
                        setOnClickListener { selectedDate = key; showCalendar() }
                    }
                    row.addView(cell, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { setMargins(Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1), Ui.dp(this@FinanceActivity, 1)) })
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
                }
            }
            page.addView(row)
            if ((week + 1) * 7 - offset + 1 > days) break
        }
    }

    private fun renderWeek(page: LinearLayout) {
        val start = (calendarAnchor.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }
        val dayLabel = java.text.SimpleDateFormat("EEE dd/MM", Locale.forLanguageTag("pt-BR"))
        val allTx = FinanceStore.allTransactions()
        for (i in 0..6) {
            val day = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
            val key = FinanceDates.dateForMillis(day.timeInMillis)
            val txs = allTx.filter { it.date == key }
            val total = txs.filter { it.status == "DONE" }.sumOf { if (it.type == "INCOME") it.amountCents else -it.amountCents }
            val b = makeButton("${dayLabel.format(day.time).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }}     ${if (txs.isEmpty()) "" else FinanceDates.money(total)}", key == selectedDate)
            b.gravity = Gravity.CENTER_VERTICAL
            b.setOnClickListener { selectedDate = key; showCalendar() }
            page.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 42)).apply { topMargin = Ui.dp(this@FinanceActivity, 3) })
        }
    }

    private fun renderYear(page: LinearLayout) {
        val grid = GridLayout(this).apply { columnCount = 3; rowCount = 4 }
        val allTx = FinanceStore.allTransactions()
        for (month in 0..11) {
            val cal = (calendarAnchor.clone() as Calendar).apply { set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, 1) }
            val start = FinanceDates.dateForMillis(cal.timeInMillis)
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
            val end = FinanceDates.dateForMillis(cal.timeInMillis)
            val tx = allTx.filter { it.date >= start && it.date <= end && it.status == "DONE" }
            val spent = tx.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
            val b = makeButton("${FinanceDates.monthShort((calendarAnchor.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.MONTH, month) })}\n${FinanceDates.money(spent)}", false)
            b.textSize = 12f
            b.setOnClickListener {
                calendarAnchor = (calendarAnchor.clone() as Calendar).apply { set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, 1) }
                calendarMode = "Mês"; selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis); showCalendar()
            }
            val lp = GridLayout.LayoutParams().apply { width = 0; height = Ui.dp(this@FinanceActivity, 72); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2), Ui.dp(this@FinanceActivity, 2)) }
            grid.addView(b, lp)
        }
        page.addView(grid)
    }

    private fun showTransactionDialog(existing: MoneyTransaction?, initialDate: String? = null, isNew: Boolean = existing == null) {
        val form = vertical().apply { setPadding(Ui.dp(this@FinanceActivity, 6), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 6), Ui.dp(this@FinanceActivity, 2)) }
        val typeSpinner = spinner(listOf("Despesa", "Receita"), if (existing?.type == "INCOME") 1 else 0)
        form.addView(label("Tipo", 13, R.color.text_secondary, false)); form.addView(typeSpinner)
        val desc = editField("Ex.: Supermercado", existing?.description.orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Descrição", 13, R.color.text_secondary, false)); form.addView(desc)
        val amount = editField("0,00", if (existing == null) "" else String.format(Locale.forLanguageTag("pt-BR"), "%.2f", existing.amountCents / 100.0), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        form.addView(label("Valor (R$)", 13, R.color.text_secondary, false)); form.addView(amount)
        val category = editField("Ex.: Alimentação", existing?.category ?: "Outros", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Categoria", 13, R.color.text_secondary, false)); form.addView(category)
        val account = editField("Ex.: Conta principal, Nubank, dinheiro", existing?.account ?: "Conta principal", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Conta / carteira", 13, R.color.text_secondary, false)); form.addView(account)
        val statusSpinner = spinner(listOf("Efetivada", "Pendente"), if (existing?.status == "PENDING") 1 else 0)
        form.addView(label("Situação", 13, R.color.text_secondary, false)); form.addView(statusSpinner)
        var dateKey = existing?.date ?: initialDate ?: FinanceDates.today()
        val dateButton = makeButton("Data: ${FinanceDates.display(dateKey)}", false)
        dateButton.setOnClickListener {
            val c = FinanceDates.calendarFor(dateKey)
            DatePickerDialog(this, { _, y, m, d ->
                val selected = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }
                dateKey = FinanceDates.dateForMillis(selected.timeInMillis)
                dateButton.text = "Data: ${FinanceDates.display(dateKey)}"
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        form.addView(label("Data", 13, R.color.text_secondary, false)); form.addView(dateButton)
        val receiptItems = ReceiptStore.list()
        val receiptOptions = listOf("Sem comprovante") + receiptItems.map { if (it.description.isNotBlank()) it.description else it.displayName }
        val receiptSpinner = spinner(receiptOptions, (receiptItems.indexOfFirst { it.id == existing?.receiptId } + 1).coerceAtLeast(0))
        form.addView(label("Comprovante (opcional)", 13, R.color.text_secondary, false)); form.addView(receiptSpinner)

        val dialog = AlertDialog.Builder(this).setTitle(if (isNew) "Nova movimentação" else "Editar movimentação")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("Salvar", null).setNegativeButton("Cancelar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val description = desc.text.toString().trim()
                val cents = FinanceDates.parseCents(amount.text.toString())
                if (description.isBlank()) { desc.error = "Informe uma descrição"; return@setOnClickListener }
                if (cents == null || cents <= 0) { amount.error = "Informe um valor maior que zero"; return@setOnClickListener }
                val tx = existing ?: MoneyTransaction(type = "EXPENSE", description = "", amountCents = 0, date = dateKey, category = "Outros")
                tx.type = if (typeSpinner.selectedItemPosition == 1) "INCOME" else "EXPENSE"
                tx.description = description; tx.amountCents = cents; tx.date = dateKey
                tx.category = category.text.toString().trim().ifBlank { "Outros" }
                tx.account = account.text.toString().trim().ifBlank { "Conta principal" }
                tx.status = if (statusSpinner.selectedItemPosition == 1) "PENDING" else "DONE"
                tx.receiptId = receiptItems.getOrNull(receiptSpinner.selectedItemPosition - 1)?.id
                try { FinanceStore.saveTransaction(tx); dialog.dismiss(); render(); Ui.toast(this, "Movimentação salva") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível salvar. Tente novamente.") }
            }
        }
        dialog.show()
    }

    private fun showOpeningBalanceDialog() {
        val input = editField("0,00", String.format(Locale.forLanguageTag("pt-BR"), "%.2f", FinanceStore.openingBalance() / 100.0), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        AlertDialog.Builder(this).setTitle("Saldo inicial")
            .setMessage("Informe o saldo que você já tinha antes das movimentações registradas.")
            .setView(input).setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val cents = FinanceDates.parseCents(input.text.toString())
                if (cents == null) Ui.toast(this, "Informe um valor válido") else try { FinanceStore.setOpeningBalance(cents); render() } catch (_: Exception) { Ui.toast(this, "Não foi possível salvar o saldo") }
            }.show()
    }

    private fun csvCell(value: String): String {
        val safe = if (value.firstOrNull() in listOf('=', '+', '-', '@')) "'" + value else value
        return "\"" + safe.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ") + "\""
    }

    @Suppress("DEPRECATION")
    private fun exportTransactionsCsv(rows: List<MoneyTransaction>) {
        if (rows.isEmpty()) { Ui.toast(this, "Não há movimentações neste período para exportar."); return }
        pendingCsv = buildString {
            append('\uFEFF')
            append("Data;Tipo;Descrição;Categoria;Conta;Situação;Valor\r\n")
            rows.sortedBy { it.date }.forEach { t ->
                append(listOf(
                    FinanceDates.display(t.date), if (t.type == "INCOME") "Entrada" else "Saída", t.description, t.category, t.account,
                    if (t.status == "PENDING") "Pendente" else "Efetivada",
                    String.format(Locale.forLanguageTag("pt-BR"), "%.2f", t.amountCents / 100.0)
                ).joinToString(";") { csvCell(it) }).append("\r\n")
            }
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "movimentacoes-" + FinanceDates.today() + ".csv")
        }
        try { startActivityForResult(intent, createCsvRequest) }
        catch (_: ActivityNotFoundException) { Ui.toast(this, "Não foi possível abrir o seletor para salvar o arquivo") }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != createCsvRequest || resultCode != RESULT_OK || uri == null) return
        val csv = pendingCsv ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                ?: throw IllegalStateException("sem saída")
            Ui.toast(this, "Movimentações exportadas")
        } catch (_: Exception) { Ui.toast(this, "Falha ao exportar as movimentações") }
        pendingCsv = null
    }

    private fun transactionCard(tx: MoneyTransaction): View {
        val card = horizontal().apply {
            background = getDrawable(R.drawable.bg_card)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 11), Ui.dp(this@FinanceActivity, 14), Ui.dp(this@FinanceActivity, 11))
            isClickable = true; isFocusable = true
            setOnClickListener { showTransactionActions(tx) }
        }
        card.addView(Ui.letterBadge(this, tx.category.trim().take(1).ifEmpty { "?" }, Ui.categoryColor(this, tx.category), 42))
        val info = vertical()
        info.addView(label(tx.description, 15, R.color.text_primary, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        info.addView(label("${tx.category} · ${tx.account.ifBlank { "Conta principal" }}", 12, R.color.text_secondary, false).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, Ui.dp(this@FinanceActivity, 2), 0, 0)
        })
        val hasReceipt = tx.receiptId != null && ReceiptStore.find(tx.receiptId!!) != null
        if (tx.status == "PENDING" || hasReceipt) {
            val tags = horizontal()
            if (tx.status == "PENDING") tags.addView(Ui.tag(this, "Pendente", R.color.warning))
            if (hasReceipt) tags.addView(Ui.tag(this, "Comprovante", R.color.primary), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (tx.status == "PENDING") leftMargin = Ui.dp(this@FinanceActivity, 6) })
            info.addView(tags, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@FinanceActivity, 6) })
        }
        card.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = Ui.dp(this@FinanceActivity, 12); marginEnd = Ui.dp(this@FinanceActivity, 8) })
        val amount = Ui.tabular(label((if (tx.type == "INCOME") "+ " else "− ") + FinanceDates.money(tx.amountCents), 15, if (tx.type == "INCOME") R.color.positive else R.color.danger, true))
        amount.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        if (tx.status == "PENDING") amount.alpha = 0.65f
        card.addView(amount)
        return card
    }

    private fun showTransactionActions(tx: MoneyTransaction) {
        val linkedReceipt = tx.receiptId?.let { ReceiptStore.find(it) }
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        labels.add("Editar"); actions.add { showTransactionDialog(tx.copy()) }
        if (tx.status == "PENDING") {
            labels.add("Marcar como efetivada")
            actions.add {
                try { FinanceStore.saveTransaction(tx.copy(status = "DONE")); render(); Ui.toast(this, "Movimentação efetivada") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível atualizar") }
            }
        }
        labels.add("Duplicar")
        actions.add { showTransactionDialog(tx.copy(id = java.util.UUID.randomUUID().toString(), date = FinanceDates.today(), receiptId = null), null, true) }
        if (linkedReceipt != null) {
            labels.add("Abrir comprovante")
            actions.add { startActivity(Intent(this, DetailActivity::class.java).putExtra(DetailActivity.EXTRA_ID, linkedReceipt.id)) }
        }
        labels.add("Excluir")
        actions.add {
            AlertDialog.Builder(this).setTitle("Excluir movimentação?").setMessage("Essa ação não pode ser desfeita.")
                .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                    try { FinanceStore.deleteTransaction(tx.id); render(); Ui.toast(this, "Movimentação excluída") }
                    catch (_: Exception) { Ui.toast(this, "Não foi possível excluir") }
                }.show()
        }
        AlertDialog.Builder(this).setTitle(tx.description).setItems(labels.toTypedArray()) { _, which -> actions[which]() }.show()
    }

    private fun choosePeriodMode(onSelected: (String) -> Unit) {
        val options = arrayOf("Semana", "Quinzena", "Mês", "Ano")
        AlertDialog.Builder(this).setTitle("Filtrar por período")
            .setSingleChoiceItems(options, options.indexOf(periodMode).coerceAtLeast(0)) { dialog, which -> onSelected(options[which]); dialog.dismiss() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun movePeriod(delta: Int) {
        when (periodMode) {
            "Semana" -> periodAnchor.add(Calendar.WEEK_OF_YEAR, delta)
            "Quinzena" -> periodAnchor.add(Calendar.DAY_OF_MONTH, 15 * delta)
            "Ano" -> periodAnchor.add(Calendar.YEAR, delta)
            else -> periodAnchor.add(Calendar.MONTH, delta)
        }
    }

    private fun range(mode: String, anchor: Calendar): Pair<String, String> {
        val start = (anchor.clone() as Calendar); val end = (anchor.clone() as Calendar)
        when (mode) {
            "Semana" -> {
                val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7
                start.add(Calendar.DAY_OF_MONTH, -offset)
                end.timeInMillis = start.timeInMillis; end.add(Calendar.DAY_OF_MONTH, 6)
            }
            "Quinzena" -> {
                if (start.get(Calendar.DAY_OF_MONTH) <= 15) { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, 15) }
                else { start.set(Calendar.DAY_OF_MONTH, 16); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
            }
            "Ano" -> { start.set(Calendar.MONTH, Calendar.JANUARY); start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun periodLabel(mode: String, anchor: Calendar): String = when (mode) {
        "Semana" -> {
            val (s, e) = range(mode, anchor); "${FinanceDates.display(s)} – ${FinanceDates.display(e)}"
        }
        "Ano" -> anchor.get(Calendar.YEAR).toString()
        "Quinzena" -> { val (s, e) = range(mode, anchor); "${FinanceDates.display(s)} – ${FinanceDates.display(e)}" }
        else -> FinanceDates.monthLabel(anchor)
    }

    private fun calendarLabel(): String = when (calendarMode) {
        "Semana" -> { val (s, e) = range("Semana", calendarAnchor); "${FinanceDates.display(s)} – ${FinanceDates.display(e)}" }
        "Ano" -> calendarAnchor.get(Calendar.YEAR).toString()
        else -> FinanceDates.monthLabel(calendarAnchor)
    }

    private fun moveCalendar(delta: Int) {
        when (calendarMode) { "Semana" -> calendarAnchor.add(Calendar.WEEK_OF_YEAR, delta); "Ano" -> calendarAnchor.add(Calendar.YEAR, delta); else -> calendarAnchor.add(Calendar.MONTH, delta) }
        selectedDate = FinanceDates.dateForMillis(calendarAnchor.timeInMillis)
    }

    private fun statBlock(title: String, value: String, colorRes: Int, titleColor: Int = R.color.text_secondary): View = vertical().apply {
        addView(label(title, 12, titleColor, false))
        addView(Ui.tabular(label(value, 16, colorRes, true)).apply { setPadding(0, Ui.dp(this@FinanceActivity, 3), 0, 0) })
    }

    private fun emptyPanel(title: String, detail: String): View = vertical().apply {
        background = getDrawable(R.drawable.bg_card)
        setPadding(Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 20), Ui.dp(this@FinanceActivity, 16), Ui.dp(this@FinanceActivity, 20))
        addView(label(title, 15, R.color.text_primary, true))
        addView(label(detail, 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@FinanceActivity, 5), 0, 0) })
    }

    private fun label(textValue: String, size: Int, colorRes: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue; textSize = size.toFloat(); setTextColor(getColor(colorRes)); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun makeButton(textValue: String, primary: Boolean): Button = Ui.button(this, textValue, primary)
    private fun styleTab(button: Button, active: Boolean) {
        button.background = if (active) Ui.rounded(this, R.color.primary, 10) else null
        button.setTextColor(getColor(if (active) R.color.on_primary else R.color.text_secondary))
    }
    private fun editField(hintValue: String, initial: String, inputTypeValue: Int): EditText = EditText(this).apply {
        hint = hintValue; setText(initial); inputType = inputTypeValue; textSize = 15f; maxLines = 1
        setPadding(Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 4), Ui.dp(this@FinanceActivity, 12), Ui.dp(this@FinanceActivity, 4))
        setBackgroundResource(R.drawable.bg_input); minimumHeight = Ui.dp(this@FinanceActivity, 44)
    }
    private fun spinner(items: List<String>, selection: Int): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@FinanceActivity, android.R.layout.simple_spinner_item, items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setSelection(selection.coerceIn(items.indices))
    }
    private fun rounded(colorRes: Int) = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = Ui.dp(this@FinanceActivity, 8).toFloat(); setColor(getColor(colorRes)) }
}
