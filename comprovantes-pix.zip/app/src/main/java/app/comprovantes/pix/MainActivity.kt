package app.comprovantes.pix

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    private companion object {
        const val REQUEST_PICK = 1001
        const val RECENT_LIMIT = 5
    }

    private lateinit var countText: TextView
    private lateinit var searchInput: EditText
    private lateinit var sectionLabel: TextView
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var historyButton: Button
    private lateinit var adapter: ReceiptAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById(R.id.mainRoot))
        ReceiptStore.init(this)

        countText = findViewById(R.id.countText)
        searchInput = findViewById(R.id.searchInput)
        sectionLabel = findViewById(R.id.sectionLabel)
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.emptyView)
        historyButton = findViewById(R.id.historyButton)
        val importButton = findViewById<Button>(R.id.importButton)

        adapter = ReceiptAdapter(this)
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val receipt = adapter.getItem(position)
            startActivity(
                Intent(this, DetailActivity::class.java)
                    .putExtra(DetailActivity.EXTRA_ID, receipt.id)
            )
        }

        importButton.setOnClickListener { pickFiles() }
        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refresh()
            }
        })
        searchInput.setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                Ui.hideKeyboard(view)
                true
            } else {
                false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val total = ReceiptStore.count()
        countText.text = resources.getQuantityString(R.plurals.saved_count, total, total)
        historyButton.visibility = if (total > 0) View.VISIBLE else View.GONE

        val query = searchInput.text.toString().trim()
        val shown = if (query.isEmpty()) {
            ReceiptStore.list().take(RECENT_LIMIT)
        } else {
            ReceiptStore.search(query)
        }
        adapter.submit(shown)

        sectionLabel.text = getString(if (query.isEmpty()) R.string.recent else R.string.search_results)
        sectionLabel.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE

        when {
            total == 0 -> {
                emptyView.setText(R.string.empty_state)
                emptyView.visibility = View.VISIBLE
            }
            shown.isEmpty() -> {
                emptyView.setText(R.string.no_results)
                emptyView.visibility = View.VISIBLE
            }
            else -> emptyView.visibility = View.GONE
        }
    }

    @Suppress("DEPRECATION")
    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try {
            startActivityForResult(intent, REQUEST_PICK)
        } catch (e: ActivityNotFoundException) {
            Ui.toast(this, getString(R.string.picker_missing))
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK || resultCode != RESULT_OK || data == null) return

        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                val uri = clip.getItemAt(i).uri
                if (uri != null && !uris.contains(uri)) uris.add(uri)
            }
        }
        if (uris.isEmpty()) return

        // A tela de confirmação é a mesma usada pelo menu "Compartilhar".
        val forward = Intent(this, ReceiveActivity::class.java).apply {
            action = Intent.ACTION_SEND_MULTIPLE
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            val clipData = ClipData.newRawUri(null, uris[0])
            for (i in 1 until uris.size) clipData.addItem(ClipData.Item(uris[i]))
            this.clipData = clipData
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(forward)
    }
}
