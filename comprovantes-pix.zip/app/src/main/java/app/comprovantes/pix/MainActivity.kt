package app.comprovantes.pix

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : BaseActivity() {

    private companion object {
        const val REQUEST_PICK = 1001
        const val RECENT_LIMIT = 4
    }

    private lateinit var countText: TextView
    private lateinit var searchInput: EditText
    private lateinit var sectionLabel: TextView
    private lateinit var receiptsContainer: LinearLayout
    private lateinit var emptyHost: LinearLayout
    private lateinit var historyButton: TextView
    private lateinit var periodChips: LinearLayout
    private lateinit var balanceText: TextView
    private lateinit var incomeText: TextView
    private lateinit var expenseText: TextView
    private lateinit var availableText: TextView
    private lateinit var planningDetailText: TextView
    private lateinit var spendingRatioText: TextView
    private lateinit var spendingProgress: ProgressBar
    private lateinit var adapter: ReceiptAdapter
    private var periodMode: String = "Mês"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById(R.id.mainRoot))
        ReceiptStore.init(this)
        FinanceStore.init(this)

        countText = findViewById(R.id.countText)
        searchInput = findViewById(R.id.searchInput)
        sectionLabel = findViewById(R.id.sectionLabel)
        receiptsContainer = findViewById(R.id.receiptsContainer)
        emptyHost = findViewById(R.id.emptyHost)
        historyButton = findViewById(R.id.historyButton)
        periodChips = findViewById(R.id.periodChips)
        balanceText = findViewById(R.id.balanceText)
        incomeText = findViewById(R.id.incomeText)
        expenseText = findViewById(R.id.expenseText)
        availableText = findViewById(R.id.availableText)
        planningDetailText = findViewById(R.id.planningDetailText)
        spendingRatioText = findViewById(R.id.spendingRatioText)
        spendingProgress = findViewById(R.id.spendingProgress)
        listOf(balanceText, incomeText, expenseText, availableText).forEach { Ui.tabular(it) }
        spendingProgress.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.stroke))

        adapter = ReceiptAdapter(this)
        buildActionTiles()
        buildPeriodChips()

        findViewById<View>(R.id.settingsButton).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<View>(R.id.planningButton).setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java).putExtra(FinanceActivity.EXTRA_SCREEN, FinanceActivity.SCREEN_PLAN))
        }
        historyButton.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { refreshReceipts() }
        })
        searchInput.setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { Ui.hideKeyboard(view); true } else false
        }
    }

    override fun onResume() {
        super.onResume()
        refreshDashboard()
        refreshReceipts()
        FinanceStore.takeRecoveryNote()?.let { note ->
            AlertDialog.Builder(this).setTitle("Atenção").setMessage(note).setPositiveButton("Entendi", null).show()
        }
    }

    // ------------------------------------------------------------------ construção da tela

    private fun buildActionTiles() {
        val grid = findViewById<GridLayout>(R.id.actionsGrid)
        grid.removeAllViews()
        fun finance(screen: String) = startActivity(Intent(this, FinanceActivity::class.java).putExtra(FinanceActivity.EXTRA_SCREEN, screen))
        val tiles = listOf<Triple<Int, String, () -> Unit>>(
            Triple(R.drawable.ic_swap, "Movimentações", { finance(FinanceActivity.SCREEN_TRANSACTIONS) }),
            Triple(R.drawable.ic_calendar, "Calendário", { finance(FinanceActivity.SCREEN_CALENDAR) }),
            Triple(R.drawable.ic_table, "Planilhas", { startActivity(Intent(this, SheetsActivity::class.java)) }),
            Triple(R.drawable.ic_chart, "Relatórios", { startActivity(Intent(this, InsightsActivity::class.java)) }),
            Triple(R.drawable.ic_note_add, "Importar", { pickFiles() }),
            Triple(R.drawable.ic_history, "Comprovantes", { startActivity(Intent(this, HistoryActivity::class.java)) })
        )
        tiles.forEach { (icon, label, action) ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = getDrawable(R.drawable.bg_card)
                isClickable = true; isFocusable = true
                contentDescription = label
                setPadding(Ui.dp(this@MainActivity, 6), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 6), Ui.dp(this@MainActivity, 12))
                setOnClickListener { action() }
            }
            tile.addView(ImageView(this).apply {
                setImageResource(icon)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }, LinearLayout.LayoutParams(Ui.dp(this, 28), Ui.dp(this, 28)))
            tile.addView(TextView(this).apply {
                text = label; textSize = 12f; gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(getColor(R.color.text_primary))
                setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0)
                maxLines = 1
            })
            val lp = GridLayout.LayoutParams().apply {
                width = 0; height = Ui.dp(this@MainActivity, 86)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                val m = Ui.dp(this@MainActivity, 4)
                setMargins(m, m, m, m)
            }
            grid.addView(tile, lp)
        }
    }

    private fun buildPeriodChips() {
        periodChips.removeAllViews()
        listOf("Semana" to "Semana", "Quinzena" to "Quinzena", "Mês" to "Mês", "Ano" to "Ano").forEach { (mode, label) ->
            val chip = Ui.chip(this, label, periodMode == mode) {
                periodMode = mode
                buildPeriodChips()
                refreshDashboard()
            }
            periodChips.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = Ui.dp(this@MainActivity, 8) })
        }
    }

    // ------------------------------------------------------------------ dados

    private fun rangeForPeriod(): Pair<String, String> {
        val cal = Calendar.getInstance()
        val start: Calendar = (cal.clone() as Calendar)
        val end: Calendar = (cal.clone() as Calendar)
        when (periodMode) {
            "Semana" -> {
                val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7
                start.add(Calendar.DAY_OF_MONTH, -offset)
                end.timeInMillis = start.timeInMillis
                end.add(Calendar.DAY_OF_MONTH, 6)
            }
            "Quinzena" -> {
                if (start.get(Calendar.DAY_OF_MONTH) <= 15) { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, 15) }
                else { start.set(Calendar.DAY_OF_MONTH, 16); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
            }
            "Ano" -> { start.set(Calendar.DAY_OF_YEAR, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun refreshDashboard() {
        val today = SimpleDateFormat("EEEE, d 'de' MMMM", Locale.forLanguageTag("pt-BR")).format(Date())
        countText.text = today.replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }
        balanceText.text = FinanceDates.money(FinanceStore.currentBalance())
        val (start, end) = rangeForPeriod()
        val periodTx = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end && it.status == "DONE" }
        incomeText.text = FinanceDates.money(periodTx.filter { it.type == "INCOME" }.sumOf { it.amountCents })
        expenseText.text = FinanceDates.money(periodTx.filter { it.type == "EXPENSE" }.sumOf { it.amountCents })

        val prefs = FinanceStore.preferences()
        val plan = FinanceStore.planningSummary()
        availableText.text = FinanceDates.money(plan.availableCents)
        val titheRateLabel = String.format(Locale.forLanguageTag("pt-BR"), "%.2f", prefs.tithePercent).trimEnd('0').trimEnd(',').trimEnd('.')
        planningDetailText.text = "disponível após descontos · " +
            (if (prefs.titheEnabled) "dízimo $titheRateLabel%: ${FinanceDates.money(plan.titheCents)}" else "dízimo desativado") +
            " · a vencer: ${FinanceDates.money(plan.mandatoryDueCents)}"
        val ratio = plan.spendingPercent
        spendingProgress.progress = (ratio ?: 0.0).toInt().coerceIn(0, 100)
        val barColor = if ((ratio ?: 0.0) >= 90.0) R.color.danger else R.color.positive
        spendingProgress.progressTintList = android.content.res.ColorStateList.valueOf(getColor(barColor))
        spendingRatioText.text = ratio?.let { "Gastos: ${String.format(Locale.forLanguageTag("pt-BR"), "%.1f", it)}% da renda recebida no período" }
            ?: "Registre uma entrada para ver quanto da renda já foi gasta"
    }

    private fun refreshReceipts() {
        val total = ReceiptStore.count()
        val query = searchInput.text.toString().trim()
        val shown = if (query.isEmpty()) ReceiptStore.list().take(RECENT_LIMIT) else ReceiptStore.search(query)
        adapter.submit(shown)
        sectionLabel.text = if (query.isEmpty()) "Comprovantes recentes" else "Resultados da pesquisa"
        historyButton.visibility = if (query.isEmpty() && total > RECENT_LIMIT) View.VISIBLE else View.GONE

        receiptsContainer.removeAllViews()
        for (i in 0 until adapter.count) {
            val view = adapter.getView(i, null, receiptsContainer)
            val receipt = adapter.getItem(i)
            view.setOnClickListener { startActivity(Intent(this, DetailActivity::class.java).putExtra(DetailActivity.EXTRA_ID, receipt.id)) }
            receiptsContainer.addView(view)
        }
        emptyHost.removeAllViews()
        when {
            total == 0 -> emptyHost.addView(Ui.emptyState(this, R.drawable.ic_note_add, "Nenhum comprovante ainda",
                "Toque em Importar ou compartilhe um comprovante de outro app para o Meu Financeiro. A leitura é feita neste aparelho."))
            shown.isEmpty() -> emptyHost.addView(Ui.emptyState(this, R.drawable.ic_history, "Nada encontrado", "Tente outras palavras na pesquisa."))
        }
    }

    @Suppress("DEPRECATION")
    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(intent, REQUEST_PICK) }
        catch (_: ActivityNotFoundException) { Ui.toast(this, getString(R.string.picker_missing)) }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) { val uri = clip.getItemAt(i).uri; if (uri != null && !uris.contains(uri)) uris.add(uri) } }
        if (uris.isEmpty()) return
        val forward = Intent(this, ReceiveActivity::class.java).apply {
            action = Intent.ACTION_SEND_MULTIPLE; type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            val clipData = ClipData.newRawUri(null, uris[0])
            for (i in 1 until uris.size) clipData.addItem(ClipData.Item(uris[i]))
            this.clipData = clipData
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(forward)
    }
}
