package app.comprovantes.pix

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.Date

/** Extração local, sem enviar comprovantes para servidores. Valores identificados sempre exigem confirmação. */
object ReceiptAnalyzer {
    data class Result(
        val rawText: String = "",
        val amountCents: Long? = null,
        val date: String? = null,
        val direction: String? = null, // INCOME / EXPENSE
        val description: String = "",
        val category: String = "Outros",
        val counterparty: String? = null,
        val directionConfident: Boolean = false,
        val notes: String = ""
    )

    fun analyze(context: Context, source: Importer.Source, mime: String?, callback: (Result) -> Unit) {
        if (source is Importer.Source.TextSource) {
            callback(parse(source.text))
            return
        }
        val fileSource = source as? Importer.Source.FileSource
        if (fileSource == null) { callback(Result(notes = "Não foi possível abrir o conteúdo.")); return }
        if (mime == "text/plain") {
            Thread {
                val raw = try {
                    context.contentResolver.openInputStream(fileSource.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(100_000) }.orEmpty()
                } catch (_: Exception) { "" }
                callback(parse(raw))
            }.start()
            return
        }
        Thread {
            val bitmap = try {
                when {
                    mime == "application/pdf" -> renderPdf(context, fileSource.uri)
                    mime?.startsWith("image/") == true -> decodeImage(context, fileSource.uri)
                    else -> null
                }
            } catch (_: Exception) { null }
            if (bitmap == null) {
                callback(Result(notes = if (mime == "application/pdf") "Não consegui ler a primeira página do PDF." else "Não consegui ler esta imagem."))
                return@Thread
            }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { visionText ->
                        callback(parse(visionText.text))
                        recognizer.close()
                        bitmap.recycle()
                    }
                    .addOnFailureListener {
                        callback(Result(notes = "A leitura automática falhou. Você ainda pode preencher os dados manualmente."))
                        recognizer.close()
                        bitmap.recycle()
                    }
            } catch (_: Exception) {
                recognizer.close()
                bitmap.recycle()
                callback(Result(notes = "A leitura automática falhou. Você ainda pode preencher os dados manualmente."))
            }
        }.start()
    }

    private fun decodeImage(context: Context, uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 3200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun renderPdf(context: Context, uri: Uri): Bitmap? {
        val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount <= 0) return null
                renderer.openPage(0).use { page ->
                    val scale = minOf(2200f / page.width.coerceAtLeast(1), 3200f / page.height.coerceAtLeast(1))
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                }
            }
        }
    }

    fun parse(raw: String): Result {
        val text = raw.replace('\u00A0', ' ').replace('\r', '\n')
        val lines = text.lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }
        val flat = lines.joinToString(" ").lowercase(Locale.ROOT)
        val outgoing = listOf("pix enviado", "transferência enviada", "transferencia enviada", "você enviou", "voce enviou", "enviado para", "pagamento realizado", "pagamento efetuado", "débito em conta", "debito em conta", "conta debitada", "pagamento via pix", "comprovante de pagamento").any { flat.contains(it) }
        val incoming = listOf("pix recebido", "transferência recebida", "transferencia recebida", "você recebeu", "voce recebeu", "recebido de", "valor recebido", "crédito em conta", "credito em conta", "crédito recebido", "credito recebido", "valor creditado", "pix creditado", "recebimento pix").any { flat.contains(it) }
        val direction = when {
            outgoing && !incoming -> "EXPENSE"
            incoming && !outgoing -> "INCOME"
            // Frases explícitas do comprovante têm prioridade quando aparecem junto dos papéis das partes.
            listOf("pix enviado", "transferência enviada", "transferencia enviada", "você enviou", "voce enviou", "pagamento realizado", "pagamento efetuado").any { flat.contains(it) } -> "EXPENSE"
            listOf("pix recebido", "transferência recebida", "transferencia recebida", "você recebeu", "voce recebeu", "recebimento pix").any { flat.contains(it) } -> "INCOME"
            else -> null
        }

        val date = findDate(text)
        val amount = findAmount(lines)
        val category = detectCategory(flat)
        val counterparty = findCounterparty(lines, direction)
        val description = when {
            counterparty != null && direction == "EXPENSE" -> "Pix para $counterparty"
            counterparty != null && direction == "INCOME" -> "Pix de $counterparty"
            category != "Outros" && direction == "EXPENSE" -> category
            direction == "EXPENSE" -> "Pix enviado"
            direction == "INCOME" -> "Pix recebido"
            category != "Outros" -> category
            else -> "Pix / transferência"
        }
        val notes = when {
            text.isBlank() -> "Nenhum texto reconhecido. Preencha os campos manualmente."
            amount == null && direction == null -> "Não consegui confirmar valor e tipo da movimentação. Confira os campos antes de registrar."
            amount == null -> "Tipo identificado, mas o valor precisa ser preenchido."
            direction == null -> "Valor identificado, mas entrada/saída precisa ser confirmada."
            else -> "Revise os dados identificados antes de registrar a movimentação."
        }
        return Result(rawText = text.trim(), amountCents = amount, date = date, direction = direction,
            description = description, category = category, counterparty = counterparty,
            directionConfident = direction != null, notes = notes)
    }

    private fun findAmount(lines: List<String>): Long? {
        val currencyRegex = Regex("(?i)R\\$\\s*((?:\\d{1,3}(?:\\.\\d{3})+|\\d+)(?:,\\d{2})?)")
        val decimalRegex = Regex("(?<![\\d/])((?:\\d{1,3}(?:\\.\\d{3})+|\\d+),\\d{2})(?![\\d/])")
        val skipLabels = listOf("saldo", "disponível", "disponivel", "limite", "taxa", "tarifa", "antes", "depois")
        val amountLabels = listOf("valor", "valor do pix", "valor enviado", "valor recebido", "valor da transferência", "valor da transferencia", "valor da transação", "valor da transacao", "total")
        // Primeiro dá prioridade a valores associados ao rótulo de valor, e não a saldo/taxa.
        for (line in lines) {
            val lower = line.lowercase(Locale.ROOT)
            if (skipLabels.any { lower.contains(it) } && !amountLabels.any { lower.contains(it) }) continue
            if (amountLabels.any { lower.contains(it) }) {
                val match = currencyRegex.find(line) ?: decimalRegex.find(line)
                val amount = match?.groupValues?.lastOrNull()?.let { parseLocalMoney(it) }
                if (amount != null && amount > 0) return amount
            }
        }
        for (line in lines) {
            val lower = line.lowercase(Locale.ROOT)
            if (skipLabels.any { lower.contains(it) }) continue
            val match = currencyRegex.find(line) ?: decimalRegex.find(line)
            val amount = match?.groupValues?.lastOrNull()?.let { parseLocalMoney(it) }
            if (amount != null && amount > 0) return amount
        }
        return null
    }


    private fun parseLocalMoney(raw: String): Long? {
        val value = raw.trim()
        // OCR pode ler R$ 1.234 sem centavos; nesse caso o ponto é separador de milhar.
        val normalized = if (!value.contains(',') && Regex("^\\d{1,3}(?:\\.\\d{3})+$").matches(value)) value.replace(".", "") else value
        return FinanceDates.parseCents(normalized)
    }

    private fun findDate(text: String): String? {
        val patterns = listOf(
            Regex("(?<!\\d)(\\d{2})/(\\d{2})/(\\d{4})(?!\\d)"),
            Regex("(?<!\\d)(\\d{2})/(\\d{2})/(\\d{2})(?!\\d)"),
            Regex("(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)")
        )
        for ((index, pattern) in patterns.withIndex()) {
            val m = pattern.find(text) ?: continue
            val raw = m.value
            val formats = when (index) {
                0 -> listOf("dd/MM/yyyy")
                1 -> listOf("dd/MM/yy")
                else -> listOf("yyyy-MM-dd")
            }
            for (format in formats) try {
                val f = SimpleDateFormat(format, Locale.ROOT).apply { isLenient = false }
                val parsed = f.parse(raw) ?: continue
                return SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(parsed)
            } catch (_: Exception) { }
        }
        // Data escrita por extenso em português, por exemplo 17 out 2026.
        val monthPattern = Regex("(?i)(\\d{1,2})\\s+(?:de\\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-z]*\\s+(?:de\\s+)?(\\d{4})")
        val match = monthPattern.find(text) ?: return null
        val month = mapOf("jan" to 1, "fev" to 2, "mar" to 3, "abr" to 4, "mai" to 5, "jun" to 6, "jul" to 7, "ago" to 8, "set" to 9, "out" to 10, "nov" to 11, "dez" to 12)[match.groupValues[2].lowercase(Locale.ROOT)] ?: return null
        val cal = Calendar.getInstance().apply { set(match.groupValues[3].toInt(), month - 1, match.groupValues[1].toInt(), 12, 0, 0) }
        return SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(cal.time)
    }

    private fun findCounterparty(lines: List<String>, direction: String?): String? {
        val labels = if (direction == "INCOME") listOf("pagador", "remetente", "origem", "nome de quem enviou", "nome do pagador", "de")
            else listOf("destinatário", "destinatario", "recebedor", "beneficiário", "beneficiario", "favorecido", "nome de quem recebeu", "para")
        val avoid = listOf("cpf", "cnpj", "banco", "agência", "agencia", "conta", "chave", "instituição", "instituicao", "valor", "data", "hora", "tipo", "pix", "pagamento", "transferência", "transferencia")
        for (i in lines.indices) {
            val lower = lines[i].lowercase(Locale.ROOT)
            val label = labels.firstOrNull { lower == it || lower.startsWith("$it:") || lower.startsWith("$it ") } ?: continue
            val sameLine = lines[i].substringAfter(":", "").trim().takeIf { it.length >= 3 && it.lowercase(Locale.ROOT) != label }
            val value = sameLine ?: lines.getOrNull(i + 1)?.takeIf { next ->
                next.length in 3..70 && avoid.none { next.lowercase(Locale.ROOT).contains(it) } && !Regex(".*\\d{3,}.*").matches(next)
            }
            if (value != null && avoid.none { value.lowercase(Locale.ROOT).contains(it) }) return value.take(70)
        }
        return null
    }

    private fun detectCategory(text: String): String = when {
        listOf("dízimo", "dizimo", "oferta", "doação", "doacao", "igreja").any { text.contains(it) } -> "Doações / Dízimo"
        listOf("netflix", "spotify", "disney+", "prime video", "assinatura", "streaming").any { text.contains(it) } -> "Assinaturas"
        listOf("escola", "faculdade", "mensalidade", "curso", "material escolar").any { text.contains(it) } -> "Educação"
        listOf("supermercado", "mercado", "restaurante", "lanche", "ifood", "padaria", "alimentação", "alimentacao").any { text.contains(it) } -> "Alimentação"
        listOf("uber", "99app", "combustível", "combustivel", "posto", "ônibus", "onibus", "passagem", "estacionamento").any { text.contains(it) } -> "Transporte"
        listOf("aluguel", "condomínio", "condominio", "imobiliária", "imobiliaria").any { text.contains(it) } -> "Moradia"
        listOf("energia", "enel", "água", "agua", "internet", "telefone", "fatura", "energia elétrica").any { text.contains(it) } -> "Contas da casa"
        listOf("farmácia", "farmacia", "hospital", "consulta", "médico", "medico", "clínica", "clinica").any { text.contains(it) } -> "Saúde"
        listOf("salário", "salario", "folha de pagamento", "pagamento de salário").any { text.contains(it) } -> "Salário"
        listOf("compra", "loja", "pedido", "e-commerce", "mercadolivre", "shopee", "amazon").any { text.contains(it) } -> "Compras"
        else -> "Outros"
    }
}
