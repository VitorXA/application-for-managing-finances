package app.comprovantes.pix

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Extração local, sem enviar comprovantes para servidores. Valores identificados sempre exigem confirmação. */
object ReceiptAnalyzer {
    data class Result(
        val rawText: String = "",
        val amountCents: Long? = null,
        val date: String? = null,
        val direction: String? = null, // INCOME / EXPENSE
        val description: String = "",
        val category: String = "Outros",
        val counterparty: String? = null,
        val directionConfident: Boolean = false,
        val notes: String = "",
        val receiverName: String? = null,   // "Destino" do comprovante
        val payerName: String? = null,      // "Origem" do comprovante
        val needsIdentity: Boolean = false  // há dois nomes, mas nenhum é o do usuário (ou o usuário ainda não disse quem é)
    )

    private val mainHandler = Handler(Looper.getMainLooper())

    /** Garante que o callback sempre roda na thread principal (ele mexe na interface). */
    private fun deliver(callback: (Result) -> Unit, result: Result) {
        if (Looper.myLooper() == Looper.getMainLooper()) callback(result) else mainHandler.post { callback(result) }
    }

    fun analyze(context: Context, source: Importer.Source, mime: String?, callback: (Result) -> Unit) {
        if (source is Importer.Source.TextSource) {
            deliver(callback, parse(source.text, Profile.names(context)))
            return
        }
        val fileSource = source as? Importer.Source.FileSource
        if (fileSource == null) { deliver(callback, Result(notes = "Não foi possível abrir o conteúdo.")); return }
        val mine = Profile.names(context)
        Thread {
            if (mime == "text/plain") {
                val raw = try {
                    context.contentResolver.openInputStream(fileSource.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(100_000) }.orEmpty()
                } catch (_: Exception) { "" }
                deliver(callback, parse(raw, mine))
                return@Thread
            }
            var rotation = 0
            val bitmap: Bitmap? = try {
                when {
                    mime == "application/pdf" -> renderPdf(context, fileSource.uri)
                    mime?.startsWith("image/") == true -> {
                        rotation = exifRotation(context, fileSource.uri)
                        decodeImage(context, fileSource.uri)
                    }
                    else -> null
                }
            } catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
            if (bitmap == null) {
                deliver(callback, Result(notes = if (mime == "application/pdf") "Não consegui ler a primeira página do PDF (ele pode estar protegido por senha)." else "Não consegui ler esta imagem."))
                return@Thread
            }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                recognizer.process(InputImage.fromBitmap(bitmap, rotation))
                    .addOnSuccessListener { visionText ->
                        val parsed = parse(visionText.text, mine)
                        recognizer.close()
                        bitmap.recycle()
                        deliver(callback, parsed)
                    }
                    .addOnFailureListener {
                        recognizer.close()
                        bitmap.recycle()
                        deliver(callback, Result(notes = "A leitura automática falhou. Você ainda pode preencher os dados manualmente."))
                    }
            } catch (_: Exception) {
                recognizer.close()
                bitmap.recycle()
                deliver(callback, Result(notes = "A leitura automática falhou. Você ainda pode preencher os dados manualmente."))
            }
        }.start()
    }

    /** Fotos da câmera podem trazer a orientação só nos metadados EXIF. */
    private fun exifRotation(context: Context, uri: Uri): Int = try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (_: Exception) { 0 }

    private fun decodeImage(context: Context, uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 3200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun renderPdf(context: Context, uri: Uri): Bitmap? {
        val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount <= 0) return null
                renderer.openPage(0).use { page ->
                    val scale = minOf(2200f / page.width.coerceAtLeast(1), 3200f / page.height.coerceAtLeast(1))
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                }
            }
        }
    }

    fun parse(raw: String, myNames: List<String> = emptyList()): Result {
        val text = raw.replace(' ', ' ').replace('\r', '\n')
        val lines = text.lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }
        val flat = lines.joinToString(" ").lowercase(Locale.ROOT)
        val outgoing = listOf("pix enviado", "transferência enviada", "transferencia enviada", "você enviou", "voce enviou", "enviado para", "pagamento realizado", "pagamento efetuado", "débito em conta", "debito em conta", "conta debitada", "pagamento via pix", "comprovante de pagamento").any { flat.contains(it) }
        val incoming = listOf("pix recebido", "transferência recebida", "transferencia recebida", "você recebeu", "voce recebeu", "recebido de", "valor recebido", "crédito em conta", "credito em conta", "crédito recebido", "credito recebido", "valor creditado", "pix creditado", "recebimento pix").any { flat.contains(it) }
        val byPhrase = when {
            outgoing && !incoming -> "EXPENSE"
            incoming && !outgoing -> "INCOME"
            // Frases explícitas do comprovante têm prioridade quando aparecem junto dos papéis das partes.
            listOf("pix enviado", "transferência enviada", "transferencia enviada", "você enviou", "voce enviou", "pagamento realizado", "pagamento efetuado").any { flat.contains(it) } -> "EXPENSE"
            listOf("pix recebido", "transferência recebida", "transferencia recebida", "você recebeu", "voce recebeu", "recebimento pix").any { flat.contains(it) } -> "INCOME"
            else -> null
        }

        // Destino x Origem: se um dos dois é o usuário, isso decide entrada ou saída.
        val parties = extractParties(lines)
        val receiver = parties.first
        val payer = parties.second
        val receiverMe = Profile.isMe(receiver, myNames)
        val payerMe = Profile.isMe(payer, myNames)
        var byName: String? = null
        var ownTransfer = false
        when {
            receiverMe && payerMe -> ownTransfer = true
            receiverMe -> byName = "INCOME"
            payerMe -> byName = "EXPENSE"
        }
        val direction = byName ?: if (ownTransfer) null else byPhrase
        val needsIdentity = receiver != null && payer != null && !receiverMe && !payerMe && byPhrase == null

        val date = findDate(text)
        val amount = findAmount(lines)
        val category = detectCategory(lines)
        val counterparty = when (direction) {
            "INCOME" -> payer?.let { Profile.pretty(it) }
            "EXPENSE" -> receiver?.let { Profile.pretty(it) }
            else -> null
        } ?: findCounterparty(lines, direction)
        val description = when {
            counterparty != null && direction == "EXPENSE" -> "Pix para $counterparty"
            counterparty != null && direction == "INCOME" -> "Pix de $counterparty"
            category != "Outros" && direction == "EXPENSE" -> category
            direction == "EXPENSE" -> "Pix enviado"
            direction == "INCOME" -> "Pix recebido"
            category != "Outros" -> category
            else -> "Pix / transferência"
        }
        val notes = when {
            text.isBlank() -> "Nenhum texto reconhecido. Preencha os campos manualmente."
            ownTransfer -> "Origem e destino são você (transferência entre suas contas). Escolha se conta como entrada ou saída."
            amount == null && direction == null -> "Não consegui confirmar valor e tipo da movimentação. Confira os campos antes de registrar."
            amount == null -> "Tipo identificado, mas o valor precisa ser preenchido."
            direction == null -> "Valor identificado, mas entrada/saída precisa ser confirmada."
            byName != null -> "Entrada/saída reconhecida pelo seu nome no comprovante."
            else -> "Dados lidos automaticamente. Revise se quiser."
        }
        return Result(rawText = text.trim(), amountCents = amount, date = date, direction = direction,
            description = description, category = category, counterparty = counterparty,
            directionConfident = direction != null, notes = notes,
            receiverName = receiver, payerName = payer, needsIdentity = needsIdentity)
    }

    // ---- Destino / Origem -------------------------------------------------------------------

    private val receiverHeads = listOf("destino", "destinatário", "destinatario", "quem recebeu", "dados de quem recebeu", "dados do destinatário", "dados do destinatario", "favorecido", "beneficiário", "beneficiario", "recebedor", "dados do recebedor")
    private val payerHeads = listOf("origem", "quem pagou", "dados de quem pagou", "quem enviou", "dados de quem enviou", "pagador", "dados do pagador", "remetente", "dados do remetente")
    private val footerMarks = listOf("id da transação", "id da transacao", "autenticação", "autenticacao", "ouvidoria", "estamos aqui", "protocolo")
    private val partyLabelWords = listOf("cpf", "cnpj", "instituição", "instituicao", "agência", "agencia", "conta", "chave", "banco", "tipo", "valor", "data", "ispb")
    private val institutionTokens = setOf("CAIXA", "ECONOMICA", "FEDERAL", "BANCO", "PAGAMENTOS", "BRADESCO", "ITAU", "ITAÚ", "SANTANDER", "INTER", "NUBANK", "NU", "MERCADO", "PAGO", "PICPAY", "SICREDI", "SICOOB", "C6", "NEON", "ORIGINAL", "NEXT", "BRASIL", "LTDA", "BANK", "IP", "SA", "S", "A")

    private fun headingRole(line: String): Int {
        val l = line.lowercase(Locale.ROOT).trim().trimEnd(':').trim()
        return when {
            receiverHeads.contains(l) -> 1
            payerHeads.contains(l) -> 2
            else -> 0
        }
    }

    /** Valor ao lado de "Nome" (ou nas linhas seguintes): aceita empresas, só recusa rótulos e números. */
    private fun looseName(value: String): Boolean {
        val lower = value.lowercase(Locale.ROOT).trim()
        if (value.length !in 2..80) return false
        if (Regex("\\d{4,}").containsMatchIn(value) || value.contains('@')) return false
        if (partyLabelWords.any { lower == it || lower.startsWith("$it ") || lower.startsWith("$it:") }) return false
        if (lower == "nome" || headingRole(value) != 0) return false
        return value.any { it.isLetter() }
    }

    /** Devolve (destino, origem) com os nomes lidos do comprovante, ou null quando não achou. */
    private fun extractParties(lines: List<String>): Pair<String?, String?> {
        val heads = lines.indices.mapNotNull { i -> val r = headingRole(lines[i]); if (r != 0) i to r else null }
        if (heads.isEmpty()) return null to null
        var receiver: String? = null
        var payer: String? = null
        for ((n, head) in heads.withIndex()) {
            val start = head.first + 1
            var end = if (n + 1 < heads.size) heads[n + 1].first else lines.size
            for (k in start until end) {
                val lo = lines[k].lowercase(Locale.ROOT)
                if (footerMarks.any { lo.contains(it) }) { end = k; break }
            }
            var found: String? = null
            for (k in start until end) {
                val line = lines[k]
                val lower = line.lowercase(Locale.ROOT)
                val isNome = lower == "nome" || lower.startsWith("nome ") || lower.startsWith("nome:")
                if (!isNome) continue
                val rest = line.substring(4).trimStart(':', ' ').trim()
                if (rest.isNotEmpty()) {
                    if (looseName(rest)) found = rest
                } else {
                    for (j in k + 1..minOf(k + 2, end - 1)) if (looseName(lines[j])) { found = lines[j]; break }
                }
                break
            }
            if (found != null) {
                if (head.second == 1 && receiver == null) receiver = found.take(80)
                if (head.second == 2 && payer == null) payer = found.take(80)
            }
        }
        if (receiver == null || payer == null) {
            // OCR que separa a coluna de rótulos da coluna de valores: os nomes vêm depois, na mesma ordem dos blocos.
            val firstRole = heads.first().second
            val from = heads.first().first + 1
            val people = lines.drop(from).filter { personLike(it) }
            if (people.size >= 2) {
                val a = people[0].take(80)
                val b = people[1].take(80)
                if (firstRole == 1) { if (receiver == null) receiver = a; if (payer == null) payer = b }
                else { if (payer == null) payer = a; if (receiver == null) receiver = b }
            }
        }
        return receiver to payer
    }

    private fun personLike(line: String): Boolean {
        if (!Regex("^[\\p{L}][\\p{L}'. ]+$").matches(line)) return false
        val tokens = line.trim().split(' ').filter { it.isNotEmpty() }
        if (tokens.size < 2) return false
        val lower = line.lowercase(Locale.ROOT)
        if (nameAvoid.any { lower.contains(it) } || partyLabelWords.any { lower.contains(it) }) return false
        return tokens.none { institutionTokens.contains(Profile.normalize(it)) }
    }

    /** Procura palavras inteiras (evita "posto" dentro de "imposto", "curso" dentro de "recurso" etc.). */
    private fun hasWord(text: String, words: List<String>): Boolean = words.any { w ->
        Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(w) + "(?![\\p{L}\\p{N}])").containsMatchIn(text)
    }

    private fun findAmount(lines: List<String>): Long? {
        // Aceita 1.234,56 · 1234,56 · 10.50 (OCR com ponto decimal) · 1.234 (milhar sem centavos)
        val currencyRegex = Regex("(?i)R\\$\\s*((?:\\d{1,3}(?:\\.\\d{3})+|\\d+)(?:[,.]\\d{2})?)")
        val decimalRegex = Regex("(?<![\\d/])((?:\\d{1,3}(?:\\.\\d{3})+|\\d+),\\d{2})(?![\\d/])")
        val skipLabels = listOf("saldo", "disponível", "disponivel", "limite", "taxa", "tarifa", "antes", "depois")
        val amountLabels = listOf("valor", "valor do pix", "valor enviado", "valor recebido", "valor da transferência", "valor da transferencia", "valor da transação", "valor da transacao", "total")
        // Primeiro dá prioridade a valores associados ao rótulo de valor, e não a saldo/taxa.
        for (line in lines) {
            val lower = line.lowercase(Locale.ROOT)
            val isAmountLine = amountLabels.any { lower.contains(it) }
            if (hasWord(lower, skipLabels) && !isAmountLine) continue
            if (isAmountLine && !hasWord(lower, listOf("taxa", "tarifa", "saldo", "limite"))) {
                val match = currencyRegex.find(line) ?: decimalRegex.find(line)
                val amount = match?.groupValues?.lastOrNull()?.let { parseLocalMoney(it) }
                if (amount != null && amount > 0) return amount
            }
        }
        for (line in lines) {
            val lower = line.lowercase(Locale.ROOT)
            if (hasWord(lower, skipLabels)) continue
            val match = currencyRegex.find(line) ?: decimalRegex.find(line)
            val amount = match?.groupValues?.lastOrNull()?.let { parseLocalMoney(it) }
            if (amount != null && amount > 0) return amount
        }
        return null
    }

    private fun parseLocalMoney(raw: String): Long? = FinanceDates.parseCents(raw.trim())

    private fun findDate(text: String): String? {
        val patterns = listOf(
            Regex("(?<!\\d)(\\d{2})/(\\d{2})/(\\d{4})(?!\\d)"),
            Regex("(?<!\\d)(\\d{2})/(\\d{2})/(\\d{2})(?!\\d)"),
            Regex("(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)")
        )
        for ((index, pattern) in patterns.withIndex()) {
            for (m in pattern.findAll(text)) {
                val format = when (index) { 0 -> "dd/MM/yyyy"; 1 -> "dd/MM/yy"; else -> "yyyy-MM-dd" }
                try {
                    val f = SimpleDateFormat(format, Locale.ROOT).apply { isLenient = false }
                    val parsed = f.parse(m.value) ?: continue
                    return SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(parsed)
                } catch (_: Exception) { /* tenta a próxima ocorrência */ }
            }
        }
        // Data escrita por extenso em português, por exemplo 17 out 2026.
        val monthPattern = Regex("(?i)(\\d{1,2})\\s+(?:de\\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-z]*\\.?\\s+(?:de\\s+)?(\\d{4})")
        val match = monthPattern.find(text) ?: return null
        val month = mapOf("jan" to 1, "fev" to 2, "mar" to 3, "abr" to 4, "mai" to 5, "jun" to 6, "jul" to 7, "ago" to 8, "set" to 9, "out" to 10, "nov" to 11, "dez" to 12)[match.groupValues[2].lowercase(Locale.ROOT)] ?: return null
        return try {
            val cal = Calendar.getInstance().apply {
                isLenient = false
                clear()
                set(match.groupValues[3].toInt(), month - 1, match.groupValues[1].toInt(), 12, 0, 0)
            }
            SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(cal.time)
        } catch (_: Exception) { null }
    }

    private val nameAvoid = listOf("cpf", "cnpj", "banco", "agência", "agencia", "conta", "chave", "instituição", "instituicao", "valor", "data", "hora", "tipo", "pix", "pagamento", "transferência", "transferencia", "autenticação", "autenticacao", "comprovante")

    private fun validName(value: String): Boolean {
        val lower = value.lowercase(Locale.ROOT)
        return value.length in 3..70 && nameAvoid.none { lower.contains(it) } && !Regex(".*\\d{3,}.*").matches(value)
    }

    private fun findCounterparty(lines: List<String>, direction: String?): String? {
        val labels = if (direction == "INCOME")
            listOf("nome de quem enviou", "nome do pagador", "quem pagou", "pagador", "remetente", "origem", "de")
        else
            listOf("nome de quem recebeu", "destinatário", "destinatario", "recebedor", "beneficiário", "beneficiario", "favorecido", "destino", "para")
        for (i in lines.indices) {
            val line = lines[i]
            val lower = line.lowercase(Locale.ROOT)
            val label = labels.firstOrNull { lower == it || lower.startsWith("$it:") || lower.startsWith("$it ") } ?: continue
            val rest = line.substring(label.length).trimStart(':', ' ').trim()
            if (rest.isNotEmpty()) {
                // "de"/"para" são curtos demais: sem dois-pontos só vale se o que segue parece um nome próprio.
                val shortLabel = label == "de" || label == "para"
                val hadColon = lower.startsWith("$label:")
                val looksLikeName = rest.first().isUpperCase()
                if ((!shortLabel || hadColon || looksLikeName) && validName(rest)) return rest.take(70)
                continue
            }
            // Rótulo sozinho na linha: o nome vem nas linhas seguintes ("Nome  João" ou só "João").
            for (j in i + 1..minOf(i + 3, lines.lastIndex)) {
                val next = lines[j]
                val nextLower = next.lowercase(Locale.ROOT)
                val candidate = if (nextLower.startsWith("nome")) next.substring(4).trimStart(':', ' ').trim() else next
                if (candidate.isNotEmpty() && validName(candidate)) return candidate.take(70)
            }
        }
        return null
    }

    private fun detectCategory(lines: List<String>): String {
        // Ignora linhas sobre o banco/conta: "Mercado Pago" como instituição não significa supermercado.
        val skip = listOf("instituição", "instituicao", "banco", "agência", "agencia", "cpf", "cnpj", "chave", "tipo de conta", "conta corrente", "conta poupança", "conta poupanca", "conta de pagamento", "ispb", "autenticação", "autenticacao", "id da transação", "id da transacao")
        val text = lines.filter { l -> val lo = l.lowercase(Locale.ROOT); skip.none { lo.contains(it) } }
            .joinToString(" ").lowercase(Locale.ROOT)
            .replace("mercado pago", " ").replace("mercadopago", " ")
        return when {
            hasWord(text, listOf("dízimo", "dizimo", "oferta", "ofertas", "doação", "doacao", "igreja")) -> "Doações / Dízimo"
            hasWord(text, listOf("mercado livre", "mercadolivre", "shopee", "amazon", "magalu", "aliexpress", "shein")) -> "Compras"
            hasWord(text, listOf("netflix", "spotify", "disney+", "prime video", "assinatura", "streaming")) -> "Assinaturas"
            hasWord(text, listOf("escola", "faculdade", "mensalidade", "curso", "material escolar")) -> "Educação"
            hasWord(text, listOf("supermercado", "mercado", "restaurante", "lanche", "lanchonete", "ifood", "padaria", "alimentação", "alimentacao")) -> "Alimentação"
            hasWord(text, listOf("uber", "99app", "combustível", "combustivel", "posto", "ônibus", "onibus", "passagem", "estacionamento")) -> "Transporte"
            hasWord(text, listOf("aluguel", "condomínio", "condominio", "imobiliária", "imobiliaria")) -> "Moradia"
            hasWord(text, listOf("energia", "enel", "água", "agua", "internet", "telefone", "fatura", "energia elétrica")) -> "Contas da casa"
            hasWord(text, listOf("farmácia", "farmacia", "hospital", "consulta", "médico", "medico", "clínica", "clinica")) -> "Saúde"
            hasWord(text, listOf("salário", "salario", "folha de pagamento", "pagamento de salário")) -> "Salário"
            hasWord(text, listOf("compra", "loja", "pedido", "e-commerce")) -> "Compras"
            else -> "Outros"
        }
    }
}
