package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.FileNotFoundException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Importação com OCR local, revisão explícita e registro financeiro apenas após confirmação. */
class ReceiveActivity : Activity() {

    companion object {
        const val EXTRA_EXISTING_RECEIPT_ID = "existing_receipt_id"
    }

    private var reanalysisReceipt: Receipt? = null

    private class Entry(
        val candidate: Importer.Candidate,
        var analysis: ReceiptAnalyzer.Result,
        var receipt: Receipt? = null,
        var transactionSaved: Boolean = false,
        var lastError: String? = null
    ) {
        lateinit var card: LinearLayout
        lateinit var statusText: TextView
        lateinit var registerCheck: CheckBox
        lateinit var fields: LinearLayout
        lateinit var typeSpinner: Spinner
        lateinit var amountInput: EditText
        lateinit var dateInput: EditText
        lateinit var descriptionInput: EditText
        lateinit var categoryInput: EditText
        lateinit var accountInput: EditText
    }

    private data class SaveRequest(
        val entry: Entry,
        val registerTransaction: Boolean,
        val receiptDescription: String,
        val type: String,
        val amountCents: Long,
        val date: String,
        val description: String,
        val category: String,
        val account: String
    )

    private lateinit var progressRow: View
    private lateinit var progressText: TextView
    private lateinit var summaryText: TextView
    private lateinit var itemsContainer: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button
    private lateinit var historyButton: Button
    private lateinit var subtitleText: TextView

    private val entries = mutableListOf<Entry>()
    private var skippedLines: List<String> = emptyList()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)
        Ui.applyInsets(findViewById(R.id.receiveRoot))
        ReceiptStore.init(this)
        FinanceStore.init(this)

        progressRow = findViewById(R.id.progressRow)
        progressText = findViewById(R.id.progressText)
        summaryText = findViewById(R.id.summaryText)
        itemsContainer = findViewById(R.id.itemsContainer)
        resultText = findViewById(R.id.resultText)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)
        historyButton = findViewById(R.id.historyButton)
        subtitleText = findViewById(R.id.receiveSubtitle)

        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener { saveReviewedItems() }
        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
            finish()
        }
        loadAndAnalyze()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!busy) super.onBackPressed()
    }

    private fun loadAndAnalyze() {
        setBusy(true, "Abrindo comprovante…")
        Thread {
            val existingReceipt = intent.getStringExtra(EXTRA_EXISTING_RECEIPT_ID)?.let { ReceiptStore.find(it) }
            val resolved = try {
                if (existingReceipt != null) {
                    listOf(Importer.Candidate(
                        source = Importer.Source.FileSource(ReceiptProvider.uriFor(this, existingReceipt)),
                        displayName = existingReceipt.displayName,
                        mime = existingReceipt.mimeType,
                        problem = null
                    ))
                } else Importer.resolve(this, Importer.extract(intent))
            } catch (_: Exception) { emptyList() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                reanalysisReceipt = existingReceipt
                entries.clear()
                analyzeNext(resolved, 0)
            }
        }.start()
    }

    private fun analyzeNext(candidates: List<Importer.Candidate>, index: Int) {
        if (isFinishing || isDestroyed) return
        if (index >= candidates.size) {
            showReviewScreen()
            return
        }
        val candidate = candidates[index]
        if (!candidate.supported) {
            entries.add(Entry(candidate, ReceiptAnalyzer.Result(notes = candidate.problem ?: "Formato não compatível.")))
            analyzeNext(candidates, index + 1)
            return
        }
        setBusy(true, "Lendo comprovante ${index + 1} de ${candidates.size} no aparelho…")
        ReceiptAnalyzer.analyze(this, candidate.source, candidate.mime) { result ->
            if (isFinishing || isDestroyed) return@analyze
            val saved = if (index == 0) reanalysisReceipt else null
            val merged = if (saved == null) result else result.copy(
                rawText = result.rawText.ifBlank { saved.recognizedText },
                amountCents = result.amountCents ?: saved.detectedAmountCents,
                date = result.date ?: saved.detectedDate,
                direction = result.direction ?: saved.detectedDirection,
                category = if (result.category != "Outros") result.category else saved.detectedCategory,
                counterparty = result.counterparty ?: saved.detectedCounterparty,
                description = if (result.counterparty != null || result.category != "Outros") result.description else saved.description.ifBlank { result.description }
            )
            entries.add(Entry(candidate, merged, receipt = saved))
            analyzeNext(candidates, index + 1)
        }
    }

    private fun showReviewScreen() {
        setBusy(false, null)
        itemsContainer.removeAllViews()
        val supported = entries.count { it.candidate.supported }
        val total = entries.size
        summaryText.text = when {
            total == 0 -> "Não recebi um arquivo para ler. Volte e tente compartilhar ou importar novamente."
            supported == 0 -> "Recebi ${total} item(ns), mas nenhum está em formato que possa ser salvo."
            else -> "$supported comprovante(s) para revisar. A leitura é feita neste aparelho; nada é enviado para um servidor."
        }
        skippedLines = entries.filter { !it.candidate.supported }.map { "${it.candidate.displayName}: ${it.candidate.problem.orEmpty()}" }
        entries.forEach { itemsContainer.addView(buildEntryCard(it)) }
        saveButton.visibility = if (supported > 0) View.VISIBLE else View.GONE
        saveButton.text = if (entries.any { it.candidate.supported && it.analysis.amountCents != null && it.analysis.direction != null }) "Salvar e registrar" else "Salvar comprovantes"
        cancelButton.text = "Cancelar"
        historyButton.visibility = View.GONE
        resultText.visibility = View.GONE
        subtitleText.text = "Confira valor, entrada ou saída e contexto. Nada será lançado sem sua confirmação."
    }

    private fun buildEntryCard(entry: Entry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@ReceiveActivity, 15), Ui.dp(this@ReceiveActivity, 14), Ui.dp(this@ReceiveActivity, 15), Ui.dp(this@ReceiveActivity, 15))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = Ui.dp(this@ReceiveActivity, 12)
            }
        }
        entry.card = card

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val fileInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fileInfo.addView(text(entry.candidate.displayName, 15, R.color.text_primary, true))
        fileInfo.addView(text(Receipt.labelFor(entry.candidate.mime) + " · análise local", 12, R.color.text_secondary, false).apply {
            setPadding(0, Ui.dp(this@ReceiveActivity, 3), 0, 0)
        })
        top.addView(fileInfo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val statusPill = text(if (entry.candidate.supported && entry.analysis.rawText.isNotBlank()) "Lido" else "Revisar", 12, R.color.primary, true).apply {
            setPadding(Ui.dp(this@ReceiveActivity, 9), Ui.dp(this@ReceiveActivity, 5), Ui.dp(this@ReceiveActivity, 9), Ui.dp(this@ReceiveActivity, 5))
            background = getDrawable(R.drawable.bg_plan_summary)
        }
        top.addView(statusPill)
        card.addView(top)

        entry.statusText = text(parsedSummary(entry), 14, R.color.primary, true).apply {
            setPadding(0, Ui.dp(this@ReceiveActivity, 12), 0, Ui.dp(this@ReceiveActivity, 4))
        }
        card.addView(entry.statusText)
        if (entry.analysis.counterparty != null) {
            card.addView(text("Possível pessoa/empresa: ${entry.analysis.counterparty} · confira", 13, R.color.text_secondary, false))
        }
        card.addView(text(entry.analysis.notes.ifBlank { "Confira os campos identificados." }, 13, R.color.text_secondary, false).apply {
            setPadding(0, Ui.dp(this@ReceiveActivity, 4), 0, Ui.dp(this@ReceiveActivity, 8))
        })
        val rawButton = TextView(this).apply {
            text = "Ver texto reconhecido"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(getColor(R.color.primary))
            setPadding(0, Ui.dp(this@ReceiveActivity, 5), 0, Ui.dp(this@ReceiveActivity, 10))
            isClickable = true
            setOnClickListener { showRecognizedText(entry.analysis.rawText) }
        }
        card.addView(rawButton)

        if (!entry.candidate.supported) {
            card.addView(text("Este item não pode ser salvo: ${entry.candidate.problem.orEmpty()}", 13, R.color.danger, true))
            return card
        }

        entry.registerCheck = CheckBox(this).apply {
            text = "Criar movimentação no financeiro também"
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
            isChecked = entry.analysis.amountCents != null && entry.analysis.direction != null
            buttonTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.primary))
        }
        card.addView(entry.registerCheck)
        entry.fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (entry.registerCheck.isChecked) View.VISIBLE else View.GONE
            setPadding(0, Ui.dp(this@ReceiveActivity, 4), 0, 0)
        }
        card.addView(entry.fields)

        entry.amountInput = addField(entry, "Valor (R$)", entry.analysis.amountCents?.let { decimalMoney(it) }.orEmpty(), "Ex.: 125,90", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        entry.typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@ReceiveActivity, android.R.layout.simple_spinner_item, listOf("Saída · dinheiro saiu", "Entrada · dinheiro entrou")).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setSelection(if (entry.analysis.direction == "INCOME") 1 else 0)
        }
        addFieldLabel(entry.fields, "Tipo de movimentação")
        entry.fields.addView(entry.typeSpinner, fullWidthParams())

        val dateDisplay = entry.analysis.date?.let { displayIsoDate(it) }.orEmpty()
        entry.dateInput = addField(entry, "Data do comprovante", dateDisplay, "Toque para escolher · dd/mm/aaaa", InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_DATE).apply {
            setOnClickListener { showDatePicker(entry) }
            isFocusable = false
            isClickable = true
        }
        entry.descriptionInput = addField(entry, "Descrição", entry.analysis.description, "Ex.: Mercado, aluguel ou Pix para Ana", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        entry.categoryInput = addField(entry, "Categoria", entry.analysis.category, "Ex.: Alimentação, Moradia", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        entry.accountInput = addField(entry, "Conta / carteira", "Conta principal", "Ex.: Nubank, dinheiro", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)

        entry.registerCheck.setOnCheckedChangeListener { _, checked ->
            entry.fields.visibility = if (checked) View.VISIBLE else View.GONE
            updateSaveLabel()
        }
        return card
    }

    private fun addField(entry: Entry, label: String, value: String, hint: String, inputType: Int): EditText {
        addFieldLabel(entry.fields, label)
        val field = EditText(this).apply {
            setSingleLine(true)
            this.inputType = inputType
            setText(value)
            this.hint = hint
            textSize = 15f
            setTextColor(getColor(R.color.text_primary))
            setHintTextColor(getColor(R.color.text_secondary))
            background = getDrawable(R.drawable.bg_input)
            setPadding(Ui.dp(this@ReceiveActivity, 12), Ui.dp(this@ReceiveActivity, 11), Ui.dp(this@ReceiveActivity, 12), Ui.dp(this@ReceiveActivity, 11))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        entry.fields.addView(field, fullWidthParams())
        return field
    }

    private fun addFieldLabel(parent: LinearLayout, value: String) {
        parent.addView(text(value, 12, R.color.text_secondary, true).apply {
            setPadding(0, Ui.dp(this@ReceiveActivity, 10), 0, Ui.dp(this@ReceiveActivity, 4))
        })
    }

    private fun fullWidthParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(getColor(color))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun parsedSummary(entry: Entry): String {
        if (!entry.candidate.supported) return "Formato não compatível"
        val amount = entry.analysis.amountCents?.let { FinanceDates.money(it) } ?: "valor não identificado"
        val type = when (entry.analysis.direction) { "INCOME" -> "Entrada detectada"; "EXPENSE" -> "Saída detectada"; else -> "Tipo não identificado" }
        val date = entry.analysis.date?.let { displayIsoDate(it) } ?: "data não identificada"
        return "$amount  ·  $type\n$date"
    }

    private fun showRecognizedText(raw: String) {
        val content = if (raw.isBlank()) "Nenhum texto foi reconhecido automaticamente. Você pode preencher os campos manualmente." else raw
        val view = TextView(this).apply {
            text = content
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
            setPadding(Ui.dp(this@ReceiveActivity, 18), Ui.dp(this@ReceiveActivity, 10), Ui.dp(this@ReceiveActivity, 18), Ui.dp(this@ReceiveActivity, 10))
            textIsSelectable = true
        }
        val scroll = ScrollView(this).apply { addView(view) }
        AlertDialog.Builder(this).setTitle("Texto reconhecido no comprovante").setView(scroll).setPositiveButton("Fechar", null).show()
    }

    private fun showDatePicker(entry: Entry) {
        val cal = try {
            val parsed = SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).apply { isLenient = false }.parse(entry.dateInput.text.toString())
            Calendar.getInstance().apply { if (parsed != null) time = parsed }
        } catch (_: Exception) { Calendar.getInstance() }
        DatePickerDialog(this, { _, year, month, day ->
            entry.dateInput.setText(String.format(Locale.ROOT, "%02d/%02d/%04d", day, month + 1, year))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateSaveLabel() {
        if (busy) return
        saveButton.text = if (entries.any { it.candidate.supported && it.registerCheck.isChecked }) "Salvar e registrar" else "Salvar comprovantes"
    }

    private fun saveReviewedItems() {
        if (busy) return
        val requests = mutableListOf<SaveRequest>()
        for (entry in entries.filter { it.candidate.supported }) {
            val register = entry.registerCheck.isChecked && !entry.transactionSaved
            val amount = if (register) FinanceDates.parseCents(entry.amountInput.text.toString()) else (entry.analysis.amountCents ?: 0L)
            val date = if (register) parseDisplayDate(entry.dateInput.text.toString()) else (entry.analysis.date ?: FinanceDates.today())
            val description = if (register) entry.descriptionInput.text.toString().trim() else entry.analysis.description
            val category = if (register) entry.categoryInput.text.toString().trim() else entry.analysis.category
            val account = if (register) entry.accountInput.text.toString().trim().ifBlank { "Conta principal" } else "Conta principal"
            if (register) {
                if (amount == null || amount <= 0L) { entry.amountInput.error = "Confira um valor maior que zero"; entry.amountInput.requestFocus(); return }
                if (date == null) { entry.dateInput.error = "Escolha a data do comprovante"; entry.dateInput.requestFocus(); return }
                if (description.isBlank()) { entry.descriptionInput.error = "Informe uma descrição"; entry.descriptionInput.requestFocus(); return }
            }
            val selectedType = if (register) if (entry.typeSpinner.selectedItemPosition == 1) "INCOME" else "EXPENSE" else entry.analysis.direction ?: "EXPENSE"
            val receiptDescription = if (!register && entry.receipt != null) entry.receipt!!.description else description
            requests.add(SaveRequest(entry, register, receiptDescription.ifBlank { entry.candidate.displayName }, selectedType, amount ?: 0L,
                date ?: entry.analysis.date ?: FinanceDates.today(), description.ifBlank { "Comprovante importado" }, category.ifBlank { "Outros" }, account))
        }
        if (requests.isEmpty()) { Ui.toast(this, "Não há comprovantes compatíveis para salvar."); return }

        val existingTransactions = FinanceStore.allTransactions()
        val duplicates = requests.filter { request ->
            request.registerTransaction && !request.entry.transactionSaved && existingTransactions.any { existing ->
                existing.status == "DONE" && existing.type == request.type && existing.amountCents == request.amountCents &&
                    existing.date == request.date && existing.description.trim().equals(request.description.trim(), ignoreCase = true)
            }
        }
        if (duplicates.isNotEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Possível movimentação duplicada")
                .setMessage("Já existe uma movimentação com o mesmo tipo, valor, data e descrição. Para evitar contar esse gasto duas vezes, confira antes de continuar.")
                .setNegativeButton("Voltar e revisar", null)
                .setPositiveButton("Registrar mesmo assim") { _, _ -> persistRequests(requests) }
                .show()
            return
        }
        persistRequests(requests)
    }

    private fun persistRequests(requests: List<SaveRequest>) {
        resultText.visibility = View.GONE
        setBusy(true, "Salvando comprovante e movimentação…")
        Thread {
            val messages = mutableListOf<String>()
            val errors = mutableListOf<Entry>()
            requests.forEach { request ->
                val entry = request.entry
                try {
                    val receipt = entry.receipt ?: when (val source = entry.candidate.source) {
                        is Importer.Source.FileSource -> ReceiptStore.saveFromUri(this, source.uri, entry.candidate.displayName,
                            entry.candidate.mime ?: "application/octet-stream", request.receiptDescription, entry.analysis)
                        is Importer.Source.TextSource -> ReceiptStore.saveText(source.text, entry.candidate.displayName, request.receiptDescription, entry.analysis)
                    }.also { entry.receipt = it }
                    if (entry.receipt != null) {
                        entry.receipt = ReceiptStore.updateAnalysis(entry.receipt!!.id, entry.analysis, request.receiptDescription)
                    }

                    if (request.registerTransaction && !entry.transactionSaved) {
                        FinanceStore.saveTransaction(MoneyTransaction(
                            type = request.type,
                            description = request.description,
                            amountCents = request.amountCents,
                            date = request.date,
                            category = request.category,
                            status = "DONE",
                            receiptId = receipt.id,
                            account = request.account
                        ))
                        entry.transactionSaved = true
                    }
                    entry.lastError = null
                    messages.add(if (entry.transactionSaved) {
                        val kind = if (request.type == "INCOME") "entrada" else "saída"
                        "✓ ${entry.candidate.displayName}: comprovante salvo e $kind de ${FinanceDates.money(request.amountCents)} registrada."
                    } else "✓ ${entry.candidate.displayName}: comprovante salvo. Nenhuma movimentação foi criada.")
                } catch (e: Exception) {
                    entry.lastError = describeError(e)
                    errors.add(entry)
                    messages.add("! ${entry.candidate.displayName}: ${entry.lastError}")
                }
            }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                setBusy(false, null)
                if (errors.isEmpty()) {
                    resultText.text = messages.joinToString("\n\n") + if (skippedLines.isNotEmpty()) "\n\nIgnorados:\n" + skippedLines.joinToString("\n") else ""
                    resultText.visibility = View.VISIBLE
                    summaryText.visibility = View.GONE
                    itemsContainer.visibility = View.GONE
                    saveButton.visibility = View.GONE
                    cancelButton.text = "Fechar"
                    historyButton.visibility = View.VISIBLE
                    subtitleText.text = "Importação concluída. Os dados registrados podem ser editados em Movimentações."
                    Ui.toast(this, "Importação concluída")
                } else {
                    resultText.text = messages.joinToString("\n\n")
                    resultText.visibility = View.VISIBLE
                    saveButton.text = "Tentar novamente"
                    saveButton.visibility = View.VISIBLE
                    subtitleText.text = "Alguns itens não foram concluídos. Os que já foram salvos não serão duplicados ao tentar novamente."
                    entries.filter { it.receipt != null }.forEach { entry ->
                        entry.statusText.text = if (entry.transactionSaved) "Salvo e registrado" else "Comprovante salvo · sem movimentação"
                        entry.registerCheck.isEnabled = !entry.transactionSaved
                        entry.fields.isEnabled = !entry.transactionSaved
                    }
                }
            }
        }.start()
    }

    private fun displayIsoDate(iso: String): String = try {
        SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).format(SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).parse(iso) ?: Date())
    } catch (_: Exception) { "" }

    private fun parseDisplayDate(raw: String): String? {
        return try {
            val parsed = SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).apply { isLenient = false }.parse(raw.trim())
                ?: return null
            SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(parsed)
        } catch (_: Exception) { null }
    }

    private fun decimalMoney(cents: Long): String = String.format(Locale.forLanguageTag("pt-BR"), "%.2f", cents / 100.0)

    private fun describeError(e: Exception): String {
        val message = e.message.orEmpty()
        return when {
            e is SecurityException -> getString(R.string.err_permission)
            e is EmptyContentException -> getString(R.string.err_empty)
            message.contains("ENOSPC", ignoreCase = true) || message.contains("No space left", ignoreCase = true) -> getString(R.string.err_no_space)
            e is FileNotFoundException -> getString(R.string.err_unreadable)
            else -> getString(R.string.err_generic)
        }
    }

    private fun setBusy(value: Boolean, label: String?) {
        busy = value
        progressRow.visibility = if (value) View.VISIBLE else View.GONE
        if (label != null) progressText.text = label
        saveButton.isEnabled = !value
        cancelButton.isEnabled = !value
        historyButton.isEnabled = !value
    }
}
