package app.comprovantes.pix

import android.content.Context
import java.text.Normalizer
import java.util.Locale

/**
 * Quem é "você" nos comprovantes. Com o seu nome conhecido, o app sabe se um Pix foi entrada
 * (você é o destino) ou saída (você é a origem) sem depender de frases do banco.
 */
object Profile {
    private const val PREFS = "settings"
    private const val KEY_NAMES = "my_names"
    private const val KEY_AUTO = "auto_register"

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun names(context: Context): List<String> =
        prefs(context).getString(KEY_NAMES, "").orEmpty().split('\n').map { it.trim() }.filter { it.length >= 3 }

    fun setNames(context: Context, names: List<String>) {
        val clean = names.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.length >= 3 }
            .distinctBy { normalize(it) }
        prefs(context).edit().putString(KEY_NAMES, clean.joinToString("\n")).apply()
    }

    fun addName(context: Context, name: String) = setNames(context, names(context) + name)

    /** Lançar comprovantes no financeiro assim que forem lidos (ligado por padrão). */
    fun autoRegister(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO, true)

    fun setAutoRegister(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO, value).apply()
    }

    /** Maiúsculas, sem acento e sem pontuação: "José  da Silva" e "JOSE DA SILVA" ficam iguais. */
    fun normalize(value: String): String {
        val decomposed = Normalizer.normalize(value, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return decomposed.uppercase(Locale.ROOT).replace(Regex("[^A-Z0-9]+"), " ").trim()
    }

    /**
     * O nome do comprovante é o seu? Aceita nome completo igual, ou o seu nome (com 2+ palavras)
     * contido no do comprovante, ou o contrário (banco que abrevia o sobrenome).
     */
    fun isMe(partyName: String?, mine: List<String>): Boolean {
        if (partyName.isNullOrBlank() || mine.isEmpty()) return false
        val party = normalize(partyName)
        if (party.isEmpty()) return false
        val partyTokens = party.split(' ').toSet()
        return mine.any { m ->
            val name = normalize(m)
            if (name.isEmpty()) return@any false
            if (name == party) return@any true
            val tokens = name.split(' ').toSet()
            (tokens.size >= 2 && partyTokens.containsAll(tokens)) || (partyTokens.size >= 2 && tokens.containsAll(partyTokens))
        }
    }

    /** "RAFAELA DE SOUSA ANDRADE" -> "Rafaela de Sousa Andrade" (só mexe em nomes todos em maiúsculas). */
    fun pretty(name: String): String {
        val trimmed = name.trim()
        if (trimmed != trimmed.uppercase(Locale.ROOT)) return trimmed
        val small = setOf("de", "da", "do", "das", "dos", "e")
        return trimmed.lowercase(Locale.ROOT).split(' ').filter { it.isNotEmpty() }.mapIndexed { i, w ->
            if (i > 0 && w in small) w else w.replaceFirstChar { it.uppercase(Locale.ROOT) }
        }.joinToString(" ")
    }
}
