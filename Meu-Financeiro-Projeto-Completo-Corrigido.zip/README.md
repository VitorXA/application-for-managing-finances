# Meu Financeiro — Android nativo

Aplicativo Android nativo em Kotlin/XML, sem bibliotecas externas. O projeto começou como um organizador local de comprovantes Pix e foi ampliado para incluir o núcleo de um gerenciador financeiro.

## Funcionalidades implementadas

- Painel inicial com saldo atual, entradas e saídas do período selecionado.
- Cadastro, edição e exclusão de receitas e despesas, incluindo data, categoria, status e valor.
- Configuração de saldo inicial.
- Calendário com visualização por semana, mês e ano, seleção de dia e consulta das movimentações daquele dia.
- Planilhas personalizadas com modelos de gastos, receitas, receitas/despesas e planilha em branco.
- Adição, edição, remoção e reordenação de colunas; tipos texto, número, moeda, data, lista e caixa de seleção.
- Edição de células, registros, indicadores financeiros e cálculo automático de despesas/entradas conforme as colunas configuradas.
- Pesquisa, filtros de período e ordenação nas planilhas.
- Exportação das planilhas em CSV para abrir em planilhas eletrônicas.
- Orçamentos mensais por categoria, com progresso, valor gasto, restante e avisos ao se aproximar ou ultrapassar o limite.
- Relatórios por semana, mês e ano, comparação com o período anterior, gastos por categoria e maiores despesas.
- Comprovantes continuam sendo importados por imagens/PDFs ou recebidos pelo menu Compartilhar do Android, mantendo a cópia no armazenamento privado do app.
- Dados financeiros e planilhas salvos localmente no arquivo privado `finance-data.json`; comprovantes mantidos pelo armazenamento existente `receipts/` e `receipts.json`.

## Observações importantes

- O app não conecta a bancos, não faz pagamentos e não exige internet.
- A importação de um comprovante não cria uma movimentação financeira automaticamente.
- Os totais das planilhas só são contabilizados quando o usuário configura uma coluna monetária como gasto, entrada ou valor automático associado à coluna `Tipo`.
- O CSV exporta os dados da planilha selecionada.
- Exportação/restauração de um backup completo do aplicativo e dos arquivos de comprovantes ainda não foi implementada.
- Esta versão foi verificada estaticamente, mas não foi possível executar a compilação Android neste ambiente porque o Gradle Wrapper tentou acessar `services.gradle.org` e a rede/DNS estava indisponível, e não há Android SDK instalado localmente. A compilação deve ser executada num ambiente com JDK 17, Gradle Wrapper acessível e Android SDK 35.

## Compilar o APK pelo GitHub Actions

O workflow em `.github/workflows/build-apk.yml` continua no projeto. Envie o conteúdo descompactado para um repositório GitHub e execute **Actions → Build Android APK → Run workflow**. Ao terminar, baixe o artefato `comprovantes-pix-apk`.

Versões configuradas: Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.1.10, JDK 17, `compileSdk` 35 e `minSdk` 24.
