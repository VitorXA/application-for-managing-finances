// Versões compatíveis entre si:
//  - Gradle 8.10.2 (wrapper)  - Android Gradle Plugin 8.7.3  - Kotlin 2.1.10  - JDK 17
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.1.10" apply false
}
