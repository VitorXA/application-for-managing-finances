package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class InsightsActivity : Activity() {
    private lateinit var contentHost: FrameLayout
    private lateinit var budgetsTab: Button
    private lateinit var reportsTab: Button
    private var activePage = "budgets"
    private var anchor = Calendar.getInstance()
    private var reportMode = "Mês"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FinanceStore.init(this)
        val root = vertical().apply {
            setBackgroundColor(getColor(R.color.background))
            setPadding(Ui.dp(this@InsightsActivity, 16), Ui.dp(this@InsightsActivity, 8), Ui.dp(this@InsightsActivity, 16), Ui.dp(this@InsightsActivity, 8))
        }
        Ui.applyInsets(root)
        val header = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(button("‹ Voltar", false).apply { setOnClickListener { finish() } }, LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 42)))
        header.addView(label("Controle financeiro", 20, R.color.text_primary, true), LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f))
        root.addView(header)
        val tabs = horizontal().apply { setPadding(0, Ui.dp(this@InsightsActivity, 7), 0, Ui.dp(this@InsightsActivity, 7)) }
        budgetsTab = button("Orçamentos", false)
        reportsTab = button("Relatórios", false)
        tabs.addView(budgetsTab, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { rightMargin = Ui.dp(this@InsightsActivity, 4) })
        tabs.addView(reportsTab, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { leftMargin = Ui.dp(this@InsightsActivity, 4) })
        root.addView(tabs)
        budgetsTab.setOnClickListener { activePage = "budgets"; render() }
        reportsTab.setOnClickListener { activePage = "reports"; render() }
        contentHost = FrameLayout(this)
        root.addView(contentHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::contentHost.isInitialized) render()
    }

    private fun render() {
        budgetsTab.setBackgroundResource(if (activePage == "budgets") R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        budgetsTab.setTextColor(getColor(if (activePage == "budgets") R.color.on_primary else R.color.primary))
        reportsTab.setBackgroundResource(if (activePage == "reports") R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        reportsTab.setTextColor(getColor(if (activePage == "reports") R.color.on_primary else R.color.primary))
        if (activePage == "budgets") showBudgets() else showReports()
    }

    private fun showBudgets() {
        val page = vertical()
        val monthKey = monthKey(anchor)
        val nav = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        nav.addView(button("‹", false).apply { setOnClickListener { anchor.add(Calendar.MONTH, -1); showBudgets() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(label(FinanceDates.monthLabel(anchor), 15, R.color.text_primary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
        nav.addView(button("›", false).apply { setOnClickListener { anchor.add(Calendar.MONTH, 1); showBudgets() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(button("Hoje", false).apply { setOnClickListener { anchor = Calendar.getInstance(); showBudgets() } }, LinearLayout.LayoutParams(Ui.dp(this, 62), Ui.dp(this, 40)).apply { leftMargin = Ui.dp(this@InsightsActivity, 4) })
        page.addView(nav)
        page.addView(button("+ Novo orçamento", true).apply { setOnClickListener { budgetDialog(null, monthKey) } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 44)).apply { topMargin = Ui.dp(this@InsightsActivity, 6); bottomMargin = Ui.dp(this@InsightsActivity, 6) })

        val budgets = FinanceStore.allBudgets().filter { it.month == monthKey }.sortedBy { it.category.lowercase(Locale.ROOT) }
        if (budgets.isEmpty()) page.addView(emptyCard("Nenhum orçamento neste mês", "Defina um limite para acompanhar os gastos por categoria."))
        budgets.forEach { budget -> page.addView(budgetCard(budget), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@InsightsActivity, 7) }) }
        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; addView(page) })
    }

    private fun budgetCard(budget: MonthlyBudget): View {
        val spent = FinanceStore.allTransactions().filter {
            it.status == "DONE" && it.type == "EXPENSE" && it.date.startsWith(budget.month) && it.category.trim().equals(budget.category.trim(), true)
        }.sumOf { it.amountCents }
        val remaining = budget.limitCents - spent
        val percent = if (budget.limitCents <= 0L) 0 else ((spent.toDouble() / budget.limitCents) * 100).toInt().coerceAtLeast(0)
        val progressColor = when { percent >= 100 -> R.color.danger; percent >= 80 -> R.color.warning; else -> R.color.primary }
        val card = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@InsightsActivity, 12), Ui.dp(this@InsightsActivity, 11), Ui.dp(this@InsightsActivity, 12), Ui.dp(this@InsightsActivity, 11))
        }
        val header = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label(budget.category, 15, R.color.text_primary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(button("Editar", false).apply { setOnClickListener { budgetDialog(budget, budget.month) } }, LinearLayout.LayoutParams(Ui.dp(this, 70), Ui.dp(this, 34)))
        header.addView(button("×", false).apply { setOnClickListener { deleteBudget(budget) } }, LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 34)).apply { leftMargin = Ui.dp(this@InsightsActivity, 3) })
        card.addView(header)
        card.addView(label("${FinanceDates.money(spent)} gastos de ${FinanceDates.money(budget.limitCents)}", 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@InsightsActivity, 6), 0, 0) })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = 100; this.progress = percent.coerceAtMost(100)
            progressTintList = android.content.res.ColorStateList.valueOf(getColor(progressColor))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.stroke))
        }
        card.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 7)).apply { topMargin = Ui.dp(this@InsightsActivity, 7) })
        val note = when {
            percent >= 100 -> "Limite ultrapassado em ${FinanceDates.money(-remaining)}"
            percent >= 80 -> "Atenção: ${percent}% do limite utilizado"
            else -> "Restam ${FinanceDates.money(remaining)} · ${percent}% utilizado"
        }
        card.addView(label(note, 12, if (percent >= 80) progressColor else R.color.text_secondary, percent >= 80).apply { setPadding(0, Ui.dp(this@InsightsActivity, 5), 0, 0) })
        return card
    }

    private fun budgetDialog(existing: MonthlyBudget?, selectedMonth: String) {
        val form = vertical().apply { setPadding(Ui.dp(this@InsightsActivity, 5), Ui.dp(this@InsightsActivity, 4), Ui.dp(this@InsightsActivity, 5), 0) }
        val category = editField("Ex.: Alimentação", existing?.category.orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val value = editField("Valor máximo em reais", existing?.let { String.format(Locale.forLanguageTag("pt-BR"), "%.2f", it.limitCents / 100.0) }.orEmpty(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        form.addView(label("Categoria", 13, R.color.text_secondary, false)); form.addView(category)
        form.addView(label("Limite do mês (R$)", 13, R.color.text_secondary, false)); form.addView(value)
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Novo orçamento" else "Editar orçamento")
            .setMessage(FinanceDates.monthLabel(FinanceDates.calendarFor("${selectedMonth}-01")))
            .setView(form).setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val categoryName = category.text.toString().trim()
                val cents = FinanceDates.parseCents(value.text.toString())
                if (categoryName.isBlank()) { category.error = "Informe uma categoria"; return@setOnClickListener }
                if (cents == null || cents <= 0) { value.error = "Informe um limite maior que zero"; return@setOnClickListener }
                val duplicate = if (existing == null) FinanceStore.allBudgets().firstOrNull { it.month == selectedMonth && it.category.equals(categoryName, true) } else null
                val budget = existing ?: duplicate ?: MonthlyBudget(category = categoryName, month = selectedMonth, limitCents = cents)
                budget.category = categoryName; budget.month = selectedMonth; budget.limitCents = cents
                try { FinanceStore.saveBudget(budget); dialog.dismiss(); showBudgets(); Ui.toast(this, "Orçamento salvo") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível salvar o orçamento") }
            }
        }
        dialog.show()
    }

    private fun deleteBudget(budget: MonthlyBudget) {
        AlertDialog.Builder(this).setTitle("Excluir orçamento?").setMessage("As movimentações financeiras não serão excluídas.")
            .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                try { FinanceStore.deleteBudget(budget.id); showBudgets() } catch (_: Exception) { Ui.toast(this, "Não foi possível excluir") }
            }.show()
    }

    private fun showReports() {
        val page = vertical()
        val controls = horizontal()
        listOf("Semana", "Mês", "Ano").forEach { mode ->
            controls.addView(button(mode, reportMode == mode).apply { setOnClickListener { reportMode = mode; showReports() } }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { leftMargin = Ui.dp(this@InsightsActivity, 2); rightMargin = Ui.dp(this@InsightsActivity, 2) })
        }
        page.addView(controls)
        val nav = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        nav.addView(button("‹", false).apply { setOnClickListener { moveReportPeriod(-1); showReports() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        nav.addView(label(reportLabel(), 15, R.color.text_primary, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f))
        nav.addView(button("›", false).apply { setOnClickListener { moveReportPeriod(1); showReports() } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 40)))
        page.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@InsightsActivity, 3); bottomMargin = Ui.dp(this@InsightsActivity, 7) })

        val (start, end) = periodRange(reportMode, anchor)
        val transactions = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end }
        val settled = transactions.filter { it.status == "DONE" }
        val income = settled.filter { it.type == "INCOME" }.sumOf { it.amountCents }
        val expenses = settled.filter { it.type == "EXPENSE" }.sumOf { it.amountCents }
        val pending = transactions.filter { it.status == "PENDING" }
        val summary = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@InsightsActivity, 12), Ui.dp(this@InsightsActivity, 12), Ui.dp(this@InsightsActivity, 12), Ui.dp(this@InsightsActivity, 12))
        }
        val totals = horizontal()
        totals.addView(stat("Entradas", FinanceDates.money(income), R.color.positive), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        totals.addView(stat("Saídas", FinanceDates.money(expenses), R.color.danger), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        totals.addView(stat("Resultado", FinanceDates.money(income - expenses), R.color.text_primary), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        summary.addView(totals)
        summary.addView(label("${transactions.size} movimentação(ões) · ${pending.size} pendente(s)", 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@InsightsActivity, 7), 0, 0) })
        page.addView(summary)

        val previousAnchor = (anchor.clone() as Calendar)
        when (reportMode) { "Semana" -> previousAnchor.add(Calendar.WEEK_OF_YEAR, -1); "Ano" -> previousAnchor.add(Calendar.YEAR, -1); else -> previousAnchor.add(Calendar.MONTH, -1) }
        val previousRange = periodRange(reportMode, previousAnchor)
        val previous = FinanceStore.allTransactions().filter { it.date >= previousRange.first && it.date <= previousRange.second && it.status == "DONE" && it.type == "EXPENSE" }.sumOf { it.amountCents }
        page.addView(label("Comparação de gastos", 16, R.color.text_primary, true).apply { setPadding(0, Ui.dp(this@InsightsActivity, 12), 0, Ui.dp(this@InsightsActivity, 5)) })
        val comparison = when {
            previous == 0L && expenses == 0L -> "Sem gastos registrados nos períodos comparados."
            previous == 0L -> "Você registrou ${FinanceDates.money(expenses)} em gastos neste período; não há gastos no período anterior para comparar."
            expenses > previous -> "Gastos aumentaram ${FinanceDates.money(expenses - previous)} em relação ao período anterior."
            expenses < previous -> "Gastos diminuíram ${FinanceDates.money(previous - expenses)} em relação ao período anterior."
            else -> "Os gastos foram iguais aos do período anterior."
        }
        page.addView(label(comparison, 13, R.color.text_secondary, false))

        page.addView(label("Gastos por categoria", 16, R.color.text_primary, true).apply { setPadding(0, Ui.dp(this@InsightsActivity, 14), 0, Ui.dp(this@InsightsActivity, 5)) })
        val byCategory = settled.filter { it.type == "EXPENSE" }.groupBy { it.category.ifBlank { "Outros" } }
            .mapValues { it.value.sumOf(MoneyTransaction::amountCents) }.entries.sortedByDescending { it.value }
        if (byCategory.isEmpty()) page.addView(label("Nenhuma despesa registrada neste período.", 13, R.color.text_secondary, false))
        else {
            val maxSpent = byCategory.maxOf { it.value }.coerceAtLeast(1L)
            byCategory.forEach { (category, value) ->
                val block = vertical().apply {
                    setPadding(0, Ui.dp(this@InsightsActivity, 5), 0, Ui.dp(this@InsightsActivity, 3))
                }
                val line = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
                line.addView(label(category, 13, R.color.text_primary, false), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(label(FinanceDates.money(value), 13, R.color.text_primary, true))
                block.addView(line)
                val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    this.max = 100; this.progress = ((value.toDouble() / maxSpent) * 100).toInt().coerceIn(1, 100)
                    progressTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.primary))
                    progressBackgroundTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.stroke))
                }
                block.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5)).apply { topMargin = Ui.dp(this@InsightsActivity, 4) })
                page.addView(block)
            }
        }

        page.addView(label("Maiores despesas", 16, R.color.text_primary, true).apply { setPadding(0, Ui.dp(this@InsightsActivity, 14), 0, Ui.dp(this@InsightsActivity, 5)) })
        val biggest = settled.filter { it.type == "EXPENSE" }.sortedByDescending { it.amountCents }.take(5)
        if (biggest.isEmpty()) page.addView(label("Sem despesas para mostrar.", 13, R.color.text_secondary, false))
        biggest.forEach { tx ->
            val row = horizontal().apply {
                background = getDrawable(R.drawable.bg_card)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(this@InsightsActivity, 10), Ui.dp(this@InsightsActivity, 9), Ui.dp(this@InsightsActivity, 10), Ui.dp(this@InsightsActivity, 9))
            }
            val info = vertical()
            info.addView(label(tx.description, 13, R.color.text_primary, true))
            info.addView(label("${tx.category} · ${FinanceDates.display(tx.date)}", 11, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@InsightsActivity, 2), 0, 0) })
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(label(FinanceDates.money(tx.amountCents), 13, R.color.danger, true))
            page.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@InsightsActivity, 5) })
        }

        contentHost.removeAllViews()
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; addView(page) })
    }

    private fun periodRange(mode: String, anchor: Calendar): Pair<String, String> {
        val start = (anchor.clone() as Calendar); val end = (anchor.clone() as Calendar)
        when (mode) {
            "Semana" -> { val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7; start.add(Calendar.DAY_OF_MONTH, -offset); end.timeInMillis = start.timeInMillis; end.add(Calendar.DAY_OF_MONTH, 6) }
            "Ano" -> { start.set(Calendar.MONTH, Calendar.JANUARY); start.set(Calendar.DAY_OF_YEAR, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun moveReportPeriod(delta: Int) {
        when (reportMode) { "Semana" -> anchor.add(Calendar.WEEK_OF_YEAR, delta); "Ano" -> anchor.add(Calendar.YEAR, delta); else -> anchor.add(Calendar.MONTH, delta) }
    }
    private fun reportLabel(): String = when (reportMode) {
        "Semana" -> { val r = periodRange("Semana", anchor); "${FinanceDates.display(r.first)} – ${FinanceDates.display(r.second)}" }
        "Ano" -> anchor.get(Calendar.YEAR).toString()
        else -> FinanceDates.monthLabel(anchor)
    }
    private fun monthKey(cal: Calendar): String = SimpleDateFormat("yyyy-MM", Locale.ROOT).format(cal.time)
    private fun stat(title: String, value: String, color: Int): View = vertical().apply {
        addView(label(title, 11, R.color.text_secondary, false))
        addView(label(value, 13, color, true).apply { setPadding(0, Ui.dp(this@InsightsActivity, 3), 0, 0) })
    }
    private fun emptyCard(title: String, detail: String): View = vertical().apply {
        background = getDrawable(R.drawable.bg_card)
        setPadding(Ui.dp(this@InsightsActivity, 14), Ui.dp(this@InsightsActivity, 16), Ui.dp(this@InsightsActivity, 14), Ui.dp(this@InsightsActivity, 16))
        addView(label(title, 15, R.color.text_primary, true))
        addView(label(detail, 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@InsightsActivity, 4), 0, 0) })
    }
    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(getColor(color)); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun button(value: String, primary: Boolean): Button = Button(this).apply {
        text = value; textSize = 13f; isAllCaps = false; minHeight = Ui.dp(this@InsightsActivity, 38); minimumHeight = Ui.dp(this@InsightsActivity, 38)
        setPadding(Ui.dp(this@InsightsActivity, 7), 0, Ui.dp(this@InsightsActivity, 7), 0)
        setBackgroundResource(if (primary) R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        setTextColor(getColor(if (primary) R.color.on_primary else R.color.primary)); stateListAnimator = null
    }
    private fun editField(hintValue: String, initial: String, inputTypeValue: Int): EditText = EditText(this).apply {
        hint = hintValue; setText(initial); inputType = inputTypeValue; textSize = 14f; maxLines = 1
        setPadding(Ui.dp(this@InsightsActivity, 11), Ui.dp(this@InsightsActivity, 3), Ui.dp(this@InsightsActivity, 11), Ui.dp(this@InsightsActivity, 3))
        setBackgroundResource(R.drawable.bg_input); minimumHeight = Ui.dp(this@InsightsActivity, 42)
    }
}
