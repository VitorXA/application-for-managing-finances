package app.comprovantes.pix

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.FileNotFoundException

/**
 * Permite que outro app (visualizador de imagem/PDF) leia um comprovante salvo, somente leitura,
 * com permissão temporária concedida pelo próprio app.
 */
class ReceiptProvider : ContentProvider() {

    companion object {
        fun uriFor(context: Context, receipt: Receipt): Uri =
            Uri.Builder()
                .scheme("content")
                .authority(context.packageName + ".receipts")
                .appendPath(receipt.storedName)
                .build()
    }

    override fun onCreate(): Boolean = true

    private fun resolve(uri: Uri): Receipt? {
        val ctx = context ?: return null
        ReceiptStore.init(ctx)
        val name = uri.lastPathSegment ?: return null
        return ReceiptStore.findByStoredName(name)
    }

    override fun getType(uri: Uri): String? = resolve(uri)?.mimeType

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val receipt = resolve(uri) ?: return null
        val columns: Array<String> =
            projection?.toList()?.toTypedArray()
                ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val row = arrayOfNulls<Any>(columns.size)
        for (i in columns.indices) {
            row[i] = when (columns[i]) {
                OpenableColumns.DISPLAY_NAME -> receipt.displayName
                OpenableColumns.SIZE -> receipt.sizeBytes
                else -> null
            }
        }
        val cursor = MatrixCursor(columns, 1)
        cursor.addRow(row)
        return cursor
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        if (mode != "r") throw FileNotFoundException("somente leitura")
        val receipt = resolve(uri) ?: throw FileNotFoundException()
        val file = ReceiptStore.fileOf(receipt)
        if (!file.exists()) throw FileNotFoundException()
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0
}
