package app.comprovantes.pix

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView

class HistoryActivity : Activity() {

    private lateinit var countText: TextView
    private lateinit var searchInput: EditText
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var adapter: ReceiptAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        Ui.applyInsets(findViewById(R.id.historyRoot))
        ReceiptStore.init(this)

        countText = findViewById(R.id.countText)
        searchInput = findViewById(R.id.searchInput)
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.emptyView)

        adapter = ReceiptAdapter(this)
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val receipt = adapter.getItem(position)
            startActivity(
                Intent(this, DetailActivity::class.java)
                    .putExtra(DetailActivity.EXTRA_ID, receipt.id)
            )
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refresh()
            }
        })
        searchInput.setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                Ui.hideKeyboard(view)
                true
            } else {
                false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val total = ReceiptStore.count()
        countText.text = resources.getQuantityString(R.plurals.saved_count, total, total)

        val query = searchInput.text.toString().trim()
        val shown = ReceiptStore.search(query)
        adapter.submit(shown)

        when {
            total == 0 -> {
                emptyView.setText(R.string.empty_state)
                emptyView.visibility = View.VISIBLE
            }
            shown.isEmpty() -> {
                emptyView.setText(R.string.no_results)
                emptyView.visibility = View.VISIBLE
            }
            else -> emptyView.visibility = View.GONE
        }
    }
}
