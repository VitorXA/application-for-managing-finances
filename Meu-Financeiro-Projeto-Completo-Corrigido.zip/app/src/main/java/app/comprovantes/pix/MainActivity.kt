package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {

    private companion object {
        const val REQUEST_PICK = 1001
        const val RECENT_LIMIT = 4
    }

    private lateinit var countText: TextView
    private lateinit var searchInput: EditText
    private lateinit var sectionLabel: TextView
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var historyButton: Button
    private lateinit var periodButton: Button
    private lateinit var balanceText: TextView
    private lateinit var incomeText: TextView
    private lateinit var expenseText: TextView
    private lateinit var adapter: ReceiptAdapter
    private var periodMode: String = "Mês"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Ui.applyInsets(findViewById(R.id.mainRoot))
        ReceiptStore.init(this)
        FinanceStore.init(this)

        countText = findViewById(R.id.countText)
        searchInput = findViewById(R.id.searchInput)
        sectionLabel = findViewById(R.id.sectionLabel)
        listView = findViewById(R.id.listView)
        emptyView = findViewById(R.id.emptyView)
        historyButton = findViewById(R.id.historyButton)
        periodButton = findViewById(R.id.periodButton)
        balanceText = findViewById(R.id.balanceText)
        incomeText = findViewById(R.id.incomeText)
        expenseText = findViewById(R.id.expenseText)

        adapter = ReceiptAdapter(this)
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val receipt = adapter.getItem(position)
            startActivity(Intent(this, DetailActivity::class.java).putExtra(DetailActivity.EXTRA_ID, receipt.id))
        }

        findViewById<Button>(R.id.importButton).setOnClickListener { pickFiles() }
        findViewById<Button>(R.id.transactionButton).setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java).putExtra(FinanceActivity.EXTRA_SCREEN, FinanceActivity.SCREEN_TRANSACTIONS))
        }
        findViewById<Button>(R.id.calendarButton).setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java).putExtra(FinanceActivity.EXTRA_SCREEN, FinanceActivity.SCREEN_CALENDAR))
        }
        findViewById<Button>(R.id.sheetsButton).setOnClickListener {
            startActivity(Intent(this, SheetsActivity::class.java))
        }
        findViewById<Button>(R.id.insightsButton).setOnClickListener {
            startActivity(Intent(this, InsightsActivity::class.java))
        }
        periodButton.setOnClickListener { choosePeriod() }
        historyButton.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { refreshReceipts() }
        })
        searchInput.setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { Ui.hideKeyboard(view); true } else false
        }
    }

    override fun onResume() {
        super.onResume()
        refreshDashboard()
        refreshReceipts()
    }

    private fun choosePeriod() {
        val options = arrayOf("Esta semana", "Este mês", "Este ano")
        val checked = when (periodMode) { "Semana" -> 0; "Ano" -> 2; else -> 1 }
        AlertDialog.Builder(this)
            .setTitle("Resumo de qual período?")
            .setSingleChoiceItems(options, checked) { dialog, which ->
                periodMode = when (which) { 0 -> "Semana"; 2 -> "Ano"; else -> "Mês" }
                periodButton.text = options[which] + " ▾"
                dialog.dismiss()
                refreshDashboard()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun rangeForPeriod(): Pair<String, String> {
        val cal = Calendar.getInstance()
        val start: Calendar = (cal.clone() as Calendar)
        val end: Calendar = (cal.clone() as Calendar)
        when (periodMode) {
            "Semana" -> {
                val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7
                start.add(Calendar.DAY_OF_MONTH, -offset)
                end.timeInMillis = start.timeInMillis
                end.add(Calendar.DAY_OF_MONTH, 6)
            }
            "Ano" -> { start.set(Calendar.DAY_OF_YEAR, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun refreshDashboard() {
        countText.text = "Visão geral do seu dinheiro"
        periodButton.text = when (periodMode) { "Semana" -> "Esta semana ▾"; "Ano" -> "Este ano ▾"; else -> "Este mês ▾" }
        balanceText.text = FinanceDates.money(FinanceStore.currentBalance())
        val (start, end) = rangeForPeriod()
        val periodTx = FinanceStore.allTransactions().filter { it.date >= start && it.date <= end && it.status == "DONE" }
        incomeText.text = FinanceDates.money(periodTx.filter { it.type == "INCOME" }.sumOf { it.amountCents })
        expenseText.text = FinanceDates.money(periodTx.filter { it.type == "EXPENSE" }.sumOf { it.amountCents })
    }

    private fun refreshReceipts() {
        val total = ReceiptStore.count()
        val query = searchInput.text.toString().trim()
        val shown = if (query.isEmpty()) ReceiptStore.list().take(RECENT_LIMIT) else ReceiptStore.search(query)
        adapter.submit(shown)
        sectionLabel.text = if (query.isEmpty()) "Comprovantes recentes" else "Resultados da pesquisa"
        historyButton.visibility = if (query.isEmpty()) View.VISIBLE else View.GONE
        when {
            total == 0 -> { emptyView.text = "Nenhum comprovante salvo ainda."; emptyView.visibility = View.VISIBLE }
            shown.isEmpty() -> { emptyView.text = "Nenhum comprovante encontrado."; emptyView.visibility = View.VISIBLE }
            else -> emptyView.visibility = View.GONE
        }
    }

    @Suppress("DEPRECATION")
    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try { startActivityForResult(intent, REQUEST_PICK) }
        catch (_: ActivityNotFoundException) { Ui.toast(this, getString(R.string.picker_missing)) }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) { val uri = clip.getItemAt(i).uri; if (uri != null && !uris.contains(uri)) uris.add(uri) } }
        if (uris.isEmpty()) return
        val forward = Intent(this, ReceiveActivity::class.java).apply {
            action = Intent.ACTION_SEND_MULTIPLE; type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            val clipData = ClipData.newRawUri(null, uris[0])
            for (i in 1 until uris.size) clipData.addItem(ClipData.Item(uris[i]))
            this.clipData = clipData
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(forward)
    }
}
