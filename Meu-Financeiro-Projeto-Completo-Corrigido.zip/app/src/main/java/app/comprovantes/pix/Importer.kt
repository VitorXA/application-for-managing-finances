package app.comprovantes.pix

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lê o que o Android entregou (ACTION_SEND / ACTION_SEND_MULTIPLE) e identifica cada item. */
object Importer {

    sealed class Source {
        data class FileSource(val uri: Uri) : Source()
        data class TextSource(val text: String) : Source()
    }

    /** [problem] != null significa que o item não pode ser salvo (e o motivo é mostrado ao usuário). */
    data class Candidate(
        val source: Source,
        val displayName: String,
        val mime: String?,
        val problem: String?
    ) {
        val supported: Boolean get() = problem == null && mime != null
    }

    fun extract(intent: Intent): List<Source> {
        val out = ArrayList<Source>()
        val seen = HashSet<Uri>()

        fun addUri(uri: Uri?) {
            if (uri != null && seen.add(uri)) out.add(Source.FileSource(uri))
        }

        when (intent.action) {
            Intent.ACTION_SEND -> addUri(streamUri(intent))
            Intent.ACTION_SEND_MULTIPLE -> streamUris(intent).forEach { addUri(it) }
        }

        val clip = intent.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) addUri(clip.getItemAt(i).uri)
        }

        if (out.isEmpty() && intent.action == Intent.ACTION_SEND) {
            val text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            if (!text.isNullOrBlank()) out.add(Source.TextSource(text))
        }
        return out
    }

    fun resolve(context: Context, sources: List<Source>): List<Candidate> {
        val resolver = context.contentResolver
        return sources.map { source ->
            when (source) {
                is Source.TextSource -> Candidate(
                    source = source,
                    displayName = "texto_" + stamp() + ".txt",
                    mime = "text/plain",
                    problem = null
                )
                is Source.FileSource -> resolveFile(context, resolver, source)
            }
        }
    }

    // ---------------------------------------------------------------- internos

    private fun resolveFile(
        context: Context,
        resolver: ContentResolver,
        source: Source.FileSource
    ): Candidate {
        val uri = source.uri
        val declared = normalize(
            try {
                resolver.getType(uri)
            } catch (e: Exception) {
                null
            }
        )

        var mime: String? = if (declared != null && isAccepted(declared)) declared else null
        var problem: String? = null

        if (mime == null) {
            // Tipo ausente ou genérico: confere os primeiros bytes (PDF, PNG ou JPEG).
            try {
                mime = sniff(resolver, uri)
            } catch (e: SecurityException) {
                problem = context.getString(R.string.err_permission)
            } catch (e: Exception) {
                problem = context.getString(R.string.err_unreadable)
            }
            if (mime == null && problem == null) {
                problem = if (declared == null || declared == "application/octet-stream") {
                    context.getString(R.string.err_unknown_format)
                } else {
                    context.getString(R.string.err_unsupported_format, declared)
                }
            }
        }

        var name = (queryName(resolver, uri) ?: "comprovante_" + stamp()).trim().take(120)
        if (name.isEmpty()) name = "comprovante_" + stamp()
        if (mime != null && !name.contains('.')) {
            name = name + "." + ReceiptStore.extensionFor(mime)
        }
        return Candidate(source, name, mime, problem)
    }

    private fun isAccepted(mime: String): Boolean =
        mime.startsWith("image/") || mime == "application/pdf" || mime == "text/plain"

    private fun normalize(mime: String?): String? =
        mime?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.isNotEmpty() }

    private fun sniff(resolver: ContentResolver, uri: Uri): String? {
        val header = ByteArray(8)
        val stream = resolver.openInputStream(uri) ?: throw IOException("sem fluxo de leitura")
        val n = stream.use { it.read(header) }
        if (n < 3) return null
        val b0 = header[0].toInt() and 0xFF
        val b1 = header[1].toInt() and 0xFF
        val b2 = header[2].toInt() and 0xFF
        val b3 = if (n >= 4) header[3].toInt() and 0xFF else -1
        return when {
            b0 == 0x25 && b1 == 0x50 && b2 == 0x44 && b3 == 0x46 -> "application/pdf"
            b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47 -> "image/png"
            b0 == 0xFF && b1 == 0xD8 && b2 == 0xFF -> "image/jpeg"
            else -> null
        }
    }

    private fun queryName(resolver: ContentResolver, uri: Uri): String? {
        return try {
            val fromProvider = resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0 && !cursor.isNull(index)) cursor.getString(index) else null
                } else {
                    null
                }
            }
            fromProvider ?: uri.lastPathSegment
        } catch (e: Exception) {
            uri.lastPathSegment
        }
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())

    @Suppress("DEPRECATION")
    private fun streamUri(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }

    @Suppress("DEPRECATION")
    private fun streamUris(intent: Intent): List<Uri> {
        val list: List<Uri>? =
            if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
        return list ?: emptyList()
    }
}
