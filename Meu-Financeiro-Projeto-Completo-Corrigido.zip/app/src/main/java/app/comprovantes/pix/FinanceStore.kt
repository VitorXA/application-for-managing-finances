package app.comprovantes.pix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.math.BigDecimal
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Modelos e armazenamento local das funções financeiras. */
data class MoneyTransaction(
    val id: String = UUID.randomUUID().toString(),
    var type: String,
    var description: String,
    var amountCents: Long,
    var date: String,
    var category: String,
    var status: String = "DONE",
    var receiptId: String? = null
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("type", type); put("description", description)
        put("amountCents", amountCents); put("date", date); put("category", category); put("status", status)
        put("receiptId", receiptId)
    }
    companion object {
        fun fromJson(o: JSONObject) = MoneyTransaction(
            id = o.optString("id", UUID.randomUUID().toString()),
            type = o.optString("type", "EXPENSE"),
            description = o.optString("description", ""),
            amountCents = o.optLong("amountCents", 0L),
            date = o.optString("date", FinanceDates.today()),
            category = o.optString("category", "Outros"),
            status = o.optString("status", "DONE"),
            receiptId = o.optString("receiptId", "").takeIf { it.isNotBlank() }
        )
    }
}

data class SheetColumn(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var type: String = "TEXT",
    var role: String = "NONE",
    var options: MutableList<String> = mutableListOf()
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("type", type); put("role", role)
        put("options", JSONArray().also { a -> options.forEach { a.put(it) } })
    }
    companion object {
        fun fromJson(o: JSONObject): SheetColumn {
            val options = mutableListOf<String>()
            val a = o.optJSONArray("options") ?: JSONArray()
            for (i in 0 until a.length()) options.add(a.optString(i, ""))
            return SheetColumn(
                id = o.optString("id", UUID.randomUUID().toString()),
                name = o.optString("name", "Campo"),
                type = o.optString("type", "TEXT"),
                role = o.optString("role", "NONE"),
                options = options
            )
        }
    }
}

data class SheetRow(
    val id: String = UUID.randomUUID().toString(),
    val cells: MutableMap<String, String> = linkedMapOf()
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        val values = JSONObject()
        cells.forEach { (k, v) -> values.put(k, v) }
        put("cells", values)
    }
    companion object {
        fun fromJson(o: JSONObject): SheetRow {
            val cells = linkedMapOf<String, String>()
            val values = o.optJSONObject("cells") ?: JSONObject()
            val keys = values.keys()
            while (keys.hasNext()) { val key = keys.next(); cells[key] = values.optString(key, "") }
            return SheetRow(o.optString("id", UUID.randomUUID().toString()), cells)
        }
    }
}

data class FinanceSheet(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var description: String = "",
    val columns: MutableList<SheetColumn> = mutableListOf(),
    val rows: MutableList<SheetRow> = mutableListOf(),
    var showSpent: Boolean = true,
    var showIncome: Boolean = false,
    var showBalance: Boolean = false,
    var updatedAt: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("description", description)
        put("columns", JSONArray().also { a -> columns.forEach { a.put(it.toJson()) } })
        put("rows", JSONArray().also { a -> rows.forEach { a.put(it.toJson()) } })
        put("showSpent", showSpent); put("showIncome", showIncome); put("showBalance", showBalance); put("updatedAt", updatedAt)
    }
    companion object {
        fun fromJson(o: JSONObject): FinanceSheet {
            val columns = mutableListOf<SheetColumn>()
            val ca = o.optJSONArray("columns") ?: JSONArray()
            for (i in 0 until ca.length()) columns.add(SheetColumn.fromJson(ca.getJSONObject(i)))
            val rows = mutableListOf<SheetRow>()
            val ra = o.optJSONArray("rows") ?: JSONArray()
            for (i in 0 until ra.length()) rows.add(SheetRow.fromJson(ra.getJSONObject(i)))
            return FinanceSheet(
                id = o.optString("id", UUID.randomUUID().toString()), name = o.optString("name", "Minha planilha"),
                description = o.optString("description", ""), columns = columns, rows = rows,
                showSpent = o.optBoolean("showSpent", true), showIncome = o.optBoolean("showIncome", false),
                showBalance = o.optBoolean("showBalance", false), updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    }
}

data class SheetTotals(val expensesCents: Long, val incomeCents: Long, val records: Int) {
    val balanceCents: Long get() = incomeCents - expensesCents
}

data class MonthlyBudget(
    val id: String = UUID.randomUUID().toString(),
    var category: String,
    var month: String,
    var limitCents: Long
) {
    fun toJson() = JSONObject().apply { put("id", id); put("category", category); put("month", month); put("limitCents", limitCents) }
    companion object {
        fun fromJson(o: JSONObject) = MonthlyBudget(
            id = o.optString("id", UUID.randomUUID().toString()),
            category = o.optString("category", "Outros"),
            month = o.optString("month", FinanceDates.today().take(7)),
            limitCents = o.optLong("limitCents", 0L)
        )
    }
}

object FinanceDates {
    private val keyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT)
    fun today(): String = synchronized(keyFormat) { keyFormat.format(Date()) }
    fun display(key: String): String = try {
        val date = synchronized(keyFormat) { keyFormat.parse(key) }
        if (date == null) key else SimpleDateFormat("dd/MM/yyyy", Locale.forLanguageTag("pt-BR")).format(date)
    } catch (_: Exception) { key }
    fun parseCents(raw: String): Long? {
        val cleaned = raw.trim().replace("R$", "", ignoreCase = true).replace(" ", "")
        if (cleaned.isEmpty()) return null
        val normalized = when {
            cleaned.contains(',') -> cleaned.replace(".", "").replace(',', '.')
            else -> cleaned
        }
        return try { BigDecimal(normalized).setScale(2, java.math.RoundingMode.HALF_UP).movePointRight(2).longValueExact() } catch (_: Exception) { null }
    }
    fun money(cents: Long): String = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR")).format(cents / 100.0)
    fun dateForMillis(millis: Long): String = synchronized(keyFormat) { keyFormat.format(Date(millis)) }
    fun calendarFor(key: String): Calendar {
        val cal = Calendar.getInstance()
        try { val date = synchronized(keyFormat) { keyFormat.parse(key) }; if (date != null) cal.time = date } catch (_: Exception) { }
        cal.set(Calendar.HOUR_OF_DAY, 12); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal
    }
    fun monthLabel(cal: Calendar): String = SimpleDateFormat("MMMM 'de' yyyy", Locale.forLanguageTag("pt-BR")).format(cal.time).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }
    fun monthShort(cal: Calendar): String = SimpleDateFormat("MMM", Locale.forLanguageTag("pt-BR")).format(cal.time).replaceFirstChar { it.uppercase(Locale.forLanguageTag("pt-BR")) }
}

object FinanceStore {
    private val lock = Any()
    private var initialized = false
    private lateinit var file: File
    private val transactions = mutableListOf<MoneyTransaction>()
    private val sheets = mutableListOf<FinanceSheet>()
    private val budgets = mutableListOf<MonthlyBudget>()
    private var openingBalanceCents: Long = 0L

    fun init(context: Context) = synchronized(lock) {
        if (initialized) return@synchronized
        file = File(context.applicationContext.filesDir, "finance-data.json")
        if (file.exists()) {
            try {
                val root = JSONObject(file.readText(Charsets.UTF_8))
                val tx = root.optJSONArray("transactions") ?: JSONArray()
                for (i in 0 until tx.length()) transactions.add(MoneyTransaction.fromJson(tx.getJSONObject(i)))
                val sh = root.optJSONArray("sheets") ?: JSONArray()
                for (i in 0 until sh.length()) sheets.add(FinanceSheet.fromJson(sh.getJSONObject(i)))
                val bs = root.optJSONArray("budgets") ?: JSONArray()
                for (i in 0 until bs.length()) budgets.add(MonthlyBudget.fromJson(bs.getJSONObject(i)))
                openingBalanceCents = root.optLong("openingBalanceCents", 0L)
            } catch (_: Exception) {
                // Não sobrescreve automaticamente um arquivo ilegível: mantém cópia para recuperação.
                val backup = File(file.parentFile, "finance-data.json.corrupt")
                if (!backup.exists()) file.copyTo(backup, overwrite = false)
                transactions.clear(); sheets.clear(); budgets.clear()
            }
        }
        initialized = true
    }

    fun allTransactions(): List<MoneyTransaction> = synchronized(lock) { transactions.map { it.copy() }.sortedByDescending { it.date } }
    fun transaction(id: String): MoneyTransaction? = synchronized(lock) { transactions.firstOrNull { it.id == id }?.copy() }
    fun saveTransaction(item: MoneyTransaction) = synchronized(lock) {
        val index = transactions.indexOfFirst { it.id == item.id }
        val old = if (index >= 0) transactions[index] else null
        if (index >= 0) transactions[index] = item else transactions.add(item)
        try { persist() } catch (e: Exception) { if (old != null) transactions[index] = old else transactions.removeAll { it.id == item.id }; throw e }
    }
    fun deleteTransaction(id: String) = synchronized(lock) {
        val index = transactions.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized
        val old = transactions.removeAt(index)
        try { persist() } catch (e: Exception) { transactions.add(index, old); throw e }
    }
    fun allSheets(): List<FinanceSheet> = synchronized(lock) { sheets.map { FinanceSheet.fromJson(it.toJson()) }.sortedByDescending { it.updatedAt } }
    fun sheet(id: String): FinanceSheet? = synchronized(lock) { sheets.firstOrNull { it.id == id }?.let { FinanceSheet.fromJson(it.toJson()) } }
    fun saveSheet(sheet: FinanceSheet) = synchronized(lock) {
        sheet.updatedAt = System.currentTimeMillis()
        val index = sheets.indexOfFirst { it.id == sheet.id }
        val old = if (index >= 0) sheets[index] else null
        val snapshot = FinanceSheet.fromJson(sheet.toJson())
        if (index >= 0) sheets[index] = snapshot else sheets.add(snapshot)
        try { persist() } catch (e: Exception) { if (old != null) sheets[index] = old else sheets.removeAll { it.id == sheet.id }; throw e }
    }
    fun deleteSheet(id: String) = synchronized(lock) {
        val index = sheets.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized
        val old = sheets.removeAt(index)
        try { persist() } catch (e: Exception) { sheets.add(index, old); throw e }
    }
    fun allBudgets(): List<MonthlyBudget> = synchronized(lock) { budgets.map { it.copy() } }
    fun saveBudget(budget: MonthlyBudget) = synchronized(lock) {
        val index = budgets.indexOfFirst { it.id == budget.id }
        val old = if (index >= 0) budgets[index] else null
        if (index >= 0) budgets[index] = budget.copy() else budgets.add(budget.copy())
        try { persist() } catch (e: Exception) { if (old != null) budgets[index] = old else budgets.removeAll { it.id == budget.id }; throw e }
    }
    fun deleteBudget(id: String) = synchronized(lock) {
        val index = budgets.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized
        val old = budgets.removeAt(index)
        try { persist() } catch (e: Exception) { budgets.add(index, old); throw e }
    }
    fun openingBalance(): Long = synchronized(lock) { openingBalanceCents }
    fun setOpeningBalance(cents: Long) = synchronized(lock) { val old = openingBalanceCents; openingBalanceCents = cents; try { persist() } catch (e: Exception) { openingBalanceCents = old; throw e } }
    fun currentBalance(): Long = synchronized(lock) { openingBalanceCents + transactions.filter { it.status == "DONE" }.sumOf { if (it.type == "INCOME") it.amountCents else -it.amountCents } }

    fun sheetTotals(sheet: FinanceSheet): SheetTotals {
        var spent = 0L; var income = 0L
        val moneyColumns = sheet.columns.filter { it.type == "MONEY" && it.role != "NONE" }
        val statusColumn = sheet.columns.firstOrNull { it.name.trim().equals("situação", true) || it.name.trim().equals("situacao", true) || it.name.trim().equals("status", true) }
        sheet.rows.forEach rowLoop@ { row ->
            val status = statusColumn?.let { row.cells[it.id].orEmpty() }?.lowercase(Locale.ROOT).orEmpty()
            if (status.contains("pendente") || status.contains("a pagar") || status.contains("aguardando") || status.contains("não pago") || status.contains("nao pago")) return@rowLoop
            moneyColumns.forEach columnLoop@ { column ->
                val amount = FinanceDates.parseCents(row.cells[column.id] ?: "") ?: return@columnLoop
                when (column.role) {
                    "EXPENSE" -> spent += amount
                    "INCOME" -> income += amount
                    "AUTO" -> {
                        val typeColumn = sheet.columns.firstOrNull { it.name.trim().equals("tipo", true) || it.name.trim().equals("movimentação", true) }
                            ?: sheet.columns.firstOrNull { it.type == "CHOICE" && it.options.any { option -> option.contains("receit", true) || option.contains("despes", true) } }
                        val type = typeColumn?.let { row.cells[it.id].orEmpty() }?.lowercase(Locale.ROOT).orEmpty()
                        if (type.contains("receit") || type.contains("entrad") || type.contains("income")) income += amount
                        else if (typeColumn != null && (type.contains("despes") || type.contains("saída") || type.contains("saida") || type.contains("expense"))) spent += amount
                    }
                }
            }
        }
        return SheetTotals(spent, income, sheet.rows.size)
    }

    private fun persist() {
        val root = JSONObject().apply {
            put("schemaVersion", 1)
            put("openingBalanceCents", openingBalanceCents)
            put("transactions", JSONArray().also { array -> transactions.forEach { array.put(it.toJson()) } })
            put("sheets", JSONArray().also { array -> sheets.forEach { array.put(it.toJson()) } })
            put("budgets", JSONArray().also { array -> budgets.forEach { array.put(it.toJson()) } })
        }
        val temp = File(file.parentFile, "finance-data.json.tmp")
        FileOutputStream(temp).use { out -> out.write(root.toString().toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync() }
        if (!temp.renameTo(file)) {
            // Renomeação compatível com sistemas de arquivo que não substituem destino existente.
            val backup = File(file.parentFile, "finance-data.json.bak")
            if (file.exists() && !file.renameTo(backup)) { temp.delete(); throw IOException("Não foi possível atualizar os dados financeiros") }
            if (!temp.renameTo(file)) {
                if (backup.exists()) backup.renameTo(file)
                temp.delete(); throw IOException("Não foi possível salvar os dados financeiros")
            }
            backup.delete()
        }
    }
}
