package app.comprovantes.pix

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class SheetsActivity : Activity() {
    private lateinit var contentHost: LinearLayout
    private var activeSheetId: String? = null
    private var exportSheetId: String? = null
    private val createCsvRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FinanceStore.init(this)
        val root = vertical().apply {
            setBackgroundColor(getColor(R.color.background))
            setPadding(Ui.dp(this@SheetsActivity, 16), Ui.dp(this@SheetsActivity, 8), Ui.dp(this@SheetsActivity, 16), Ui.dp(this@SheetsActivity, 8))
        }
        Ui.applyInsets(root)
        val header = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(makeButton("‹ Voltar", false).apply { setOnClickListener { if (activeSheetId != null) { activeSheetId = null; showList() } else finish() } }, LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 42)))
        header.addView(label("Minhas planilhas", 21, R.color.text_primary, true), LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f))
        root.addView(header)
        contentHost = vertical()
        root.addView(contentHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        showList()
    }

    override fun onResume() {
        super.onResume()
        if (::contentHost.isInitialized) { if (activeSheetId == null) showList() else showSheet(activeSheetId!!) }
    }

    private fun showList() {
        activeSheetId = null
        contentHost.removeAllViews()
        val page = vertical()
        page.addView(label("Controles do seu jeito", 14, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 3), 0, Ui.dp(this@SheetsActivity, 8)) })
        page.addView(makeButton("+ Nova planilha", true).apply { setOnClickListener { createSheetDialog() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46)))
        val sheets = FinanceStore.allSheets()
        if (sheets.isEmpty()) {
            page.addView(emptyCard("Nenhuma planilha criada", "Crie um controle de gastos, uma lista de compras ou uma planilha em branco."), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 10) })
        } else {
            sheets.forEach { sheet ->
                page.addView(sheetCard(sheet), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 8) })
            }
        }
        contentHost.addView(ScrollView(this).apply { isFillViewport = true; addView(page) })
    }

    private fun sheetCard(sheet: FinanceSheet): View {
        val totals = FinanceStore.sheetTotals(sheet)
        val hasExpense = sheet.columns.any { it.type == "MONEY" && it.role == "EXPENSE" } || sheet.columns.any { it.type == "MONEY" && it.role == "AUTO" }
        val hasIncome = sheet.columns.any { it.type == "MONEY" && (it.role == "INCOME" || it.role == "AUTO") }
        val card = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@SheetsActivity, 13), Ui.dp(this@SheetsActivity, 12), Ui.dp(this@SheetsActivity, 10), Ui.dp(this@SheetsActivity, 11))
        }
        val top = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        val info = vertical()
        info.addView(label(sheet.name, 16, R.color.text_primary, true))
        if (sheet.description.isNotBlank()) info.addView(label(sheet.description, 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 2), 0, 0) })
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(makeButton("⋮", false).apply { setOnClickListener { sheetMenu(sheet.id) } }, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 38)))
        card.addView(top)
        card.addView(View(this).apply { setBackgroundColor(getColor(R.color.stroke)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)).apply { topMargin = Ui.dp(this@SheetsActivity, 9); bottomMargin = Ui.dp(this@SheetsActivity, 8) })
        val stats = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        val statText = buildList {
            if (sheet.showSpent) add(if (hasExpense) "Gastos: ${FinanceDates.money(totals.expensesCents)}" else "Gastos: configure um campo de valor")
            if (sheet.showIncome) add(if (hasIncome) "Entradas: ${FinanceDates.money(totals.incomeCents)}" else "Entradas: configure um campo de valor")
            if (sheet.showBalance && (hasExpense || hasIncome)) add("Saldo: ${FinanceDates.money(totals.balanceCents)}")
        }
        val statBox = vertical()
        if (statText.isEmpty()) statBox.addView(label("${sheet.rows.size} registro(s)", 13, R.color.text_secondary, false))
        else statText.forEachIndexed { idx, s -> statBox.addView(label(s, 14, if (s.startsWith("Gastos:")) R.color.danger else if (s.startsWith("Entradas:")) R.color.positive else R.color.text_primary, idx == 0).apply { if (idx > 0) setPadding(0, Ui.dp(this@SheetsActivity, 3), 0, 0) }) }
        stats.addView(statBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(label("${sheet.rows.size} registro(s)", 12, R.color.text_secondary, false))
        card.addView(stats)
        card.addView(label("Toque para abrir e editar", 11, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 6), 0, 0) })
        card.setOnClickListener { activeSheetId = sheet.id; showSheet(sheet.id) }
        return card
    }

    private fun showSheet(id: String) {
        val sheet = FinanceStore.sheet(id)
        if (sheet == null) { activeSheetId = null; showList(); return }
        activeSheetId = id
        contentHost.removeAllViews()
        val page = vertical()
        val titleRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(label(sheet.name, 18, R.color.text_primary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        titleRow.addView(makeButton("Opções", false).apply { setOnClickListener { sheetMenu(sheet.id) } }, LinearLayout.LayoutParams(Ui.dp(this, 88), Ui.dp(this, 38)))
        page.addView(titleRow)
        if (sheet.description.isNotBlank()) page.addView(label(sheet.description, 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 3), 0, 0) })

        val totals = FinanceStore.sheetTotals(sheet)
        val expenseColumn = sheet.columns.any { it.type == "MONEY" && (it.role == "EXPENSE" || it.role == "AUTO") }
        val incomeColumn = sheet.columns.any { it.type == "MONEY" && (it.role == "INCOME" || it.role == "AUTO") }
        val summary = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@SheetsActivity, 12), Ui.dp(this@SheetsActivity, 9), Ui.dp(this@SheetsActivity, 12), Ui.dp(this@SheetsActivity, 9))
        }
        val summaryRow = horizontal()
        if (sheet.showSpent) summaryRow.addView(statBlock("Gastos", if (expenseColumn) FinanceDates.money(totals.expensesCents) else "Não configurado", R.color.danger), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (sheet.showIncome) summaryRow.addView(statBlock("Entradas", if (incomeColumn) FinanceDates.money(totals.incomeCents) else "Não configurado", R.color.positive), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (sheet.showBalance && (expenseColumn || incomeColumn)) summaryRow.addView(statBlock("Saldo", FinanceDates.money(totals.balanceCents), R.color.text_primary), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (summaryRow.childCount > 0) summary.addView(summaryRow)
        summary.addView(label("${sheet.rows.size} registro(s) · Toque em um campo para editar", 12, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 6), 0, 0) })
        page.addView(summary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 8); bottomMargin = Ui.dp(this@SheetsActivity, 8) })

        val actions = horizontal()
        actions.addView(makeButton("+ Registro", true).apply { setOnClickListener { addRow(sheet.id) } }, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { rightMargin = Ui.dp(this@SheetsActivity, 3) })
        actions.addView(makeButton("+ Coluna", false).apply { setOnClickListener { addColumn(sheet.id) } }, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { leftMargin = Ui.dp(this@SheetsActivity, 3); rightMargin = Ui.dp(this@SheetsActivity, 3) })
        actions.addView(makeButton("Colunas", false).apply { setOnClickListener { manageColumns(sheet.id) } }, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { leftMargin = Ui.dp(this@SheetsActivity, 3) })
        page.addView(actions)
        page.addView(makeButton("Exportar CSV", false).apply { setOnClickListener { exportSheet(sheet.id) } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)).apply { topMargin = Ui.dp(this@SheetsActivity, 5) })

        val search = editField("Pesquisar nesta planilha", "", InputType.TYPE_CLASS_TEXT)
        page.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 42)).apply { topMargin = Ui.dp(this@SheetsActivity, 7) })
        val filters = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        val periodOptions = listOf("Todo período", "Esta semana", "Este mês", "Este ano")
        val periodSpinner = spinner(periodOptions, 0)
        val sortOptions = listOf("Ordem original") + sheet.columns.map { it.name }
        val sortSpinner = spinner(sortOptions, 0)
        val directionButton = makeButton("↑", false)
        filters.addView(periodSpinner, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { rightMargin = Ui.dp(this@SheetsActivity, 3) })
        filters.addView(sortSpinner, LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f).apply { leftMargin = Ui.dp(this@SheetsActivity, 3); rightMargin = Ui.dp(this@SheetsActivity, 3) })
        filters.addView(directionButton, LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 40)).apply { leftMargin = Ui.dp(this@SheetsActivity, 3) })
        page.addView(filters, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 3) })

        val rowsHost = vertical()
        page.addView(rowsHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        var descending = false
        fun refreshRows() {
            rowsHost.removeAllViews()
            val query = search.text.toString().trim().lowercase(Locale.ROOT)
            val dateColumn = sheet.columns.firstOrNull { it.type == "DATE" } ?: sheet.columns.firstOrNull { it.name.equals("data", true) }
            val periodMode = when (periodSpinner.selectedItemPosition) { 1 -> "Semana"; 2 -> "Mês"; 3 -> "Ano"; else -> "Todos" }
            val bounds = if (periodMode == "Todos") null else sheetDateRange(periodMode)
            val visibleRows = sheet.rows.filter { row ->
                val matchesText = query.isBlank() || sheet.columns.any { (row.cells[it.id] ?: "").lowercase(Locale.ROOT).contains(query) }
                val date = dateColumn?.let { row.cells[it.id].orEmpty() }.orEmpty()
                val matchesDate = bounds == null || (date >= bounds.first && date <= bounds.second)
                matchesText && matchesDate
            }.toMutableList()
            val selectedSort = sortSpinner.selectedItemPosition - 1
            val sortColumn = sheet.columns.getOrNull(selectedSort)
            if (sortColumn != null) {
                val comparator = Comparator<SheetRow> { a, b ->
                    val av = a.cells[sortColumn.id].orEmpty()
                    val bv = b.cells[sortColumn.id].orEmpty()
                    when (sortColumn.type) {
                        "MONEY" -> (FinanceDates.parseCents(av) ?: Long.MIN_VALUE).compareTo(FinanceDates.parseCents(bv) ?: Long.MIN_VALUE)
                        "NUMBER" -> (av.toDoubleOrNull() ?: Double.NEGATIVE_INFINITY).compareTo(bv.toDoubleOrNull() ?: Double.NEGATIVE_INFINITY)
                        else -> av.compareTo(bv, ignoreCase = true)
                    }
                }
                visibleRows.sortWith(if (descending) comparator.reversed() else comparator)
            }
            if (visibleRows.isEmpty()) {
                rowsHost.addView(emptyCard(if (sheet.rows.isEmpty()) "Sua planilha está vazia" else "Nenhum registro encontrado", if (sheet.rows.isEmpty()) "Adicione um registro para começar." else "Experimente alterar a pesquisa ou os filtros."), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 9) })
            } else visibleRows.forEachIndexed { index, row -> rowsHost.addView(rowCard(sheet, row, index), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(this@SheetsActivity, 7) }) }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refreshRows() }
            override fun afterTextChanged(s: Editable?) {}
        })
        periodSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshRows() }
        }
        sortSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshRows() }
        }
        directionButton.setOnClickListener { descending = !descending; directionButton.text = if (descending) "↓" else "↑"; refreshRows() }
        refreshRows()

        contentHost.addView(ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(page) })
    }

    private fun rowCard(sheet: FinanceSheet, row: SheetRow, index: Int): View {
        val card = vertical().apply {
            background = getDrawable(R.drawable.bg_card)
            setPadding(Ui.dp(this@SheetsActivity, 11), Ui.dp(this@SheetsActivity, 10), Ui.dp(this@SheetsActivity, 11), Ui.dp(this@SheetsActivity, 10))
        }
        val head = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Registro ${index + 1}", 13, R.color.text_primary, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(makeButton("Editar linha", false).apply { setOnClickListener { editRow(sheet.id, row.id) } }, LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 34)))
        head.addView(makeButton("×", false).apply { setOnClickListener { deleteRow(sheet.id, row.id) } }, LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 34)).apply { leftMargin = Ui.dp(this@SheetsActivity, 3) })
        card.addView(head)
        sheet.columns.forEach { col ->
            val raw = row.cells[col.id].orEmpty()
            val shown = if (col.type == "MONEY") FinanceDates.parseCents(raw)?.let { FinanceDates.money(it) } ?: raw else if (col.type == "DATE") FinanceDates.display(raw) else raw
            val tv = label("${col.name}: ${shown.ifBlank { "—" }}", 13, if (col.role == "EXPENSE") R.color.danger else R.color.text_secondary, false)
            tv.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 2))
            tv.isClickable = true; tv.isFocusable = true
            tv.setOnClickListener { editCell(sheet.id, row.id, col.id) }
            card.addView(tv)
        }
        return card
    }

    private fun createSheetDialog() {
        val form = vertical().apply { setPadding(Ui.dp(this@SheetsActivity, 5), Ui.dp(this@SheetsActivity, 4), Ui.dp(this@SheetsActivity, 5), 0) }
        val name = editField("Nome da planilha", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Nome", 13, R.color.text_secondary, false)); form.addView(name)
        form.addView(label("Modelo inicial", 13, R.color.text_secondary, false))
        val templates = spinner(listOf("Controle de gastos", "Receitas e despesas", "Receitas", "Em branco"), 0)
        form.addView(templates)
        val dialog = AlertDialog.Builder(this).setTitle("Nova planilha").setView(form).setNegativeButton("Cancelar", null).setPositiveButton("Criar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = name.text.toString().trim()
                if (title.isBlank()) { name.error = "Dê um nome à planilha"; return@setOnClickListener }
                val sheet = makeTemplate(title, templates.selectedItemPosition)
                try { FinanceStore.saveSheet(sheet); dialog.dismiss(); activeSheetId = sheet.id; showSheet(sheet.id); Ui.toast(this, "Planilha criada") }
                catch (_: Exception) { Ui.toast(this, "Não foi possível criar a planilha") }
            }
        }
        dialog.show()
    }

    private fun makeTemplate(name: String, index: Int): FinanceSheet {
        val columns = mutableListOf<SheetColumn>()
        fun col(label: String, type: String = "TEXT", role: String = "NONE", options: List<String> = emptyList()) { columns.add(SheetColumn(name = label, type = type, role = role, options = options.toMutableList())) }
        val categories = listOf("Alimentação", "Moradia", "Transporte", "Saúde", "Educação", "Lazer", "Compras", "Outros")
        val statuses = listOf("Pago", "Pendente")
        when (index) {
            0 -> { col("Data", "DATE"); col("Descrição"); col("Categoria", "CHOICE", options = categories); col("Valor", "MONEY", "EXPENSE"); col("Situação", "CHOICE", options = statuses) }
            1 -> { col("Data", "DATE"); col("Descrição"); col("Tipo", "CHOICE", options = listOf("Despesa", "Receita")); col("Categoria", "CHOICE", options = categories); col("Valor", "MONEY", "AUTO"); col("Situação", "CHOICE", options = statuses) }
            2 -> { col("Data", "DATE"); col("Descrição"); col("Categoria", "CHOICE", options = categories); col("Valor", "MONEY", "INCOME"); col("Situação", "CHOICE", options = statuses) }
            else -> { col("Campo 1"); col("Campo 2") }
        }
        return FinanceSheet(name = name, description = "", columns = columns, showSpent = true, showIncome = index == 1 || index == 2, showBalance = index == 1)
    }

    private fun sheetMenu(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        val options = arrayOf("Renomear", "Escolher indicadores do card", "Duplicar", "Exportar CSV", "Excluir planilha")
        AlertDialog.Builder(this).setTitle(sheet.name).setItems(options) { _, which ->
            when (which) {
                0 -> renameSheet(id)
                1 -> chooseIndicators(id)
                2 -> duplicateSheet(id)
                3 -> exportSheet(id)
                4 -> AlertDialog.Builder(this).setTitle("Excluir planilha?").setMessage("Os registros desta planilha serão excluídos. Movimentações e comprovantes independentes não serão apagados.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                        try { FinanceStore.deleteSheet(id); if (activeSheetId == id) activeSheetId = null; showList(); Ui.toast(this, "Planilha excluída") }
                        catch (_: Exception) { Ui.toast(this, "Não foi possível excluir") }
                    }.show()
            }
        }.show()
    }

    private fun renameSheet(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        val input = editField("Nome da planilha", sheet.name, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        AlertDialog.Builder(this).setTitle("Renomear planilha").setView(input).setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isBlank()) { Ui.toast(this, "Informe um nome") } else {
                    sheet.name = newName
                    try { FinanceStore.saveSheet(sheet); refreshCurrentSheet() } catch (_: Exception) { Ui.toast(this, "Não foi possível salvar") }
                }
            }.show()
    }

    private fun chooseIndicators(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        val labels = arrayOf("Mostrar total gasto", "Mostrar total de entradas", "Mostrar saldo")
        val selected = booleanArrayOf(sheet.showSpent, sheet.showIncome, sheet.showBalance)
        AlertDialog.Builder(this).setTitle("Indicadores no card").setMultiChoiceItems(labels, selected) { _, which, checked -> selected[which] = checked }
            .setNegativeButton("Cancelar", null).setPositiveButton("Salvar") { _, _ ->
                sheet.showSpent = selected[0]; sheet.showIncome = selected[1]; sheet.showBalance = selected[2]
                try { FinanceStore.saveSheet(sheet); refreshCurrentSheet() } catch (_: Exception) { Ui.toast(this, "Não foi possível salvar") }
            }.show()
    }

    private fun duplicateSheet(id: String) {
        val original = FinanceStore.sheet(id) ?: return
        val input = editField("Nome da cópia", "Cópia de ${original.name}", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val builder = AlertDialog.Builder(this).setTitle("Duplicar planilha").setView(input)
            .setNegativeButton("Cancelar", null).setPositiveButton("Duplicar com registros") { _, _ ->
                duplicateAndSave(original, input.text.toString(), true)
            }
        builder.setNeutralButton("Só a estrutura") { _, _ -> duplicateAndSave(original, input.text.toString(), false) }.show()
    }

    private fun duplicateAndSave(original: FinanceSheet, name: String, withRows: Boolean) {
        val duplicate = FinanceSheet(
            name = name.trim().ifBlank { "Cópia de ${original.name}" }, description = original.description,
            columns = original.columns.map { it.copy(id = java.util.UUID.randomUUID().toString(), options = it.options.toMutableList()) }.toMutableList(),
            rows = mutableListOf(), showSpent = original.showSpent, showIncome = original.showIncome, showBalance = original.showBalance
        )
        if (withRows) {
            val idMap = original.columns.zip(duplicate.columns).associate { it.first.id to it.second.id }
            original.rows.forEach { row -> duplicate.rows.add(SheetRow(cells = row.cells.mapNotNull { (k, v) -> idMap[k]?.let { it to v } }.toMap().toMutableMap())) }
        }
        try { FinanceStore.saveSheet(duplicate); activeSheetId = duplicate.id; showSheet(duplicate.id); Ui.toast(this, "Planilha duplicada") }
        catch (_: Exception) { Ui.toast(this, "Não foi possível duplicar") }
    }

    private fun addColumn(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        showColumnForm(sheet, null)
    }

    private fun manageColumns(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        if (sheet.columns.isEmpty()) { addColumn(id); return }
        AlertDialog.Builder(this).setTitle("Escolha uma coluna")
            .setItems(sheet.columns.map { "${it.name} · ${typeLabel(it.type)}" }.toTypedArray()) { _, which ->
                val col = sheet.columns.getOrNull(which) ?: return@setItems
                AlertDialog.Builder(this).setTitle(col.name).setItems(arrayOf("Renomear / configurar", "Mover para cima", "Mover para baixo", "Excluir coluna")) { _, action ->
                    when (action) {
                        0 -> showColumnForm(sheet, col)
                        1 -> moveColumn(sheet.id, col.id, -1)
                        2 -> moveColumn(sheet.id, col.id, 1)
                        3 -> AlertDialog.Builder(this).setTitle("Excluir coluna?").setMessage("Os valores desta coluna serão removidos de todos os registros.")
                            .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                                sheet.columns.removeAll { it.id == col.id }; sheet.rows.forEach { it.cells.remove(col.id) }; saveAndRefresh(sheet)
                            }.show()
                    }
                }.show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun showColumnForm(sheet: FinanceSheet, existing: SheetColumn?) {
        val form = vertical().apply { setPadding(Ui.dp(this@SheetsActivity, 5), Ui.dp(this@SheetsActivity, 4), Ui.dp(this@SheetsActivity, 5), 0) }
        val name = editField("Nome da coluna", existing?.name.orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Nome", 13, R.color.text_secondary, false)); form.addView(name)
        form.addView(label("Tipo de campo", 13, R.color.text_secondary, false))
        val types = listOf("Texto", "Número", "Moeda (R$)", "Data", "Lista de opções", "Caixa de seleção")
        val typeSpinner = spinner(types, when (existing?.type) { "NUMBER" -> 1; "MONEY" -> 2; "DATE" -> 3; "CHOICE" -> 4; "CHECKBOX" -> 5; else -> 0 })
        form.addView(typeSpinner)
        form.addView(label("Como esta coluna entra nos totais", 13, R.color.text_secondary, false))
        val roles = listOf("Não somar", "Gastos", "Entradas", "Automático pelo campo Tipo")
        val roleSpinner = spinner(roles, when (existing?.role) { "EXPENSE" -> 1; "INCOME" -> 2; "AUTO" -> 3; else -> 0 })
        form.addView(roleSpinner)
        val optionsInput = editField("Ex.: Opção 1, Opção 2", existing?.options?.joinToString(", ").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        form.addView(label("Opções da lista (separadas por vírgula)", 13, R.color.text_secondary, false))
        form.addView(optionsInput)
        optionsInput.visibility = if (typeSpinner.selectedItemPosition == 4) View.VISIBLE else View.GONE
        typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { optionsInput.visibility = if (position == 4) View.VISIBLE else View.GONE }
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Adicionar coluna" else "Configurar coluna").setView(form)
            .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = name.text.toString().trim()
                if (title.isBlank()) { name.error = "Informe um nome"; return@setOnClickListener }
                val type = when (typeSpinner.selectedItemPosition) { 1 -> "NUMBER"; 2 -> "MONEY"; 3 -> "DATE"; 4 -> "CHOICE"; 5 -> "CHECKBOX"; else -> "TEXT" }
                var role = when (roleSpinner.selectedItemPosition) { 1 -> "EXPENSE"; 2 -> "INCOME"; 3 -> "AUTO"; else -> "NONE" }
                if (type != "MONEY") role = "NONE"
                val col = existing ?: SheetColumn(name = title)
                col.name = title; col.type = type; col.role = role
                col.options = if (type == "CHOICE") optionsInput.text.toString().split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct() .toMutableList() else mutableListOf()
                if (existing == null) sheet.columns.add(col)
                saveAndRefresh(sheet); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun moveColumn(sheetId: String, columnId: String, delta: Int) {
        val sheet = FinanceStore.sheet(sheetId) ?: return
        val from = sheet.columns.indexOfFirst { it.id == columnId }
        val to = from + delta
        if (from < 0 || to !in sheet.columns.indices) { Ui.toast(this, "A coluna já está nessa posição"); return }
        val col = sheet.columns.removeAt(from); sheet.columns.add(to, col); saveAndRefresh(sheet)
    }

    private fun addRow(sheetId: String) {
        val sheet = FinanceStore.sheet(sheetId) ?: return
        val cells = linkedMapOf<String, String>()
        sheet.columns.forEach { col ->
            cells[col.id] = when {
                col.type == "DATE" -> FinanceDates.today()
                col.name.equals("Tipo", true) || col.name.equals("Movimentação", true) -> "Despesa"
                col.name.equals("Situação", true) || col.name.equals("Status", true) -> "Pago"
                col.type == "CHECKBOX" -> "Não"
                else -> ""
            }
        }
        val row = SheetRow(cells = cells)
        sheet.rows.add(row)
        try { FinanceStore.saveSheet(sheet); showSheet(sheetId); editRow(sheetId, row.id) }
        catch (_: Exception) { Ui.toast(this, "Não foi possível adicionar registro") }
    }

    private fun editRow(sheetId: String, rowId: String) {
        val sheet = FinanceStore.sheet(sheetId) ?: return
        val row = sheet.rows.firstOrNull { it.id == rowId } ?: return
        val form = vertical().apply { setPadding(Ui.dp(this@SheetsActivity, 5), Ui.dp(this@SheetsActivity, 4), Ui.dp(this@SheetsActivity, 5), 0) }
        val inputs = linkedMapOf<String, EditText>()
        sheet.columns.forEach { col ->
            form.addView(label(col.name, 13, R.color.text_secondary, false))
            val inputType = when (col.type) { "NUMBER", "MONEY" -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
            val input = editField(col.name, row.cells[col.id].orEmpty(), inputType)
            inputs[col.id] = input; form.addView(input)
        }
        val dialog = AlertDialog.Builder(this).setTitle("Editar registro").setView(ScrollView(this).apply { addView(form) })
            .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var invalid: EditText? = null
                sheet.columns.forEach { col ->
                    val value = inputs[col.id]?.text?.toString().orEmpty().trim()
                    if (col.type == "MONEY" && value.isNotBlank() && FinanceDates.parseCents(value) == null) { invalid = inputs[col.id]; invalid?.error = "Informe um valor válido" }
                }
                if (invalid != null) return@setOnClickListener
                inputs.forEach { (colId, input) ->
                    val col = sheet.columns.firstOrNull { it.id == colId }
                    val raw = input.text.toString().trim()
                    row.cells[colId] = if (col?.type == "MONEY" && raw.isNotBlank()) String.format(Locale.ROOT, "%.2f", (FinanceDates.parseCents(raw) ?: 0L) / 100.0) else raw
                }
                saveAndRefresh(sheet); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun editCell(sheetId: String, rowId: String, colId: String) {
        val sheet = FinanceStore.sheet(sheetId) ?: return
        val row = sheet.rows.firstOrNull { it.id == rowId } ?: return
        val col = sheet.columns.firstOrNull { it.id == colId } ?: return
        if (col.type == "DATE") {
            val c = FinanceDates.calendarFor(row.cells[col.id].orEmpty())
            DatePickerDialog(this, { _, y, m, d ->
                val selected = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }
                row.cells[col.id] = FinanceDates.dateForMillis(selected.timeInMillis)
                saveAndRefresh(sheet)
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            return
        }
        if (col.type == "CHECKBOX") {
            AlertDialog.Builder(this).setTitle(col.name).setSingleChoiceItems(arrayOf("Sim", "Não"), if (row.cells[col.id].equals("Sim", true)) 0 else 1) { dialog, which ->
                row.cells[col.id] = if (which == 0) "Sim" else "Não"; dialog.dismiss(); saveAndRefresh(sheet)
            }.setNegativeButton("Cancelar", null).show()
            return
        }
        if (col.type == "CHOICE" && col.options.isNotEmpty()) {
            val current = col.options.indexOf(row.cells[col.id]).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle(col.name).setSingleChoiceItems(col.options.toTypedArray(), current) { dialog, which ->
                row.cells[col.id] = col.options[which]; dialog.dismiss(); saveAndRefresh(sheet)
            }.setNegativeButton("Cancelar", null).show()
            return
        }
        val inputType = when (col.type) { "NUMBER", "MONEY" -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val input = editField(col.name, row.cells[col.id].orEmpty(), inputType)
        val dialog = AlertDialog.Builder(this).setTitle("Editar ${col.name}").setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString().trim()
                if (col.type == "MONEY" && raw.isNotBlank() && FinanceDates.parseCents(raw) == null) { input.error = "Informe um valor válido"; return@setOnClickListener }
                row.cells[col.id] = if (col.type == "MONEY" && raw.isNotBlank()) String.format(Locale.ROOT, "%.2f", (FinanceDates.parseCents(raw) ?: 0L) / 100.0) else raw
                saveAndRefresh(sheet); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun deleteRow(sheetId: String, rowId: String) {
        AlertDialog.Builder(this).setTitle("Excluir registro?").setMessage("Os dados deste registro serão removidos.")
            .setNegativeButton("Cancelar", null).setPositiveButton("Excluir") { _, _ ->
                val sheet = FinanceStore.sheet(sheetId) ?: return@setPositiveButton
                sheet.rows.removeAll { it.id == rowId }; saveAndRefresh(sheet)
            }.show()
    }

    private fun saveAndRefresh(sheet: FinanceSheet) {
        try { FinanceStore.saveSheet(sheet); refreshCurrentSheet() }
        catch (_: Exception) { Ui.toast(this, "Não foi possível salvar. Seus dados atuais foram mantidos quando possível.") }
    }

    private fun refreshCurrentSheet() { if (activeSheetId == null) showList() else showSheet(activeSheetId!!) }

    private fun exportSheet(id: String) {
        val sheet = FinanceStore.sheet(id) ?: return
        exportSheetId = id
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "${safeFileName(sheet.name)}.csv")
        }
        try { startActivityForResult(intent, createCsvRequest) }
        catch (_: Exception) { Ui.toast(this, "Não foi possível abrir o seletor para salvar o arquivo") }
    }

    @Deprecated("Activity result API kept for compatibility with the current project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createCsvRequest || resultCode != RESULT_OK || data?.data == null) return
        val sheet = exportSheetId?.let { FinanceStore.sheet(it) } ?: return
        try {
            val csv = buildString {
                append('\uFEFF')
                append(sheet.columns.joinToString(";") { csvCell(it.name) }).append("\r\n")
                sheet.rows.forEach { row -> append(sheet.columns.joinToString(";") { col -> csvCell(row.cells[col.id].orEmpty()) }).append("\r\n") }
            }
            contentResolver.openOutputStream(data.data!!)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                ?: throw IllegalStateException("Não foi possível gravar o arquivo")
            Ui.toast(this, "Planilha exportada")
        } catch (_: Exception) { Ui.toast(this, "Falha ao exportar a planilha") }
    }

    private fun sheetDateRange(mode: String): Pair<String, String> {
        val start = Calendar.getInstance(); val end = Calendar.getInstance()
        when (mode) {
            "Semana" -> { val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7; start.add(Calendar.DAY_OF_MONTH, -offset); end.timeInMillis = start.timeInMillis; end.add(Calendar.DAY_OF_MONTH, 6) }
            "Ano" -> { start.set(Calendar.MONTH, Calendar.JANUARY); start.set(Calendar.DAY_OF_YEAR, 1); end.set(Calendar.MONTH, Calendar.DECEMBER); end.set(Calendar.DAY_OF_MONTH, 31) }
            else -> { start.set(Calendar.DAY_OF_MONTH, 1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH)) }
        }
        return FinanceDates.dateForMillis(start.timeInMillis) to FinanceDates.dateForMillis(end.timeInMillis)
    }

    private fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ")}\""
    private fun safeFileName(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "planilha" }
    private fun typeLabel(type: String) = when (type) { "NUMBER" -> "Número"; "MONEY" -> "Moeda"; "DATE" -> "Data"; "CHOICE" -> "Lista"; "CHECKBOX" -> "Sim/Não"; else -> "Texto" }

    private fun statBlock(title: String, value: String, colorRes: Int): View = vertical().apply {
        addView(label(title, 11, R.color.text_secondary, false))
        addView(label(value, 13, colorRes, true).apply { setPadding(0, Ui.dp(this@SheetsActivity, 3), 0, 0) })
    }
    private fun emptyCard(title: String, detail: String): View = vertical().apply {
        background = getDrawable(R.drawable.bg_card)
        setPadding(Ui.dp(this@SheetsActivity, 14), Ui.dp(this@SheetsActivity, 16), Ui.dp(this@SheetsActivity, 14), Ui.dp(this@SheetsActivity, 16))
        addView(label(title, 15, R.color.text_primary, true))
        addView(label(detail, 13, R.color.text_secondary, false).apply { setPadding(0, Ui.dp(this@SheetsActivity, 4), 0, 0) })
    }
    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(getColor(color)); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun makeButton(value: String, primary: Boolean): Button = Button(this).apply {
        text = value; textSize = 13f; isAllCaps = false; minHeight = Ui.dp(this@SheetsActivity, 38); minimumHeight = Ui.dp(this@SheetsActivity, 38)
        setPadding(Ui.dp(this@SheetsActivity, 7), 0, Ui.dp(this@SheetsActivity, 7), 0)
        setBackgroundResource(if (primary) R.drawable.bg_button_primary else R.drawable.bg_button_outline)
        setTextColor(getColor(if (primary) R.color.on_primary else R.color.primary)); stateListAnimator = null
    }
    private fun editField(hintValue: String, initial: String, inputTypeValue: Int): EditText = EditText(this).apply {
        hint = hintValue; setText(initial); inputType = inputTypeValue; textSize = 14f; maxLines = 1
        setPadding(Ui.dp(this@SheetsActivity, 11), Ui.dp(this@SheetsActivity, 3), Ui.dp(this@SheetsActivity, 11), Ui.dp(this@SheetsActivity, 3))
        setBackgroundResource(R.drawable.bg_input); minimumHeight = Ui.dp(this@SheetsActivity, 42)
    }
    private fun spinner(items: List<String>, selection: Int): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@SheetsActivity, android.R.layout.simple_spinner_item, items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setSelection(selection.coerceIn(items.indices))
    }
}
