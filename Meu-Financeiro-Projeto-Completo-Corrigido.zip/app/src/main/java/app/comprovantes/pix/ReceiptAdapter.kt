package app.comprovantes.pix

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ReceiptAdapter(private val context: Context) : BaseAdapter() {

    private var data: List<Receipt> = emptyList()

    fun submit(list: List<Receipt>) {
        data = list
        notifyDataSetChanged()
    }

    override fun getCount(): Int = data.size

    override fun getItem(position: Int): Receipt = data[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView
            ?: LayoutInflater.from(context).inflate(R.layout.item_receipt, parent, false)
        val receipt = data[position]

        val title = view.findViewById<TextView>(R.id.itemTitle)
        val name = view.findViewById<TextView>(R.id.itemName)
        val meta = view.findViewById<TextView>(R.id.itemMeta)

        if (receipt.description.isNotBlank()) {
            title.text = receipt.description
            name.text = receipt.displayName
            name.visibility = View.VISIBLE
        } else {
            title.text = receipt.displayName
            name.visibility = View.GONE
        }
        meta.text = receipt.formatLabel + " · " +
            Ui.formatDate(receipt.importedAt) + " · " +
            Ui.formatSize(context, receipt.sizeBytes)
        return view
    }
}
