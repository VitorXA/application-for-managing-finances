package app.comprovantes.pix

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID

/** Conteúdo recebido sem nenhum byte. */
class EmptyContentException : IOException("empty content")

/**
 * Armazenamento local simples:
 *  - arquivos em filesDir/receipts/
 *  - metadados em filesDir/receipts.json (gravação atômica: arquivo temporário + renomear)
 */
object ReceiptStore {

    private val lock = Any()
    private var initialized = false
    private lateinit var dir: File
    private lateinit var indexFile: File
    private val items = ArrayList<Receipt>()

    fun init(context: Context) {
        synchronized(lock) {
            if (!initialized) {
                val base = context.applicationContext.filesDir
                dir = File(base, "receipts")
                dir.mkdirs()
                indexFile = File(base, "receipts.json")
                val indexOk = loadIndex()
                initialized = true
                // Só remove arquivos sem registro se o índice foi lido com sucesso.
                if (indexOk) removeOrphans()
            }
        }
    }

    fun count(): Int = synchronized(lock) { items.size }

    fun list(): List<Receipt> = synchronized(lock) { items.sortedByDescending { it.importedAt } }

    fun search(query: String): List<Receipt> {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return list()
        return list().filter {
            it.displayName.lowercase(Locale.ROOT).contains(q) ||
                it.description.lowercase(Locale.ROOT).contains(q) ||
                it.formatLabel.lowercase(Locale.ROOT).contains(q)
        }
    }

    fun find(id: String): Receipt? = synchronized(lock) { items.firstOrNull { it.id == id } }

    fun findByStoredName(storedName: String): Receipt? =
        synchronized(lock) { items.firstOrNull { it.storedName == storedName } }

    fun fileOf(receipt: Receipt): File = File(dir, receipt.storedName)

    /** Copia o conteúdo de [uri] para o armazenamento privado. Lança exceção se algo falhar. */
    fun saveFromUri(
        context: Context,
        uri: Uri,
        displayName: String,
        mime: String,
        description: String
    ): Receipt {
        val stored = UUID.randomUUID().toString() + "." + extensionFor(mime)
        val part = File(dir, "$stored.part")
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw FileNotFoundException("sem fluxo de leitura")
            var size = 0L
            input.use { ins ->
                FileOutputStream(part).use { out ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = ins.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        size += n
                    }
                    out.flush()
                    out.fd.sync()
                }
            }
            if (size == 0L) throw EmptyContentException()
            return commit(part, stored, displayName, mime, size, description)
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    /** Salva um texto compartilhado como arquivo .txt. */
    fun saveText(text: String, displayName: String, description: String): Receipt {
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty()) throw EmptyContentException()
        val stored = UUID.randomUUID().toString() + ".txt"
        val part = File(dir, "$stored.part")
        try {
            FileOutputStream(part).use { out ->
                out.write(bytes)
                out.flush()
                out.fd.sync()
            }
            return commit(part, stored, displayName, "text/plain", bytes.size.toLong(), description)
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    fun updateDescription(id: String, description: String): Receipt {
        return synchronized(lock) {
            val index = items.indexOfFirst { it.id == id }
            if (index < 0) throw FileNotFoundException("registro não encontrado")
            val old = items[index]
            val updated = old.copy(description = description)
            items[index] = updated
            try {
                persist()
            } catch (e: IOException) {
                items[index] = old
                throw e
            }
            updated
        }
    }

    /**
     * Apaga primeiro o arquivo e depois o registro. Se o arquivo não puder ser apagado,
     * o registro é mantido (assim não sobra arquivo órfão nem registro apagado por engano).
     */
    fun delete(id: String) {
        synchronized(lock) {
            val index = items.indexOfFirst { it.id == id }
            if (index < 0) throw FileNotFoundException("registro não encontrado")
            val receipt = items[index]
            val file = fileOf(receipt)
            if (file.exists() && !file.delete()) {
                throw IOException("não foi possível apagar o arquivo")
            }
            items.removeAt(index)
            try {
                persist()
            } catch (e: IOException) {
                items.add(index, receipt)
                throw e
            }
        }
    }

    fun extensionFor(mime: String): String = when (mime) {
        "application/pdf" -> "pdf"
        "image/png" -> "png"
        "image/jpeg" -> "jpg"
        "text/plain" -> "txt"
        else -> if (mime.startsWith("image/")) {
            mime.substringAfter('/').filter { it.isLetterOrDigit() }
                .lowercase(Locale.ROOT)
                .ifEmpty { "img" }
        } else {
            "bin"
        }
    }

    // ---------------------------------------------------------------- internos

    private fun commit(
        part: File,
        stored: String,
        displayName: String,
        mime: String,
        size: Long,
        description: String
    ): Receipt {
        return synchronized(lock) {
            val target = File(dir, stored)
            if (!part.renameTo(target)) throw IOException("não foi possível finalizar o arquivo")
            val receipt = Receipt(
                id = stored.substringBeforeLast('.'),
                displayName = displayName,
                storedName = stored,
                mimeType = mime,
                importedAt = System.currentTimeMillis(),
                sizeBytes = size,
                description = description
            )
            items.add(receipt)
            try {
                persist()
            } catch (e: IOException) {
                items.remove(receipt)
                target.delete()
                throw e
            }
            receipt
        }
    }

    private fun loadIndex(): Boolean {
        items.clear()
        if (!indexFile.exists()) return true
        return try {
            val array = JSONArray(indexFile.readText(Charsets.UTF_8))
            for (i in 0 until array.length()) {
                items.add(Receipt.fromJson(array.getJSONObject(i)))
            }
            true
        } catch (e: Exception) {
            // Índice ilegível: guarda uma cópia, não apaga nenhum arquivo e recomeça o índice.
            items.clear()
            indexFile.renameTo(File(indexFile.parentFile, "receipts.json.corrupt"))
            false
        }
    }

    private fun persist() {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        val temp = File(indexFile.parentFile, "receipts.json.tmp")
        FileOutputStream(temp).use { out ->
            out.write(array.toString().toByteArray(Charsets.UTF_8))
            out.flush()
            out.fd.sync()
        }
        if (!temp.renameTo(indexFile)) {
            temp.delete()
            throw IOException("não foi possível gravar o índice")
        }
    }

    private fun removeOrphans() {
        val known = items.map { it.storedName }.toHashSet()
        dir.listFiles()?.forEach { file ->
            if (file.isFile && file.name !in known) file.delete()
        }
    }
}
