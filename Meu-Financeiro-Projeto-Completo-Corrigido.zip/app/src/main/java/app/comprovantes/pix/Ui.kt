package app.comprovantes.pix

import android.content.Context
import android.os.Build
import android.text.format.Formatter
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Ui {

    /** Mantém o conteúdo fora das barras do sistema (necessário com Android 15 em diante). */
    fun applyInsets(root: View) {
        val left = root.paddingLeft
        val top = root.paddingTop
        val right = root.paddingRight
        val bottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { view, insets ->
            val extra = systemInsets(insets)
            view.setPadding(
                left + extra[0],
                top + extra[1],
                right + extra[2],
                bottom + extra[3]
            )
            insets
        }
        root.requestApplyInsets()
    }

    @Suppress("DEPRECATION")
    private fun systemInsets(insets: WindowInsets): IntArray {
        return if (Build.VERSION.SDK_INT >= 30) {
            val types = WindowInsets.Type.systemBars() or
                WindowInsets.Type.displayCutout() or
                WindowInsets.Type.ime()
            val i = insets.getInsets(types)
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            intArrayOf(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
        }
    }

    fun toast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    fun hideKeyboard(view: View) {
        val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun formatDate(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.forLanguageTag("pt-BR")).format(Date(millis))

    fun formatSize(context: Context, bytes: Long): String =
        Formatter.formatShortFileSize(context, bytes)

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
