package app.comprovantes.pix

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.FileNotFoundException

/**
 * Destino do menu "Compartilhar" (e da importação manual). Fluxo:
 * ler o conteúdo -> mostrar o que foi recebido -> usuário confirma -> gravar -> mostrar o resultado.
 * Nada é dado como salvo antes de a gravação terminar.
 */
class ReceiveActivity : Activity() {

    private class Outcome(val candidate: Importer.Candidate, val error: String?)

    private lateinit var progressRow: View
    private lateinit var progressText: TextView
    private lateinit var summaryText: TextView
    private lateinit var itemsContainer: LinearLayout
    private lateinit var descriptionLabel: TextView
    private lateinit var descriptionInput: EditText
    private lateinit var resultText: TextView
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button
    private lateinit var historyButton: Button

    private var candidates: List<Importer.Candidate> = emptyList()
    private var skippedLines: List<String> = emptyList()
    private var savedTotal = 0
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)
        Ui.applyInsets(findViewById(R.id.receiveRoot))
        ReceiptStore.init(this)

        progressRow = findViewById(R.id.progressRow)
        progressText = findViewById(R.id.progressText)
        summaryText = findViewById(R.id.summaryText)
        itemsContainer = findViewById(R.id.itemsContainer)
        descriptionLabel = findViewById(R.id.descriptionLabel)
        descriptionInput = findViewById(R.id.descriptionInput)
        resultText = findViewById(R.id.resultText)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)
        historyButton = findViewById(R.id.historyButton)

        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener { save() }
        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
            finish()
        }

        load()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!busy) super.onBackPressed()
    }

    private fun load() {
        setBusy(true, getString(R.string.reading_content))
        val received = intent
        Thread {
            val resolved = try {
                Importer.resolve(this, Importer.extract(received))
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) showCandidates(resolved)
            }
        }.start()
    }

    private fun showCandidates(list: List<Importer.Candidate>) {
        candidates = list
        setBusy(false, null)
        itemsContainer.removeAllViews()

        if (list.isEmpty()) {
            summaryText.setText(R.string.nothing_received)
            saveButton.visibility = View.GONE
            cancelButton.setText(R.string.close)
            return
        }

        val supportedCount = list.count { it.supported }
        val summary = StringBuilder(
            resources.getQuantityString(R.plurals.received_count, list.size, list.size)
        )
        if (supportedCount == 0) summary.append("\n").append(getString(R.string.nothing_to_save))
        summaryText.text = summary

        for (candidate in list) {
            val row = layoutInflater.inflate(R.layout.item_incoming, itemsContainer, false)
            row.findViewById<TextView>(R.id.incomingName).text = candidate.displayName
            row.findViewById<TextView>(R.id.incomingStatus).text =
                if (candidate.supported) {
                    getString(R.string.ready_to_save, Receipt.labelFor(candidate.mime))
                } else {
                    getString(R.string.cannot_save, candidate.problem.orEmpty())
                }
            itemsContainer.addView(row)
        }

        skippedLines = list.filter { !it.supported }.map {
            getString(R.string.result_skipped, it.displayName, it.problem.orEmpty())
        }

        if (supportedCount > 0) {
            descriptionLabel.visibility = View.VISIBLE
            descriptionInput.visibility = View.VISIBLE
            saveButton.setText(R.string.save)
            saveButton.visibility = View.VISIBLE
        } else {
            saveButton.visibility = View.GONE
            cancelButton.setText(R.string.close)
        }
    }

    private fun save() {
        if (busy) return
        val toSave = candidates.filter { it.supported }
        if (toSave.isEmpty()) return
        val description = descriptionInput.text.toString().trim()

        setBusy(true, getString(R.string.saving))
        Thread {
            val outcomes = toSave.map { candidate ->
                try {
                    when (val source = candidate.source) {
                        is Importer.Source.FileSource -> ReceiptStore.saveFromUri(
                            this,
                            source.uri,
                            candidate.displayName,
                            candidate.mime ?: "application/octet-stream",
                            description
                        )
                        is Importer.Source.TextSource -> ReceiptStore.saveText(
                            source.text,
                            candidate.displayName,
                            description
                        )
                    }
                    Outcome(candidate, null)
                } catch (e: Exception) {
                    Outcome(candidate, describeError(e))
                }
            }
            runOnUiThread {
                if (!isDestroyed) showOutcomes(outcomes)
            }
        }.start()
    }

    private fun showOutcomes(outcomes: List<Outcome>) {
        setBusy(false, null)
        val saved = outcomes.filter { it.error == null }
        val failed = outcomes.filter { it.error != null }
        savedTotal += saved.size

        val lines = ArrayList<String>()
        if (savedTotal > 0) {
            lines.add(resources.getQuantityString(R.plurals.saved_summary, savedTotal, savedTotal))
        }
        for (f in failed) {
            lines.add(getString(R.string.result_failed, f.candidate.displayName, f.error.orEmpty()))
        }
        lines.addAll(skippedLines)

        resultText.text = lines.joinToString("\n\n")
        resultText.visibility = View.VISIBLE
        summaryText.visibility = View.GONE
        itemsContainer.visibility = View.GONE
        descriptionLabel.visibility = View.GONE
        descriptionInput.visibility = View.GONE
        cancelButton.setText(R.string.close)

        if (failed.isEmpty()) {
            saveButton.visibility = View.GONE
        } else {
            // Permite tentar de novo somente os itens que falharam.
            candidates = failed.map { it.candidate }
            saveButton.setText(R.string.retry)
            saveButton.visibility = View.VISIBLE
        }
        if (savedTotal > 0) {
            historyButton.visibility = View.VISIBLE
            if (saved.isNotEmpty()) Ui.toast(this, getString(R.string.saved_toast))
        }
    }

    private fun describeError(e: Exception): String {
        val message = e.message.orEmpty()
        return when {
            e is SecurityException -> getString(R.string.err_permission)
            e is EmptyContentException -> getString(R.string.err_empty)
            message.contains("ENOSPC", ignoreCase = true) ||
                message.contains("No space left", ignoreCase = true) ->
                getString(R.string.err_no_space)
            e is FileNotFoundException -> getString(R.string.err_unreadable)
            else -> getString(R.string.err_generic)
        }
    }

    private fun setBusy(value: Boolean, label: String?) {
        busy = value
        progressRow.visibility = if (value) View.VISIBLE else View.GONE
        if (label != null) progressText.text = label
        saveButton.isEnabled = !value
        cancelButton.isEnabled = !value
        historyButton.isEnabled = !value
    }
}
